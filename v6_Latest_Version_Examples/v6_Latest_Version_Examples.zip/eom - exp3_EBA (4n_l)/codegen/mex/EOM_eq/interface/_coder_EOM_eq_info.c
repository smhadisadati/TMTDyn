/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_eq_info.c
 *
 * Code generation for function 'EOM_eq'
 *
 */

/* Include files */
#include "_coder_EOM_eq_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[10] = {
    "789ced9b3b6fdb5614c7af82386981b4c9d076e8d80f105a12655b59025ba41e9569cbb1a4c82a0a8926af2d4abca4445eca948666eb5664ce67c8d0a11fa06b"
    "812e053a640fda2e05fa40c7ba482d89d77ac00c0d534fe69ec1d4c121f5e7ff1cde1f2e041a8432420800f02118448d1b1c3f70f207cef116188fc97ac839de",
    "1bc9ff7b363c7f0ddc06e7cf86d7f5ea7f5efc79eee492ae6168e341a289085e5e29eb48d1440de73b4d080c68ea6a1bcafdca89a2c2bc82e0e168b2d7cb5072"
    "a47499f44abdcf891a941a87160246cd1cdea13a9af4fbf1d7c5fdfd30e2b7e787f8bd7d453f46eba41fc713398907cef9a4fe05ff65e2115330a16132926562",
    "1d418311f8d4b6d9d124262dca0a9317f25c476312ba0c9dcf95638845a61dabec8a189ab852bcb85ad1b50a6f8ba8a94293813a62f87da1025b0fd1b8afa64f"
    "5ff73d7c91ba8945ac4815a4c81513c3e6a57ed5a7fe1d57fd3bfdf34d6c58121efafdc9a75ec3c32fa9cf6e8e139d7406ead5cffb603cdcfc4d1e87e7bfd75f",
    "b7d57baf426e7ae71e7ae737d0fbfdcda77fcf538fc4a2f46c97efbbeaf9bc4aef13173df27c92ba916dd5e2a823f161f6a99a536c954d5badf4f03e721e3a5e"
    "f7015cf2797dff28af6fd2c765e575d5a7af35575f6b7d5f27f54a2339453d2f3ecbba75acc2e9cd4d74d51bcc8dd46737b77e07c9d8e6c691afc4f972f9c51f",
    "91dfe6a94722e85c3e49a76ba5cd52019672186df1162aadb7bb3ce572d0b9ecc5c90baa285a7275b9bcf8b90d3a78ddb9ad2a977f7ca9532e83e97339bb5e6c"
    "e2685c6439ac6d70f9bd42cd6a2b49cae5e559df8bd92fe7eb158bee97fdccaddfc1c0ef975f7ef735e532983e97cb1b6a765f4997e5ddd3ed5c26d389a4ec42",
    "9aa35c0e3a97bd388944d34c865797cb8b9fdba08341df2fd73faabe9ea71e89a07379bfdbce0b29542fe58fc2755d88c64cf1ac93a25c5e9ef5bd402e472897"
    "7d723912742e279b12e532983e97ed2dd32e74378fedfd52f6906b358e324acba2bf2f2fd1fa5e2097a394cb3eb91c0d3a97dffcdba05c06d3e7b266a9674a7a",
    "878b458bb8d5ce66b82e3c7c4a7f5f5ea2f5bd402eb394cb3eb9cc069dcbdf739072195cffb9fcd8458f3c97a4be9de926d2122fe81bba201807e281804b7140"
    "b9bc3cebdbfbbde69bf87adfc317a99b4d4346cd64380ec6f5ab3ef5e7cd6938914ffa25f519bed74c3ad91f6550397debe7cf7e99a71e8955e5f475f7cfd158",
    "19375067cfd06a472ce20b5692cbb33b94d394d38370e8125907e3fa559ffaef2ca723eb81e6b4f4f8db5fe7a94722e89cb6e33be5784a3b8deda22d6cec3c51"
    "b3a75d83729a72dac9095dc2605cbfea53ffdde57438d09c7efdf015dd4f83e9735a3f2dc6eba9622ed94eb12a5fee2811249fd1f737969ed3559fbeeebafaba",
    "dbf7a5eaa2dc7bb16e55b92cb9ea0de646eab39b9bd3c1b7fcdf7610b8fc4de81fba7f0633f89d23d728b289938cf6f9e646e1c07e72a621251a002eff0fdb4b"
    "6efd", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 17536U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_eq"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM_eq.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.07067129633));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_eq_info.c) */
