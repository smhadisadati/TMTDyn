/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_info.c
 *
 * Code generation for function 'EOM'
 *
 */

/* Include files */
#include "_coder_EOM_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[10] = {
    "789ced9acf73da4614c7d7193b6967d23687a6871cf30758200136b9646c4080b16c1c03c5743a204b6b106825593fb0e0d0dc72cbb4d7cef43fc8a187fe01c9"
    "b1333df6909e336d8f6d677aac3b2d08d610068d9808882df61d901e6fc577df7bcb67767604d6b2dc1a00e06330b06fb283eb4743ffdef07a0bbc6d93f1b589",
    "effbfebf4f47e337c03ab87cfa76fccfdec7d7435f501513dae6c0517804af9e14552429bc62163a1a043a3454b90d45277226c9b02021783cee1cf43dc48e85"
    "ae9c7ea87f9f6840a1756c21a0378cd10ce571c7a9c75fbdf9bd1acbab9f0fce777d4a3dc6e3b81ed5091fdbbde1781cff22f565e2115534a06e508265982a82",
    "3ac5a5d23b464711a80c2f4a54812b243b0a95504538bcaf9e4293a7dad1ea3e6f42c3ac967a4f4baa524dd93cd2646850504554ea90db4457f9683ef3b9eb91"
    "0f8e8bbdd92149ac1a26d4c6eb59f3a97fdb55ffb633de30754b30477a3ffad46b78e48be38bebdf78253791571d3f9931afc9eb68fc07ceffb476f7b5139aa6",
    "77e9a177f90e7adffdf2e072997ad8de979eedf27bd3d6e534bdcf5cf4f0bac4f1ae2c35d4231a329c16dbabefd9a29868e433a379e43d74bce6015cfc65fdfe"
    "2b97e767ade375e373cd673e1baef96c38f99c35ab2d1678affb59f5bc782caad6a90ca7f3f85df47857bd41bf707c71fd722ad8ebd8c096c58faff8e5f2f8db",
    "3fe8df97a9872de83c3ecb641ae5ad721196f326da4e59a81c6a775384c741e5b1171f7b34698beccde5f1a9abdea05f38be501ef72a88811c541eafbf8c111e"
    "83f9f3382f71f45ea85c39c917cd2d399a97599169121eaf328f2585f0d81f8f7b150c3a8f7f7aa1121e83f9f338172a692613e723495389250b07c586d59658",
    "c2e3a0f2d8ebbca2d0ac5ae4bcc24fbf9c0a06febce2c50fcf088fc1fc795c89c9b943295311f7eb3bf96cb643a7ed622649781c541e7bf111f186c1866f2e8f"
    "dffffe7850c1a0ef8f9b9fd6de2c530f5bd0797cd86d17b8346a960b27e1a6ca315183bfe8a4098f579ac734e1b14f1ed341e731ab0984c760fe3cb6b70dbbd8",
    "dd3ab50fcbb9e3e479eb242b9d5be4fc78b579cc101efbe43113741efff74f8bf018cc9fc78a255f4899dd64942999e7ed5c36d985c79f93f3e3d5e67184f0d8"
    "278f2341e7f1cb24243c06b3afcbfb2e7a785de2f84eb69bc808294e8da91ca71ff1479c598e03c2e3ebca63cd673e1f7ae483e386a68b4863c3f1897ad67cea",
    "2f9bcf70c29fcc17c717d7bfab4a3a880e2a9f6ffdfcf0d765ea61bba97c9e75bfcc442b660b750e74a5711241a9a2c5260b915dc267c267872a7468a29e359f"
    "fa2bcb673a14683e0b8fbfff6d997ad882ce673bbe5b89a7957a741f6d9bfaee133957efea84cf84cf43aa8427ea59f3a9bfba7c0e079acf6f365f93fd33983f",
    "9fd57a29de4c97f26c3b1d9153958e4423f182bc8f716df95cf399cf1dd77cee38f9c82a2ff65f90bba93c165cf506fdc2f1c5f56b58c1e181735079fc7ced6f"
    "b25f060b38cfc8b74a91c45956d9db8a158fec27170a929800f0f87fad66f4a7", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 18856U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.07082175929));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_info.c) */
