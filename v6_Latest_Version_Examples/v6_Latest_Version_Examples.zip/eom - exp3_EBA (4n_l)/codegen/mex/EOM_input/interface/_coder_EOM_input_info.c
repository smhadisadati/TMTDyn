/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_input_info.c
 *
 * Code generation for function 'EOM_input'
 *
 */

/* Include files */
#include "_coder_EOM_input_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[4] = {
    "789ce553cd4ac34010de48152f6a4f3e86eba5857a52faa3822962534144e29a4c6d34bb09bbdb9278e923f85abe818fa10f50c1a4699a35a4440aeac18164f6"
    "cb3733dfccb041daa9ae2184b65162fb1b89df8a9ef788a8cebfafa1af96e7b502ff31c9e2d751054d27495ecabf45afe739b63c262190096084c222d3f6a8c3",
    "089346e803e2203c770cf68c19382e180e859e0aba31a21d855a80988acfcd21588fbd11457c28b20e5d15ccf611cf77abcc1bcf93ce5b29d887cae74dcbe17c"
    "dc7fd17b59512fad7f5fa297f2d7fd9be601ee0be0025b23213d0a1cebede32311320b9f10dbc1866eb442869b9e0df3b3790792e071cd3c231284342fa36cc7",
    "63663b20d4774160f0281e45354d9f70b147892cdde3ce37e7cafb2c7e73f6df4cc8aba6ee51d59b96e84d57d06bf9f8f037f552fb2bbd6049bda27b59a4b7bb"
    "44af9ae35ba4d1086a7c507f620f5d29f9955fbfd03b591fe7253a657da025f8a7eb7f02e96d95c9",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 1608U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_input"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM_input.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.07082175929));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_input_info.c) */
