/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_eq_info.c
 *
 * Code generation for function 'EOM_eq'
 *
 */

/* Include files */
#include "_coder_EOM_eq_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[8] = {
    "789ced9abf6fda4014c78f28bf2a353f94aa1d3a766d15270102e916880d242521c1a182aa22363e82c16713fb9c408676aad42d6b97fe0fa9ba64ecdca16b86"
    "4e5dfa37742c185f20a89613412fc2f19390793cfb7ddfbd77fae8640102a9740000300b3a5679d1b9ceb43e5fc60098b77f1f03d7ad3f1eb0afd33dfe9ff7dd",
    "fb27c0b8e5cff4c4cf5bcf9fd97e4953316ce08ea30a085e3d296948560515f3cd3a043a3434e5184a56a42c2b909711ccf63adb6d0f713da12ba71d6a7f8f57"
    "60a9963511d02b46b742a5d7b1fad15edf79cf7adbf593f58effa31fbd71d28f4c9f4f6cdece4fe26fd8b7f197ccbe017583299906d610d499349b58379a6a89",
    "490a92ccf0697ea3a932714d82f6f7a208b1c0f026d674595018a82186dd4917e1d12222f5d707ac7fcea57e1237b080e55211c952d1c0b07ed5bf8301f5271d"
    "f527adfc06d6cd12eeceebdb807a7997f592f8b0e6d5d7b74564e777ebdf1cb86e4eebe9bf76ef9fb6eee71e5e0668eaa5e0d30c4d3d6277a5d770c877d3fdf8",
    "c4418fec471287caee16d471703556d6d8f58d9c785a3554b65b07e18c938e5b1dc0c1a7957fd4397c3060fd138ef54f58f9cbd5628d03eefb7c58dc95345354"
    "e0f0e6b3e3a8d7c94fe2c39a8fd5af166d6971e18832679f3d5f7b44538f98d739cba350634fd6234a088b3931226a4ba852e67cce7a85b36edc6b714356b9d1",
    "e52cedf974fae53e9f51e5eca70f1f7dce82e17316ad35362196b387bb6684df3b5e2de4c4682ce973d62b9c753bcff2d5a2e99f676f3e1fab5f1e3ecf7efdf5"
    "d9e72cf80fe7d9a5a4b68d38612d735cc8941bfbafd5e56d31e673d62b9c75e31e120c835b1e5dced29e4fa75ff4ceb375ca9c0dc616bed3d423e675ced60a11",
    "45499a48106a6c382dc97a54840d9fb3f78bb32b3e676fc5d915efbe377870f683aa1e31af73369d43b913fe55beb9ba2e15ea9bd57235c386e33e67ef156783"
    "3e676fc5d9a07739fbfbf2dd2c4d3d625ee7ec61ad2626a49c18ce96b7429b91d39092c752c2e7ac57383be558ff94955fd104a9fde2e0ae387b31a0deaea35e",
    "273f890f6b3e76bfa8ffbf8b366f2fb23f1768ea111b55de3e76d023fb90c4a371f684cb8722a9fa89112d2552cb3b19e1088c3e6fff027cc34b50",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 11392U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_eq"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\Tutorial\\eom\\EOM_eq.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738213.7892361111));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_eq_info.c) */
