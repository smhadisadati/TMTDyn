/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_input_info.c
 *
 * Code generation for function 'EOM_input'
 *
 */

/* Include files */
#include "_coder_EOM_input_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[4] = {
    "789c6360f4f465646060e0638000033608cd0bc41f8012025071260654802ecf8885fe5b8f50cfcac0c2f0a71ea20f26ff1e48f443f9c9f97925a91525104e5e"
    "626e2a5c674a7e6e665e625e494865412a43516a717e4e596a0a58262d332735243337351899e307e2e5ba2149c139202910db392335393bb83497a128a318e1",
    "c21c640e383c40fe4b40f22fc83f30ffb260090f647974c088c647573752ec3b41a67d30f3d309d807938f0e8d75b6d20f2d4e2d2ad64f2e2d2ec9cf4d2dd2f7"
    "7575772caecc4bd6f7484cc9d40ff10d71a9ccd377ce4f4985b2e393524b12f5cb4ce37d124b528b4be2c380ba33f3f3e25d2b12730b72528bf553f373f54b81",
    "66c617241615ebe52696100c477e22fd854e23d47380f34d6de27546e47044b6ef0f01fbfe9061df1cb10a567ada070303655f050ef3b0a54b6cf689e1b04f00"
    "4dde292ab33020bcc231c2c2ddd9d9353d3dbc20d929c203e18e0002f6107207030e3eadcd0700b5419575",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 1608U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_input"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM_input.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.05974537041));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_input_info.c) */
