/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_eq_info.c
 *
 * Code generation for function 'EOM_eq'
 *
 */

/* Include files */
#include "_coder_EOM_eq_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[9] = {
    "789ced9abf6fd35010c71dd41f2051da0566245890102e71485bc4d0244dd23649d3fc2e45c875ec97c44d9e1dfc1cd7e952c1c4c60a1b2b037f027b2554c4c6"
    "c80813ac0c20681cbf268db01cc98d135bbec539ddd9df77777e1f3d59217c1b291f4110d788ae35a9ee754ef717f4eb25e2bc0dc67dfaf54a9fffe7a8973f4d",
    "4c69fe5c5ffcf6e9435fe93e2b0a3250e5ae2330109cddc98990171841ceb79b809000121b0ae0b448856f803c0f41aedfd9ea7830d6173a733aa1ceef480db0"
    "f55c0b12520df556d8e877b47e74d677dc576f67fdb8dea9fff4a33f8efb511ef0b12de8f938fe24fa34f2902c202021926d215984402253d17808b505965c67",
    "389ecca7f26b6d818c881cd07fd3652033a4f2804e323240325d3cbd9b17053aaa32b0d90088042224a3e9140d9edd83e7eb6a5aac6bdea42e1c473223f32c0d"
    "798e4632689ee9ef59d49f31d49fd1f2912cb558b957ef678b7a75937a717c74731ce8a43e50b37ece13e7cda8bec16b2fffb296af5cfde2b353efeda35bbfec",
    "d4c3362e3dd5e079c3be9f370cf4f0fb89e34aaa5400e54ca27198cdf34a5d89aa856238dc5bc7b6898ed93a0803dfaee7bb95d77b16eb9a36ac6b5acbafecd3"
    "f5d805ea99f199135be506b8b8b931867add7c1c1fdddcb40ee2b1d9c6118ab197cb1ffebe3cb1530f9bdbb99cdd3a0827c3076aad992e84a52c1f2c71cbd1a8",
    "c765b773d98c93a754e1859873b93cfeb9753b38ecdc9ccae53bdfbf795c262e9ecb4bed5cce9f5c52ca9562201807e2f2469cab7ae7e509dadfe3392fe7f7e9"
    "96775eb63237ad83ae3f2fbffe417cb2530f9bdbb91c1162713faa70c1604e6d164b61d85243db318fcb6ee7b21927218350ecbe73b93cfeb9753be8f6f3f2ef",
    "d5af4776ea61732a97af1be8e1f712c7b3c1c4622d14db54e474265da3e4cd1594de263c2e4fcefe1e2397fd1e972d72d9ef762eafbec83eb7530f9b53b93cec"
    "7959dc92a4c24618d4c37e6a6db19544896a68d73b2f4fd0fe1e2397298fcb16b94cb99dcbcac737efedd4c3e6762eb3a980e44f8662c575a5ca6d1e427f1509",
    "81b8c7e5c9d9df63e472c0e3b2452e07dccee599c4bb633bf5b03995cbc37ec7580a896aedf18ab2d382ebfc6e20132ae50219c2e3f2e4ecefd17079d6b0ae59"
    "2dbf21325ce703b353b9cc1aea75f3717c7473d33b68f3ff97ede6f2dd9f374fecd4c3e6542e0f7b5e4e23a6ad52956c4d0deea4a8f83e6c405458733e97ff01",
    "b6554681", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 13192U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_eq"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM_eq.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738321.69586805557));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_eq_info.c) */
