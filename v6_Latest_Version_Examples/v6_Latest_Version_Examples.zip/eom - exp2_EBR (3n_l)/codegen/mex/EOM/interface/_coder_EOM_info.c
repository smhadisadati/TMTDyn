/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_info.c
 *
 * Code generation for function 'EOM'
 *
 */

/* Include files */
#include "_coder_EOM_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[9] = {
    "789ced99cf4f1a4114c747eb8fa6e90f7b68ff841e5d0401e90d7017b1a228286ad3e0c28cbab0b30bec2eb2bdf817682ffd437aeaa517931eda43ef1eda4393"
    "f65c7b6bd2d8a4b030420d9b35aeae759c7760f6e5cdf09df766f864f30003c9d40000e03e68db9ba9f678afe38f75c641f0af9d8e0f74c63b3dfe9fddeefc61",
    "30048e77bbeb5af1a3e6c7ab8e5f54151d35f4b6a388189dac842a961451d1b36605811ad254b98ea015d99464949530caf43af32d0f0b3da113a7156a3dc7b7"
    "51b19c3130a86d6bdd1dcabd8e558f9fcdfd1df4e4dbca87e43bd4a71ebd71528ffc299fd858673e893fe75fc49f72cb1aaa695cd1d07415a31a97e21351cd54",
    "8adc8c08252e9bca4e9b0a175721ea3ce70b4817b97a303f27ea48d3f32bcdd592aae4f986882b32d238a4628e5f488de3937c2a2ef3b9eb900f89c3e6eeb004"
    "f39a8e2abdf5dc70a93f62ab3f62cdd7f49a51d4bb7a1f5dea6d3be44be297777ebd951cc74e757c70c6bc4e8fddf9b7addf69553cb442fdf48e1df48ecfa1f7",
    "ebfdef352ff5885d955ec3e6fbfaddcb7e7a8f6df4c8bd24f1102c45e6038bbe9814f1357cc2620049bc31dddd47da41c7691fc0c6f7eafb0f6cd69fb58eff1b"
    "9f375ce6336c9bcfb095cf66295f1680f3bd3fab9e138fa16a1464d49fc7e7d1136df5dae745e297775e56059b27d636aff851f298c739b8f9c54b3d62b4f3b8",
    "b6ae85f4ea4a618adfcea5a5d9702a8ae3ab71c6635a79ecc4c7264dea50b8be3c2ed8eab5cf8bc42f95c7cd0a1220d3cae36839cd780cce7e2f1fd9e8917b49"
    "e2d3f5e9b2cf349378895faecf65a2a26f4b3601e3f10de6b1a4301ebbe371b382b4f3f8c38f4f8cc7e0e2df8fe5ba1289f86349d594310a8471d934ab26eb57",
    "50cb63a77e45b6943758bfc2cd795915a4be5f71f4fa3be331b8781e17e6e73359a10695d8c4aa1e0aad2e07913fc4331ed3ca63273e6251d38489ebcbe3ab7f"
    "3f6e5790f6f7e35be3fb7b5eea11a39dc751586dc4a70c41da5a5027d4248ac6e7766604c6e31bcd633fe3b14b1efb69e7f1db6f9ff7bdd423463b8f53c1f59d",
    "86914bbf0ca3d5446e6a690daef090f52b6e368f038cc72e791ca09dc7a30f37de79a9478c761e9b42ac14cd04901fcd1a81dcca72b8923610eb57dc6c1e4f32"
    "1ebbe4f124ed3cfefa443cf4528f18ed3c2e9bd18945949884702b1c8f95c34224e857138cc7b4f278d4369f512b1f591561ab817c5d795cb4d56b9f17895fde",
    "79752ad80132ad3cdeab0db2fff3c0c5f3b898550293c57429b8b410c6be676bf5d2ce4292827ec55feb2220a3",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 14536U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.03040509264));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_info.c) */
