/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_input_info.c
 *
 * Code generation for function 'EOM_input'
 *
 */

/* Include files */
#include "_coder_EOM_input_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[4] = {
    "789c6360f4f465646060e0638000033608cd0bc4ef8112025071260654802ecf8885fe5b8f50cfcac0c2f0a71ea20f260fd2df0fe527e7e795a4569440387989"
    "b9a9709d29f9b99979897925219505a90c45a9c5f93965a9296099b4cc9cd490ccdcd460648e1f8897eb862405e780a4406ce78cd4e4ece0d25c86a28c62840b",
    "739039e0f000b92f01c9bf20ffc0fccb82253c90e5d101231a1f5ddd48b1ef0499f6c1cc4f27601f4c3e3a34d6d94a3fb438b5a8583fb9b4b8243f37b548dfd7"
    "d5ddb1b8322f59df233125533fc437c4a5324fdf393f2515ca8e4f4a2d49d42f338df7492c492d2e890f03eacecccf8b77ad48cc2dc8492dd64fcdcfd52f059a",
    "195f905854ac979b5842301cf989f4173a8d50cf01ce37e589d71991c311d9be3f04ecfb43867d774ef4cad1d33e181828fb2a7098872d5d62b34f0c877d0268"
    "f24e99396ea55585e11679895e991e89692699992696ae08770410b087903b1870f0696d3e0029e196c5",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 1608U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_input"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM_input.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.03040509264));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_input_info.c) */
