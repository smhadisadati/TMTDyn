/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_info.c
 *
 * Code generation for function 'EOM'
 *
 */

/* Include files */
#include "_coder_EOM_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[9] = {
    "789ced9bdf6fd25014c73bb34db34cddd3fe01dfd4ac83c1c6742fe347c77eb02d50e6c02c50da8b14da5ba02d944ddd9fa0ff866f7b34f1c125c6c4f8e49bc6"
    "47e3bbc6e79908853b70a1e9b2ca9dbbf43cd09e9c7bfbbde79cf2c9cd255023abb1118aa26e516d3b0ab4af373bfe54e77a8dfadbcec6473ad7891efff76177",
    "fc18354a9d1c76e7b5e23f9a1f2f3a3eaf400d185adb819c0c4e670a8a2c420e6a6ca30ca82a5015a9060433921725c08a3248f43a9b2d4f667a42a74e2bd4ba"
    "0f15005f4ae832552da8dd154abd8e598f9fcdf51df7e4dbca07e53bdaa71ebd71548fcc191fd954673c8a3f8eec851ed0491554559ad7554d9141958e455696",
    "d506e4e9282788341b63c30d4887140174ee3339a07174cd9fd9e034a06a999de66c51819988c1c96509a83450643ab2159b914ff3293bcc67d2261f14179aab"
    "934521a36aa0dc5bcfac43fd714bfd7173bcaa55755eebea7d70a857b0c917c507d7bfde4acec87675bc7dcebcce5ebbe36f98df5366f2b319eaa77762a37772",
    "013dfeb9670da71eb2cbd2332c9ed7efbdeca7376da187de4b141783465ccbad2d2742955d79ae918eae97a037d25dc7b68d8edd3a280b1fd7f38f2de69fb78e"
    "ff1b9fb30ef319b3cc67cccc275fcc9418cafebd3faf9e1d8f0545cf49a03f8f2fa2c759eab5fb85e283eb9759c166c7da868b1f4f39bc3cbefbf55316a71e32",
    "d2799c630275251a2f84957265764d0835a265560db93c2695c7767c6cd2a426305797c7394bbd76bf507ca03c6e56100199541ebf515e6771ea21239dc7861e"
    "4d4299c947033a80be00ac28f54a8971793cc43c16a1cb63673c6e5690741ebf2fdce170ea21239dc771859dad338fbc5ba1e84261c1b7bcb6a8ef7a822e8f49",
    "e5b1dd79055bcce8ee7985937e991524febc62fafb92cb63eadff358e71bc55d6814f5749e0d2c7aaba95995a9bbfb6362796cc747995355c67375797cf9fbe3"
    "760571ef8feb98791c3ed8fb85530f19e93cae708b8b1280fbab6ca9169d5fadb1db731ecedd1f0f378fbd2e8f1df2d88b9bc706661ebffd32b184530f19e93c",
    "9652c1f5744a0d7bfdfb05b9b8bdfcc45b0c04ddfdf170f378cee5b1431ecfe1e6f101661e3f7bf7f1154e3d64a4f3783fbc0037b8d974b9bc2bf15b3bc57c5c"
    "4eeb2e8f879bc73e97c70e79ec23fdf7bcfbdf8e2238f59091ce637f7e2391db8ce9fba9643cb56e24d590b1e55b71794c2a8faf5be673ddcc475238a175807c",
    "5579cc5beab5fb85e283eb57a7821d2093cae397f71e6671ea21239dc7f3ec4e24bc50d8d4603a2f8a3c0c7afc259e80ff83fc01edec1fc9",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 14536U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\TMTDyn\\Code\\TMTDyn_beta\\v5_Latest_Version_Examples\\eom\\EOM.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738322.05974537041));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_info.c) */
