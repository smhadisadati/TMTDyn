/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: loadsF1.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 14-Oct-2020 22:53:18
 */

#ifndef LOADSF1_H
#define LOADSF1_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "EOM_types.h"

/* Function Declarations */
extern void loadsF1(const double in1[58], const double in2[64], double out1[192],
                    double out2[6]);

#endif

/*
 * File trailer for loadsF1.h
 *
 * [EOF]
 */
