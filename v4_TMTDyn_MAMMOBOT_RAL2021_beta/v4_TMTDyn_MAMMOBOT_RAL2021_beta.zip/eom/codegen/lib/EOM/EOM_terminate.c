/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: EOM_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 14-Oct-2020 22:53:18
 */

/* Include Files */
#include "EOM.h"
#include "EOM_input.h"
#include "EOM_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void EOM_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for EOM_terminate.c
 *
 * [EOF]
 */
