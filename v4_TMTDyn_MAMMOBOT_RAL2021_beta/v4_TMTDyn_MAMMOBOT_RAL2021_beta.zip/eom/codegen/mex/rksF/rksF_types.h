/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rksF_types.h
 *
 * Code generation for function 'rksF'
 *
 */

#ifndef RKSF_TYPES_H
#define RKSF_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (rksF_types.h) */
