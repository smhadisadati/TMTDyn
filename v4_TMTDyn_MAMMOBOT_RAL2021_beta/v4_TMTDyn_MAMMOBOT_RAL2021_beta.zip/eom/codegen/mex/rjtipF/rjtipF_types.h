/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rjtipF_types.h
 *
 * Code generation for function 'rjtipF'
 *
 */

#ifndef RJTIPF_TYPES_H
#define RJTIPF_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (rjtipF_types.h) */
