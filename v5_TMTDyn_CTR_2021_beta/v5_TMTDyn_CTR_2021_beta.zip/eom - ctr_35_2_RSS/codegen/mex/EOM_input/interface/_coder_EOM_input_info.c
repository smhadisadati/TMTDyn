/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_input_info.c
 *
 * Code generation for function 'EOM_input'
 *
 */

/* Include files */
#include "_coder_EOM_input_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[4] = {
    "789c6360f4f465646060e0638000033608cd0bc42a4c0c0c025071260654802ecf8885fe5f8f50cfcac002e6f322c983f4f743f9c9f97925a91525104e5e626e"
    "2a5c674a7e6e665e625e494865412a43516a717e4e596a0a58262d332735243337351899e307e2e5ba2149c139202910db392335393bb83497a128a318e1c21c",
    "640e383c40ee4b40f22fc8fd30ffb260090f647974c088c647573752ec3b41a67d30f31309d807938f0e8d75b6d20f2d4e2d2ad64f2e2d2ec9cf4d2dd2f77575"
    "772caecc4bd6f7484cc9d40fc82f2e49c94fd6378af776f6019241a9c5a98945c919fa467a0abef929a939face21410a21be212e9579faa9f9b9faa540d3e20b",
    "128b8af572134bd0fc9580c3ddfc44fa0b9d46a8e700abff247a9d919ef6b59ec809a4a77d303050f655e0308fd8742986c33e013479a30c5fa392a8c0dcaae2"
    "1497c070a702b3901c634b27843b0208d843c81d0c38f8b4361f00504c8741", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 1608U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM_input"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\Postdoc\\2_KCL\\2_Research\\2. Model\\CTR TMTDyn\\eom\\EOM_input.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738225.88486111106));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_input_info.c) */
