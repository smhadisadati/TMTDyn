/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_EOM_info.c
 *
 * Code generation for function 'EOM'
 *
 */

/* Include files */
#include "_coder_EOM_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[11] = {
    "789ced9b4b8b235514c7aba5c7f7682b8c4b19c4ad53797612c1455e95f7fbd1e9b49a54aa2aa94aead5f54857e2c29520b8f04bb870e7464637c22028e84274"
    "a32e45410654f41b68924a75d2c5841af2b863dfdcb348f5e15fa9ff3de7841f979b0e7690ca1d6018f61c66c63fa7e6f5e63c3f9a5f1fc3ae865d3f7840feef",
    "bb8bfb6f6087b3fce692feeae4a11fce734a1235c6d0cc442405e6f29db4247022296ad591cc600aa34afc90a1674a97e3992a273095e5243fcd046249ba4ca6"
    "d2f4ef28cb50838a2e600aab2e56c82f27b37e4cd7776fa9dee9faadfa0e1fd08f65ddeac7a92db7e2c8a69fc5df8abe8ed7544651714a57354960143c174f84",
    "d59148e14992e6f0a2a46ab444e19e56269a9dbc96199521158ac53d776ee7249ae1f168b57cbb9aabc64622ce48021e2fe4ee08b67ae40deb79d6a11e4ba747"
    "624be0e896aa31f2b27f7b43ffc757fa9b8aaa293aa52dfcbedfd04fb0e5f67a2d7d17f3d3274f6b511345c597db399ba9533f9f7fc8faecd7c5fd4fceee7fff",
    "931f671228bf574a7ffc0ad2cf8a47e567ac78dec37e3e5f5ae17764d3e3a54a49cfc7bb896c3953a48ca4bfd8cde6138b75141d7c9cd681adc8413dffde8af7"
    "5f574eb737ace7c6ca7a4ca5db6f0d882dfa39719996f40ecf6c6f5e672bfdaeeabb98d7ac77f38981e2c6dfb77e02cae1377eab7c06d2cf0ad8391c62ea9e74",
    "3ec2c7754267998140f3744221108761e5b01317272c19d2c4f5e5f09b2bfdaeea3be2f0a477e6c860e5f0e1d97dc4616cfb1c56ce8da4908d444822dd34623c"
    "9f610b4a0eed87f799c39c8838bc2e8727bd839bc3bfbcf329e230b67d0ed7d2898c568e0ef4ac566a18a12e25fbfc29b41f8696c34ee712d57e4b47e712ebcd",
    "6bd63bc8cf253ef8fc3bc4616cfb1c3ea7c383cef0a47b42b815bd56e244af5a231087a1e5f0a12d5fd4632a8a2410dbf403cde1e64abfabfa2ee635ed9d3530"
    "50dcf81330875ff8e1b5bb20fdac809dc32157b8376e8aec393be648a912f0f80354019d4b40cb61272e0aa4aa12eeebcbe147792e61f60eecb904680efffcb6",
    "1bed87b1ed735812dca3dc71a01ecf93fd2227f71b31da5588210eef35873d88c36b73d80337878fb9bb5f81f4b302760e5f506c957765628a76da6583ba5c20"
    "65b91e471cde6b0e7b1187d7e6b0176e0e477e6f7c09d2cf0ad839ecf2695243c9fa0c3f330eb8839d41d4e0ebe85c62bf39ec431c5e9bc33eb839fcde134f7f",
    "0dd2cf0ad8395c1e050c62e82dd545aa775e0b51f98a5aeaa2fdf07e73d88f38bc3687fd707338c753df80f4b302760ee705a93272957a792994320c8df33714"
    "8145ff2ff1bfe5b0bc613d4f39d463e9aaacd0824c78fc36fff686fea0b9dc72a8d7d27731bfcb1e4ea6088a237f01e67229acd641fa59013d97b5c6c09f19f7",
    "52c9215d08f40c5e2a363b88cb88cb73a61cdbfcdb1bfaef23978f21e6f28b610fe232b67d2eb3aa142dfadc29434bb34332e1920bb9512289b88cb86c322560"
    "f36f6fe8bf8f5c0e00e432e8df7d789ef9d607d2cf0ad8b9cca76bbdc8b0510b9fe61b62586e52a49019a2f364c4e539538236fff686fefbc8e520c4fbe5cec7",
    "5f3440fa59715db97c6b85df914d674f2a7d5f9e0b36bd44a096ac87ebb1468fc4109711974da6846cfeed0dfdf791cb2188f7cbc2472fa3df8560dbdf2feb4c"
    "89cc5c04ab17e5f438e2e993d15e8882e17bbfff00ef323a21", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 23048U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\Postdoc\\2_KCL\\2_Research\\2. Model\\CTR TMTDyn\\eom\\EOM.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738225.88486111106));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_EOM_info.c) */
