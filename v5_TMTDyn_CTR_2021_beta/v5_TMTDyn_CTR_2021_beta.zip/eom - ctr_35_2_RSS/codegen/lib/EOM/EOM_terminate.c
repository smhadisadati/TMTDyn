/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: EOM_terminate.c
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 10-Mar-2021 22:46:32
 */

/* Include Files */
#include "EOM_terminate.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void EOM_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for EOM_terminate.c
 *
 * [EOF]
 */
