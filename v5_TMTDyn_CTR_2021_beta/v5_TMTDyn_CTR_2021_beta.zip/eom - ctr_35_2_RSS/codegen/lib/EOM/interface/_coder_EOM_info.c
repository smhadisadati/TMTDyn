/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_EOM_info.c
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 10-Mar-2021 22:46:32
 */

/* Include Files */
#include "_coder_EOM_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[12] = {
    "789ced9c4b6fe35414c75dd4e15de88086050854b1a779344f24167939691ece3b4d5320716c2776e257fd489db2608584c4822fc1821d1b34b0411a21818005"
    "820d20560824843483f808439ac44d6a617994c71d7a73cfa2eed13ff6ff9e739a9fae6e9b625b87b92d0cc39ec126b1d79c5c77a6f9eef4fa087635acfad6f4",
    "7a732ebfffeeecf537b0ed71be33a7bf387ae887d39c92448d31b4492292027379272d099c488a5a65283398c2a8123f60e8b1d2e178a6c2094c793e212e3201"
    "9f932e930be9e2fb18cb50fdb22e600aabce56c8cf27e37ebc345adf9db97a2fd66fd6bbfd1ffd98d7cd7e1c5b7233762dfa49e2add8ebaeaaca28aa8bd2554d",
    "1218c5954b2423ea50a45c2992e65c0549d5688972799b995876f4b5c4a80ca950accbbbbf9793688677c52aa5bd4aae121f8a2e46125c897c6e5fb0d4232f59"
    "cfd30ef5983a3d149b024737558d91e7fd5b4bfa3f6aeb3f51544dd1296de6f7c3927e8225b7d66beaeb989f3e7a5a931a29aa6bbe9de3993af5f3d907accf7a",
    "9dbdfef1f1ebdfffe4a7b104caefd5e2dddf41fa99f1b0fc0c9be73de8cfe70b367ebb163d512c177522d149664b990265a4fc854e9648ced65170f0715a0766"
    "93837afe1d9bfbaf2ba75b4bd673c3b69e89d2e935fbf80afd9cb84c4b7a9b675637af135bbfabfa3ae635eedd7462a0b8f1cfad9f8172f88d3fca9f81f43303",
    "760e87999a374d44f9848eeb2cd317689e4e2a38e230ac1c76e2e28825031abfbe1c7ed3d6efaabe260e8f7a371919ac1cde3ef90b71185b3d879553232564a3"
    "51124f378c38cf67d8bc9243fbe14de63027220e2fcae151efe0e6f06fef7c8a388cad9ec3d57432a395627d3dab15eb46b843c93eff21da0f43cb61a773894a",
    "afa9a37389c5e635ee1de4e7121f7cfe3de230b67a0e9fd2917e7b70d439c23d8a5e2d72e2815ac51187a1e5f0b6259fd533511449c057e9079ac30d5bbfabfa"
    "3ae675d13b7360a0b8710f30876ffef8da6d907e66c0cee1b03bd23d6f88ec297bce915239e8f507a93c3a978096c34e5c144855c53dd797c30ff35c62d23bb0",
    "e712a039fccbdb1eb41fc656cf6149f00c7381602d4190bd0227f7ea71da9d8f230e6f3487bd88c30b73d80b378703dcedaf40fa99013b87cf28b6c2bb337145"
    "3beeb0215dce93b25c4b200e6f34870f108717e6f001dc1c8efe59ff12a49f19b073d8edd3a4ba92f5197ee63ce809b5fb3183afa17389cde6b00f7178610efb",
    "e0e6f07b8f3df935483f3360e770691834f0c141b12652ddd36a9822ca6ab183f6c39bcd613fe2f0c21cf6c3cde11c4f7d0bd2cf0cd8394c085279e82e760929"
    "7c68181ae7af2b028bfe5ee27fcb6179c97a9e70a8c7d45559a10519f7fa2dfead25fd4173b9e950afa9af637e973d1c4d111447fe06cce56244ad81f433037a",
    "2e6bf5be3f73de3d4c0de87cb06bf052a1d1465c465c9e322560f16f2de9bf895c0e40cce5e7225ec4656cf55c66552956f0790e0d2dcd0ec8a45bcee786c914"
    "e232e2f28429418b7f6b49ff4de472102097417feec3fbd4773e907e66c0ce653e5ded4607f56ae498a88b11b94191426680ce931197a74c0959fc5b4bfa6f22",
    "974310ef97db1f7f5107e967c675e5f22d1bbf5d8bce1e957b3e820b350ef06035558bd4e2f52e89212e232e4f9812b6f8b796f4df442e8721de2f0b1fbd823e"
    "1782ad7ebfac3345327316aa9c95d2e7516f8f8c75c3144cbff76bd9dcefd4476bd8f571d3fcbe59d0cf7c3ee9e067ea27d535fdff619954d47d81d42c75b56c",
    "d6bdaaf7f77dc0bcdcf9f5f99741fa99013b2f0beeaab77c1ca8ca0139968b481c41b48d50f4faf3f25f42899030",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 24376U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  const char_T *propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 2, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 3);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("EOM"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(3.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (3.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\Postdoc\\2_KCL\\2_Research\\2. Model\\CTR TMTDyn\\eom\\EOM.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (738225.94846064819));
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 1, "Name", emlrtMxCreateString("EOM_input"));
  emlrtSetField(xEntryPoints, 1, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 1, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (4.0));
  emlrtSetField(xEntryPoints, 1, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 1, "FullPath", emlrtMxCreateString(
    "C:\\Users\\customer\\MEGAsync\\Hadi\\Postdoc\\2_KCL\\2_Research\\2. Model\\CTR TMTDyn\\eom\\EOM_input.m"));
  emlrtSetField(xEntryPoints, 1, "TimeStamp", emlrtMxCreateDoubleScalar
                (738225.94846064819));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.9.0.1570001 (R2020b) Update 4"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_EOM_info.c
 *
 * [EOF]
 */
