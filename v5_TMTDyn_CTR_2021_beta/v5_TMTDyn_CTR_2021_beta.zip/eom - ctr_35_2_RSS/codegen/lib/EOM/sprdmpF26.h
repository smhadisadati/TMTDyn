/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: sprdmpF26.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 10-Mar-2021 22:46:32
 */

#ifndef SPRDMPF26_H
#define SPRDMPF26_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>
#ifdef __cplusplus

extern "C" {

#endif

  /* Function Declarations */
  void sprdmpF26(const double in1[60], const double in2[48], double s, double
                 out1[144], double out2[6], double out3[6], double out4[6],
                 double *out6);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for sprdmpF26.h
 *
 * [EOF]
 */
