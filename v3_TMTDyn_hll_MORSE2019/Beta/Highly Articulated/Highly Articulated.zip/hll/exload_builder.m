classdef exload_builder < handle
    
    properties (GetAccess = public, SetAccess=private)
        source;
        name;
		template;
        
        exbody_val ;
        refbody_val ;
        transformations ;
        force_val ;
        moment_val ;
        ftau_val ;        
    end

    properties (GetAccess = public, SetAccess=public)
        pipe;
        i_t = 0 ; % transformation counter
        i_S = 1;
    end
    
    methods
        function self = exload_builder(source, name)
            self.source = source;
            self.name = name;
			self.template = source.template;
			self.pipe = source.template.exload;
        end
        
        function self = exbody( self, exbody_val )
            self.exbody_val = exbody_val ;
            self.pipe.exbody = exbody_val;
            self.i_S = self.i_S + 1;
        end
        
        function self = refbody( self, refbody_val )
            self.refbody_val = refbody_val ;
            self.pipe.refbody = refbody_val;
            self.i_S = self.i_S + 1;
        end
        
        function transformation = with_transformation( self )
            self.i_t = self.i_t + 1 ;
            transformation = transformation_builder(self, 1);
            self.transformations{self.i_t} = transformation ;
            self.i_S = self.i_S + 1;
        end
        
        function self = force( self, force_val )
            self.force_val = force_val ;
            self.pipe.ftau(:,1:3) = force_val;
            self.i_S = self.i_S + 1;
        end
        
        function self = moment( self, moment_val )
            self.moment_val = moment_val ;
            self.pipe.ftau(:,4:6) = moment_val;
            self.i_S = self.i_S + 1;
        end
        
        function varargout = subsref (self, S)
            try
                [varargout{1:nargout}] = builtin('subsref', self, S);
            catch e
                if ~ strcmp (e.identifier, 'MATLAB:noSuchMethodOrField')
                    rethrow(e)
                end
                e.message
            	self.source.pipe.exload(self.source.i_l) = self.pipe;
				self.source.i_S = 1 ; % reset i_S of the source object
                [varargout{1:nargout}] = builtin('subsref', self.source, S(2*self.i_S-1:end));
            end
        end
        
    end
end
