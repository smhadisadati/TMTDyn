function dydt = BallodeFcn(t,y)
dydt = [y(2); -9.8];