function [alpham,betam,alphan,betan,alphah,betah] = alphabeta(Vm)

  global VT ...
         am1 am2 am3 am4 am5 ...
         bm1 bm2 bm3 bm4 bm5 ...
         an1 an2 an3 an4 an5 ...
         bn1 bn2 bn3         ...
         ah1 ah2 ah3         ...
         bh1 bh2 bh3 bh4        
             
  alpham  =  am1*(Vm-VT+am2)/(exp(-(Vm-VT+am3)/am4)+am5);
  betam   =  bm1*(Vm-VT+bm2)/(exp((Vm-VT+bm3)/bm4)+bm5);
  alphan  =  an1*(Vm-VT+an2)/(exp(-(Vm-VT+an3)/an4)+an5);
  betan   =  bn1*exp(-(Vm-VT+bn2)/bn3);
  alphah  =  ah1*exp(-(Vm-VT+ah2)/ah3);
  betah   =  bh1/(bh2+exp(-(Vm-VT+bh3)/bh4));     
  
  % J'ai essay� les deux versions de calcul pour alpha et beta
  % pour m'assurer que les versions fortran et octave sont identiques
  % ce qui est le cas.
%   on  = 1;
%   off = 0;
%   alpham0 = abfunc(Vm,-VT*am1+am1*am2,am1,am5,on,-am4,am3-VT);
%   betam0  = abfunc(Vm,-VT*bm1+bm1*bm2,bm1,bm5,on,bm4,bm3-VT);
%   alphan0 = abfunc(Vm,-VT*an1+an1*an2,an1,an5,on,-an4,an3-VT);
%   betan0  = abfunc(Vm,on,off,off,1/bn1,bn3,bn2-VT);
%   alphah0 = abfunc(Vm,on,off,off,1/ah1,ah3,ah2-VT);
%   betah0  = abfunc(Vm,bh1,off,bh2,on,-bh4,bh3-VT);     
%   max(abs( alpham  - alpham0))
%   max(abs( betam   - betam0))
%   max(abs( alphan  - alphan0))
%   max(abs( betan   - betan0 ))
%   max(abs( alphah  - alphah0 ))
%   max(abs( betah   - betah0)) 
%   pause
end 
%   
% function  abf = abfunc(Vm,AA,BB,CC,HH,FF,DD)      
%   abf = (AA+BB*Vm)/(CC+HH*exp((Vm+DD)/FF));
% end
 





