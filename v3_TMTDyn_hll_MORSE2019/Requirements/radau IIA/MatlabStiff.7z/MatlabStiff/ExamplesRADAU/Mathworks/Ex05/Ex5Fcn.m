function yp = Ex5Fcn(t,y,OdeCoeff)
%  This is the two phase plug flow problem from E. Hairer, Ch. Lubich,
%  and M. Roche, The Numerical Solution of Differential-Algebraic Systems 
%  by Runge-Kutta Methods, Lecture Notes in Math. #1409, Springer, Berlin,
%  1989, specifically the normal flow example.  There are two algebraic 
%  variables.  The variables of HLR correspond to those used here as follows:
%     P <--> y(1), u <--> y(2), y <--> y(3). 
% Copyright 2004, The MathWorks, Inc.
% ---------------------------
% See
%    E. Hairer S.P. Norsett G. Wanner
%    Solving Ordinary Differential Equations I
%    Nonstiff Problems
%    Springer Verlag
%    ISBN 3-540-17145-2, ISBN 0-387-17145-2
%    
%    E. Hairer G. Wanner
%    Solving Ordinary Differential Equations II
%    Stiff and Differential-Algebraic Problems
%    Springer Verlag
%    ISBN 3-540-53775-9 ISBN 0-387-53775-9
%    
%    E. Hairer C. Lubich M. Roche, 
%    The Numerical Solution of Differential-Algebraic Systems 
%    by Runge-Kutta Methods. 
%    Lecture Notes in Mathematics, Vol. 1409, Springer-Verlag 1989. 
%    
% See also http://www.unige.ch/~hairer/software.html
% ---------------------------
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
%   Denis Bichsel
%   Rue des Deurres 58
%   2000 Neuch�tel
%   Suisse
%   dbichsel@infomaniak.ch
%   End of 2015
% ---------------------------

R        = OdeCoeff{1};
rho      = OdeCoeff{2};
mu       = OdeCoeff{3};
b        = OdeCoeff{4};
Qco      = OdeCoeff{5};
Qa       = OdeCoeff{6};
y0(1)    = OdeCoeff{7};
    
temp1 = pi*sqrt(0.5*R/rho);
temp2 = sqrt(0.5*R*rho);
temp3 = log(temp2 * (y(3)/mu) * y(2) - 5);
  
yp    = zeros(3,1);
yp(1) = - y(2)^2;
yp(2) = temp1*(R - y(3))^2 * y(2) * (2.5*temp3 + 10.5) ...
        - b*Qco - (y0(1)/y(1)) * Qco * (1 - b);
    
yp(3) = 2*temp1*y(2)*((2.5*R*y(3) - 1.25*y(3)^2)* ...
        temp3 + 3*R*y(3) - 2.125*y(3)^2 - 13.6*R*mu/(temp2*y(2))) - Qa;
   