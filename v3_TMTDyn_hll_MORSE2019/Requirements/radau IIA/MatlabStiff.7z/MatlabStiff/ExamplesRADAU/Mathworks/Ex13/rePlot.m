function stop = rePlot(t,y,Flag)
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
%   Denis Bichsel
%   Rue des Deurres 58
%   2000 Neuch�tel
%   Suisse
%   dbichsel@infomaniak.ch
%   End of 2015
% ---------------------------

stop = false;
if strcmp(Flag,'init')
  feval('odeplot',t,y,'init');
elseif strcmp(Flag,'')    
  feval('odeplot',t,y);
elseif strcmp(Flag,'done')
  feval('odeplot',[],[],'done');
end
axis([0 40 0 40])
grid on
% if t > 10 
%   stop = true
% end