function stop = E13WriteToFile(t,y,Flag)
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
%   Denis Bichsel
%   Rue des Deurres 58
%   2000 Neuch�tel
%   Suisse
%   dbichsel@infomaniak.ch
%   End of 2015
% ---------------------------
stop = false;
persistent fileout

if strcmp(Flag,'init')
  FileName = 'Ex13Result.txt';
  fileout = fopen(FileName,'w');  
  fprintf(fileout,'  %18.16e',t(1));
  for l = 1:length(y)
    fprintf(fileout,'  %18.16e',y(l));
  end
  fprintf(fileout,'\r\n');
elseif strcmp(Flag,'') 
  fprintf(fileout,'  %18.16e',t);
  for l = 1:size(y,2)
    fprintf(fileout,'  %18.16e',y(l));
  end 
  fprintf(fileout,'\r\n');
elseif strcmp(Flag,'done')
  fclose(fileout);
end

