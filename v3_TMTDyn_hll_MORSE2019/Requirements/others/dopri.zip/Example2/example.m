opt=[];
opt.RelTol=1e-6;opt.AbsTol=1e-6;
opt.OutputFcn=@odeplot;
opt.OutputCallMode=2;
figure(1);
[tNodes,xNodes,stats]=dopri5Mex(inline('x','t','x'),linspace(0,3,500),1,opt);

figure(2);
[tNodes,xNodes,stats]=dop853Mex(inline('x','t','x'),linspace(0,3,500),1,opt);