opt=[];
opt.RelTol=1e-6;opt.AbsTol=1e-6;

figure(1);
[tNodes,xNodes,stats]=dopri5Mex(@f,[0,3],1,opt);
% also possible (auch möglich):
% [tNodes,xNodes,stats]=dopri5Mex('f',[0,3],1,opt);
% [tNodes,xNodes,stats]=dopri5Mex(inline('x','t','x'),[0,3],1,opt);

t=linspace(0,3,200);
plot(t,exp(t),'b-',tNodes,xNodes,'rx');

figure(2);
[tNodes,xNodes,stats]=dop853Mex(@f,[0,3],1,opt);
t=linspace(0,3,200);
plot(t,exp(t),'b-',tNodes,xNodes,'rx');
