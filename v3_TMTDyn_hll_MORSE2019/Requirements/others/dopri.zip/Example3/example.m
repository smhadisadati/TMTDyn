opt=[];
opt.RelTol=1e-10;opt.AbsTol=1e-10;
opt.OutputFcn=@outputfcn;
opt.OutputCallMode=3;
figure(1);
[tNodes,xNodes,stats]=dopri5Mex(inline('x','t','x'),[0,1.5,100],1,opt);
