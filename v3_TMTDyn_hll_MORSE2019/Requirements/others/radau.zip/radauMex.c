/*
 * RADAUMEX-Interface von C. Ludwig
 * Version: $Id: radauMex.c 1195 2013-07-16 21:49:58Z luchr $ */
#define RADAUMexVersion "16. July 2013"
/*
 * 
 * Fragen, Wünsche, Probleme, Anregungen, 
 * Anmerkungen, Bemerkungen und Bugs an
 *  ludwig@ma.tum.de
 */
#include <math.h>
#include "mex.h"
#include "string.h"
#include "options.h"
#include "radauMex.h"

#define Fabs(i) (i>0?(i):(-i))
#define FMTS "%" FMT_SIZE_T "u"
#define MPR mexPrintf

static SOptionSettings optSet;
static SParameterIO paramIO;
static SParameterGlobal paramGlobal;
static SParameterRadau paramRadau;
static SParameterRightSide paramRightSide;
static SParameterMassmatrix paramMassmatrix;
static SParameterJacobimatrix paramJacobimatrix;
static SParameterOutput paramOutput;

static char ismxArrayString (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  if (mxIsChar(arr)) return (char)1;
  return (char)0;
}

static char ismxArrayFunction (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (mxGetClassID(arr)==mxFUNCTION_CLASS)?(char)1:(char)0;
}

static char ismxArrayInline (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (strcmp(mxGetClassName(arr),"inline")==0)?(char)1:(char)0;
}

static void clearList (PListElement current) {
  PListElement next;
  
  while (current!=NULL) {
    next=current->next;
    if (current->values!=NULL)
      {mxFree(current->values);current->values=NULL;}
    mxFree(current);
    current=next;
  }
}

static void initVars (void) {
  /* IO parameters */
  paramIO.opt=NULL;paramIO.optCreated=0;  

  /* Option settings */
  optSet.warnMiss=0;optSet.warnType=1;optSet.warnSize=1;   
  
  /* global parameters */
  paramGlobal.tPointer=NULL;
  
  /* parameters for Radau */
  paramRadau.xStart=NULL;
  paramRadau.RTOL=NULL;paramRadau.ATOL=NULL;
  paramRadau.WORK=NULL;paramRadau.IWORK=NULL;
  paramRadau.RPAR=NULL;paramRadau.IPAR=NULL;
  
  /* parameters for rightside */
  paramRightSide.rightSideFcn=NULL;
  paramRightSide.rightSideFcnH=NULL;
  paramRightSide.tArg=NULL;paramRightSide.xArg=NULL;
  
  /* parameters for mass */
  paramMassmatrix.radauMASFunc=NULL;
  
  /* parameters for jacobi */
  paramJacobimatrix.jacFcn=NULL;
  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.tArg=NULL;paramJacobimatrix.xArg=NULL;
  paramJacobimatrix.radauJACFunc=NULL;
  
  /* output parameters */
  paramOutput.txList.values=NULL;
  paramOutput.txList.next=NULL;
  paramOutput.lastTXElement=&paramOutput.txList;
  paramOutput.numberOfElements=0;
  paramOutput.outputFcn=NULL;
  paramOutput.outputFcnH=NULL;
  paramOutput.tArg=NULL;
  paramOutput.xArg=NULL;
}

static void doneVars (void) {
  /* IO parameters */
  if ((paramIO.optCreated) && (paramIO.opt!=NULL)) 
    {mxDestroyArray((mxArray*)paramIO.opt);paramIO.opt=NULL;}    
  
  /* global parameters */
  /* tPointer darf auf keinen Fall */
  /* freigegeben werden, er gehört dem Aufrufer */
    
  /* parameters for Radau */
  if (paramRadau.xStart!=NULL)
    {mxFree(paramRadau.xStart);paramRadau.xStart=NULL;}
  if (paramRadau.RTOL!=NULL)
    {mxFree(paramRadau.RTOL);paramRadau.RTOL=NULL;}
  if (paramRadau.ATOL!=NULL)
    {mxFree(paramRadau.ATOL);paramRadau.ATOL=NULL;}
  if (paramRadau.WORK!=NULL)
    {mxFree(paramRadau.WORK);paramRadau.WORK=NULL;}
  if (paramRadau.IWORK!=NULL)
    {mxFree(paramRadau.IWORK);paramRadau.IWORK=NULL;}
  if (paramRadau.RPAR!=NULL)
    {mxFree(paramRadau.RPAR);paramRadau.RPAR=NULL;}
  if (paramRadau.IPAR!=NULL)
    {mxFree(paramRadau.IPAR);paramRadau.IPAR=NULL;}
    
  /* parameters for right side */
  if (paramRightSide.rightSideFcn!=NULL)
    {mxFree(paramRightSide.rightSideFcn);paramRightSide.rightSideFcn=NULL;}
  paramRightSide.rightSideFcnH=NULL; /* gehört Aufrufer => nicht freigeben */
  if (paramRightSide.tArg!=NULL)
    {mxDestroyArray(paramRightSide.tArg);paramRightSide.tArg=NULL;}
  if (paramRightSide.xArg!=NULL)
    {mxDestroyArray(paramRightSide.xArg);paramRightSide.xArg=NULL;}
  
  /* parameters for jacobi */
  if (paramJacobimatrix.jacFcn!=NULL)
    {mxFree(paramJacobimatrix.jacFcn);paramJacobimatrix.jacFcn=NULL;}
  paramJacobimatrix.jacFcnH=NULL; /* gehört Aufrufer => nicht freigeben */
  if (paramJacobimatrix.tArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.tArg);paramJacobimatrix.tArg=NULL;}
  if (paramJacobimatrix.xArg!=NULL)
    {mxDestroyArray(paramJacobimatrix.xArg);paramJacobimatrix.xArg=NULL;}
  
  /* output parameters */
  clearList(paramOutput.txList.next);paramOutput.txList.next=NULL;
  if (paramOutput.outputFcn!=NULL)
    {mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;}
  paramOutput.outputFcnH=NULL; /* gehört Aufrufer => nicht freigeben */
  if (paramOutput.tArg!=NULL)
    {mxDestroyArray(paramOutput.tArg);paramOutput.tArg=NULL;}
  if (paramOutput.xArg!=NULL)
    {mxDestroyArray(paramOutput.xArg);paramOutput.xArg=NULL;}
}

static void stopMexFunction (int errNo,
  size_t i1, size_t i2, size_t i3, size_t i4, size_t i5, long l1, long l2, double d1) {
  const char *msg;
  size_t d;
  
  mexPrintf("Error (%i) [Version: %s]:\n",errNo,RADAUMexVersion);
  mexPrintf("Fehler (%i) [Version: %s]:\n",errNo,RADAUMexVersion);
  d = (size_t)paramGlobal.d;
  switch (errNo) {
    #include "errors.c"      
    default: msg="unknown error number (Unbekannte Fehlernummer)";break;
  }
  
  doneVars();
  mexErrMsgTxt(msg);
}

static void stopMexFunction0 (int errNo) {
  stopMexFunction(errNo,0,0,0,0,0,0,0,0);
}
static void stopMexFunctionI1 (int errNo, size_t i1) {
  stopMexFunction(errNo,i1,0,0,0,0,0,0,0);
}
static void stopMexFunctionI2 (int errNo, size_t i1, size_t i2) {
  stopMexFunction(errNo,i1,i2,0,0,0,0,0,0);
}
static void stopMexFunctionI3 (int errNo, size_t i1, size_t i2, size_t i3) {
  stopMexFunction(errNo,i1,i2,i3,0,0,0,0,0);
}
static void stopMexFunctionI4 (int errNo, size_t i1, size_t i2, size_t i3, size_t i4) {
  stopMexFunction(errNo,i1,i2,i3,i4,0,0,0,0);
}
static void stopMexFunctionI5 (int errNo, size_t i1, size_t i2, size_t i3, size_t i4, size_t i5) {
  stopMexFunction(errNo,i1,i2,i3,i4,i5,0,0,0);
}
static void stopMexFunctionL1 (int errNo, long l1) {
  stopMexFunction(errNo,0,0,0,0,0,l1,0,0);
}
static void stopMexFunctionL2 (int errNo, long l1, long l2) {
  stopMexFunction(errNo,0,0,0,0,0,l1,l2,0);
}
static void stopMexFunctionD1 (int errNo, double d1) {
  stopMexFunction(errNo,0,0,0,0,0,0,0,d1);
}


static void addTXtoList (double t, double *x) {
  double* dpointer;
  PListElement target;
  
  target=(PListElement)mxMalloc(sizeof(SListElement));
  target->next=NULL;paramOutput.lastTXElement->next=target;
  paramOutput.lastTXElement=target;paramOutput.numberOfElements++;
  target->values=(double*)mxMalloc((size_t)(paramGlobal.d+1)*sizeof(double));
  dpointer=target->values;
  *dpointer=t;dpointer++;
  memcpy(dpointer,x,(size_t)paramGlobal.d*sizeof(double));
}

static void checkNumberOfArgs (int nlhs, int nrhs) {
  if ((nlhs<2) || (nlhs>4)) stopMexFunctionI1(1,(size_t)nlhs);
  if ((nrhs!=3) && (nrhs!=4)) stopMexFunctionI1(2,(size_t)nrhs);
}

static void processArgs (int nrhs, const mxArray* prhs[])
{
  size_t len;
  mwSize buflen;
  double *dpointer;
  
  /* 1st arg: right side */
  if (ismxArrayString(prhs[0])) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1))
      stopMexFunctionI2(4,(size_t)mxGetNumberOfDimensions(prhs[0]),mxGetM(prhs[0]));

    paramRightSide.rightSideFcn=mxArrayToString(prhs[0]);
    paramRightSide.rightSideFcnH=prhs[0]; 
  } else 
  if ( (ismxArrayFunction(prhs[0])) || (ismxArrayInline(prhs[0])) ) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1) ||
        (mxGetN(prhs[0])!=1))
      stopMexFunctionI3(21,(size_t)mxGetNumberOfDimensions(prhs[0]),
                      mxGetM(prhs[0]),mxGetN(prhs[0]));
    paramRightSide.rightSideFcn=NULL; /* kein String */
    paramRightSide.rightSideFcnH=prhs[0];
  } else {
    stopMexFunction0(3);
  }

  /* 2nd arg: row-vector containing time-values */
  if (!mxIsDouble(prhs[1])) stopMexFunction0(5);
  if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxGetM(prhs[1])!=1))
    stopMexFunctionI2(6,(size_t)mxGetNumberOfDimensions(prhs[1]),mxGetM(prhs[1]));
  len=mxGetN(prhs[1]);
  if (!tif_fits_st_in_mws(len)) stopMexFunctionI2(29,len,(size_t)MWSIZE_MAX);
  paramGlobal.tLength=tif_st2mws(len);
  if (paramGlobal.tLength<2) stopMexFunction0(7);
  if (paramGlobal.tLength>2) {
    paramRadau.denseFlag=1; 
  } else {
    paramRadau.denseFlag=0;
  }
  dpointer=mxGetPr(prhs[1]);paramGlobal.tPointer=dpointer;
  paramRadau.tStart=dpointer[0];
  paramRadau.tEnd=dpointer[paramGlobal.tLength-1];
  if (paramRadau.tStart==paramRadau.tEnd) stopMexFunction0(12);
  paramGlobal.direction=(paramRadau.tEnd-paramRadau.tStart)>0?1.0:-1.0;
  for (buflen=1; buflen<paramGlobal.tLength; buflen++,dpointer++)
    if (paramGlobal.direction*(dpointer[0]-dpointer[1])>0)
      stopMexFunctionD1(14,paramGlobal.direction);
  
  /* 3rd arg: start vector */
  if (!mxIsDouble(prhs[2])) stopMexFunction0(8);
  if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetN(prhs[2])!=1))
    stopMexFunctionI2(9,(size_t)mxGetNumberOfDimensions(prhs[2]),mxGetN(prhs[2]));
  len=mxGetM(prhs[2]);
  if (!tif_fits_st_in_mws(len)) stopMexFunctionI2(28,len,(size_t)MWSIZE_MAX);
  paramGlobal.d=tif_st2mws(len);
  if (paramGlobal.d<1) stopMexFunction0(10);
  dpointer=mxGetPr(prhs[2]);
  paramRadau.xStart=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
  memcpy(paramRadau.xStart,dpointer,(size_t)paramGlobal.d*sizeof(double));
  /* little remark: A COPY of the startvector is made, because
     it will be passed to Fortran code. To be sure, that
     it will not be changed there, a copy will be passed.
     x0 belongs to the caller and it is not allowed 
     (due to Matlab-Contract) to change it. */
  /* kleine Anmerkung: der Startvektor wird KOPIERT, da er an den 
     Fortran code weitergegeben wird. Um ganz sicher zu gehen,
     dass er nicht verändert wird, wird eine Kopie übergeben.
     x0 gehört ja dem Aufrufer und darf nach Matlab-Konvention
     nicht verändert werden. */
  
  /* 4th arg: struct with options */
  if (nrhs==4) {
    if (!mxIsStruct(prhs[3])) stopMexFunction0(11);
    paramIO.opt=prhs[3];paramIO.optCreated=0;
  } else {
    paramIO.opt=mxCreateStructMatrix(1,1,0,NULL);
    paramIO.optCreated=1;
  }
}

static void extractOptionSettings (void) {
  optSet.warnMiss=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNMISS,0);
  optSet.warnType=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNTYPE,1);
  optSet.warnSize=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNSIZE,1);
}

static void extractHandTOLs (void) {
  size_t len1,len2;
  mwSize m1,n1,m2,n2;
  char res1,res2;
  int takeScalar;
  
  paramRadau.h=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_INITIALSS,1e-6);
  
  res1=opt_getSizeOfOptField(paramIO.opt,OPT_RTOL,&len1,&len2);
  if (!tif_fits_st_in_mws(len1)) stopMexFunctionI1(26,len1);
  if (!tif_fits_st_in_mws(len2)) stopMexFunctionI1(26,len2);
  m1=tif_st2mws(len1); n1=tif_st2mws(len2);

  res2=opt_getSizeOfOptField(paramIO.opt,OPT_ATOL,&len1,&len2);
  if (!tif_fits_st_in_mws(len1)) stopMexFunctionI1(27,len1);
  if (!tif_fits_st_in_mws(len2)) stopMexFunctionI1(27,len2);
  m2=tif_st2mws(len1); n2=tif_st2mws(len2);

  takeScalar=0;
  if (((res1!=0) || (res2!=0)) ||
      ((res1==0) && (m1==1)) ||
      ((res2==0) && (m2==1))) {
    takeScalar=1; 
  } else {
    if ((n1!=1) || (n2!=1)) takeScalar=1;
    if (m1!=m2) takeScalar=1;
    if (m1!=paramGlobal.d) takeScalar=1;
  }

  if (takeScalar) {
    paramRadau.RTOL=(double*)mxMalloc(1*sizeof(double));
    paramRadau.ATOL=(double*)mxMalloc(1*sizeof(double));
    *paramRadau.RTOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RTOL,1e-3);
    *paramRadau.ATOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ATOL,1e-6);
    paramRadau.ITOL=0;
  } else {
    paramRadau.RTOL=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
    paramRadau.ATOL=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_RTOL,
      (size_t)paramGlobal.d,1,paramRadau.RTOL);
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_ATOL,
      (size_t)paramGlobal.d,1,paramRadau.ATOL);
    paramRadau.ITOL=1;
  }
}

static void extractOutput (void) {
  mxArray *arr;

  if (paramRadau.denseFlag) {
    paramOutput.includeGrid=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_IGPIDO,0);
  }

  paramOutput.outputFcnH=NULL;paramOutput.outputFcn=NULL;
  arr=mxGetField(paramIO.opt,0,OPT_OUTPUTFUNCTION);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1))
        stopMexFunctionI3(401,(size_t)mxGetNumberOfDimensions(arr),
                        mxGetM(arr),mxGetN(arr));
      paramOutput.outputFcnH=arr;
    } else {
      paramOutput.outputFcn=opt_getStringFromOpt(paramIO.opt,&optSet,
        OPT_OUTPUTFUNCTION,NULL);
      if (paramOutput.outputFcn!=NULL) {
        if (strlen(paramOutput.outputFcn)==0) {
          mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;
        } else {
          paramOutput.outputFcnH=arr;
        }
      }
    }
  }
  
  paramOutput.outputCallMode=1;
  if ((paramOutput.outputFcnH!=NULL) && (paramRadau.denseFlag)) {
    paramOutput.outputCallMode=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_OUTPUTCALLMODE,1);
    if ((paramOutput.outputCallMode<1) || (paramOutput.outputCallMode>3))
      paramOutput.outputCallMode=1;
  }
}

static void extractGlobalOptions (void) {
  paramGlobal.funcCallMethod=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_FUNCCALLMETHOD,1);
  switch (paramGlobal.funcCallMethod) {
    case 0: /* use maxCallMATLAB direct */
      if (paramRightSide.rightSideFcn==NULL) stopMexFunction0(22);
      if ((paramOutput.outputFcnH!=NULL) && (paramOutput.outputFcn==NULL))
        stopMexFunction0(23);
      if ((paramJacobimatrix.jacFcnH!=NULL) && 
          (paramJacobimatrix.jacFcn==NULL)) 
        stopMexFunction0(24);
      break;
    case 1: /* use mexCallMATLAB to call feval */
      break;
    default:
      stopMexFunction0(25);
      break;
  }
}

static void extractOptionsPart1 (void) {
  extractOptionSettings();
  extractHandTOLs();
  extractOutput();  
  /* extractGlobalOptions später; erst wenn Jacobi-Param eingelesen */
}

static void extractMassMatrix (void) {
  mxArray *mField;
  Fint m1,d;
  size_t m,n,len;
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  m1=paramRadau.IWORK[9-1];
  
  if ((mField==NULL) || (mxIsEmpty(mField))) {
    /* Massenmatrix=Id */
    paramMassmatrix.IMAS=0;paramMassmatrix.MLMAS=0;
    paramMassmatrix.radauMASFunc=NULL;
    return;
  }
  
  if (paramRadau.IWORK[1-1]!=0) stopMexFunction0(18);
  paramMassmatrix.IMAS=1; 
  d=tif_mws2Fint(paramGlobal.d);
  paramMassmatrix.MLMAS=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MASSLBAND,d-m1);
  paramMassmatrix.MUMAS=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MASSUBAND,d-m1);
  if ((paramMassmatrix.MLMAS<0) || (paramMassmatrix.MUMAS<0) || 
      (paramMassmatrix.MLMAS>d-m1) || (paramMassmatrix.MUMAS>d-m1))
    stopMexFunctionI1(110,(size_t)m1);
    
  if (paramMassmatrix.MLMAS==d-m1) { 
    /* Massmatrix is full or fullbutlowerright */
    if (!mxIsDouble(mField)) stopMexFunctionI2(101,(size_t)paramGlobal.d,(size_t)m1);
    if (mxGetNumberOfDimensions(mField)!=2) stopMexFunction0(102);
    m=mxGetM(mField);n=mxGetN(mField);
    if (m!=n) stopMexFunctionI2(103,m,n);
    if (m!=(size_t)paramGlobal.d-(size_t)m1) stopMexFunctionI2(104,m,(size_t)m1);
    if (m1>0)
      paramMassmatrix.radauMASFunc=RadauMASFullLRFunc; else
      paramMassmatrix.radauMASFunc=RadauMASFullFunc;
  } else { 
    /* Massmatrix is banded or bandedbutlowerright */
    if ((!mxIsDouble(mField)) && (!mxIsCell(mField)))      
      stopMexFunctionI2(105,(size_t)paramMassmatrix.MLMAS,(size_t)m1);
    if (m1==0) { 
      /* Massmatrix is banded */
      if (mxIsDouble(mField)) {
        len=(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=len) || (mxGetN(mField)!=(size_t)paramGlobal.d))
          stopMexFunctionI2(106,mxGetM(mField),mxGetN(mField));
        paramMassmatrix.radauMASFunc=RadauMASBandedMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=1) || (mxGetN(mField)!=len))
          stopMexFunctionI2(107,mxGetM(mField),mxGetN(mField));
        paramMassmatrix.radauMASFunc=RadauMASBandedCellFunc;
      }      
    } else { 
      /* Massmatrix is bandedbutlowerright */
      if (mxIsDouble(mField)) {
        len=(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=len) || (mxGetN(mField)!=(size_t)(d-m1)))
          stopMexFunctionI2(108,mxGetM(mField),mxGetN(mField));
        paramMassmatrix.radauMASFunc=RadauMASBandedLRMatrixFunc;
      }
      if (mxIsCell(mField)) {
        len=(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS);
        if ((mxGetNumberOfDimensions(mField)!=2) ||
            (mxGetM(mField)!=1) || (mxGetN(mField)!=len))
          stopMexFunctionI2(109,mxGetM(mField),mxGetN(mField));
        paramMassmatrix.radauMASFunc=RadauMASBandedLRCellFunc;
      }
    }
  }
}

static void extractJacobiMatrix (void) {
  Fint m1,m2,d;
  mxArray *arr;

  paramJacobimatrix.jacFcnH=NULL;
  paramJacobimatrix.jacFcn=NULL;

  arr=mxGetField(paramIO.opt,0,OPT_JACOBIMATRIX);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if (ismxArrayString(arr)) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1)) 
        stopMexFunctionI2(225,(size_t)mxGetNumberOfDimensions(arr),mxGetM(arr));
      paramJacobimatrix.jacFcn=mxArrayToString(arr);
      paramJacobimatrix.jacFcnH=arr;
    } else
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1)) 
        stopMexFunctionI3(226,(size_t)mxGetNumberOfDimensions(arr),mxGetM(arr),mxGetN(arr));
      paramJacobimatrix.jacFcn=NULL; /* kein String */
      paramJacobimatrix.jacFcnH=arr;
    } else {
      stopMexFunction0(227);
    }
  }

  m1=paramRadau.IWORK[9-1];m2=paramRadau.IWORK[10-1];
  d=tif_mws2Fint(paramGlobal.d);
  
  paramJacobimatrix.IJAC=(paramJacobimatrix.jacFcnH==NULL)?0:1;
  paramJacobimatrix.MLJAC=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_JACOBILBAND,d-m1);
  paramJacobimatrix.MUJAC=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_JACOBIUBAND,0);
  
  if ((paramJacobimatrix.MLJAC<0) ||
      (paramJacobimatrix.MUJAC<0) || 
      (paramJacobimatrix.MLJAC>d-m1) ||
      (paramJacobimatrix.MUJAC>d-m1))
    stopMexFunctionI2(201,(size_t)paramGlobal.d,(size_t)m1);
  
  if (m1>0) {
    if (paramRadau.IWORK[1-1]!=0) stopMexFunction0(19);
    if (paramJacobimatrix.MLJAC==d-m1) {
      paramJacobimatrix.radauJACFunc=RadauJACFullLFunc; 
    } else {      
      if (m1+m2!=d) stopMexFunction0(202);
      if ((paramJacobimatrix.MLJAC>m2) || (paramJacobimatrix.MUJAC>m2))      
        stopMexFunction0(203);
      paramJacobimatrix.radauJACFunc=RadauJACBandedLFunc;
    }
  } else {
    if (paramJacobimatrix.MLJAC==d-m1) {
      paramJacobimatrix.radauJACFunc=RadauJACFullFunc; 
    } else {
      if (paramRadau.IWORK[1-1]!=0) stopMexFunction0(20);
      paramJacobimatrix.radauJACFunc=RadauJACBandedFunc;
    }
  }      
}

static void extractOptionsPart2 (void) {
  extractMassMatrix();
  extractJacobiMatrix();
  if (paramMassmatrix.MLMAS>paramJacobimatrix.MLJAC)
    stopMexFunctionI2(16,(size_t)paramMassmatrix.MLMAS,(size_t)paramJacobimatrix.MLJAC);
  extractGlobalOptions();
}

static void prepareIWORKArray (void) {
  Fint i,d,m1,m2;
  Fint nsmax;

  d=tif_mws2Fint(paramGlobal.d);
  paramRadau.IOUT=1;

  /* first get nsmax then we can calculate how much
     memory is needed */
  nsmax=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_NSMAX,7);
  if ((nsmax!=1) && (nsmax!=3) && (nsmax!=5) && (nsmax!=7)) 
    stopMexFunctionI1(522,(size_t)nsmax);

  /* IWORK */
  paramRadau.LIWORK=  (2+(nsmax-1)/2)*d+20;
  paramRadau.IWORK=(Fint*)mxMalloc((size_t)paramRadau.LIWORK*sizeof(Fint));
  
  /* Std-Values */
  for (i=1-1; i<=20-1; i++) paramRadau.IWORK[i]=0;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_TRANSJTOH,0);
  if ((i!=0) && (i!=1)) stopMexFunctionL1(502,i);
  paramRadau.IWORK[1-1]=i;
    
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MAXSTEPS,100000);
  if (i<=0) stopMexFunctionL1(503,i);
  paramRadau.IWORK[2-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MAXNEWTONITER,7);
  if (i<=0) stopMexFunctionL1(504,i);
  paramRadau.IWORK[3-1]=i;  
    
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_NEWTONSTARTSWITCH,0);
  paramRadau.IWORK[4-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND1VAR,d);
  if ((i<=0) || (i>d)) stopMexFunctionL1(505,i);
  paramRadau.IWORK[5-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND2VAR,0);
  if (i<0) stopMexFunctionL1(506,i);
  paramRadau.IWORK[6-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_DIMOFIND3VAR,0);
  if (i<0) stopMexFunctionL1(507,i);
  paramRadau.IWORK[7-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_STEPSIZESTRATEGY,1);
  if ((i!=1) && (i!=2)) stopMexFunctionL1(508,i);
  paramRadau.IWORK[8-1]=i;
  
  m1=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_M1,0);
  m2=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_M2,0);
  if ((m1<0) || (m2<0)) stopMexFunction0(509);
  if (m1+m2>d) stopMexFunctionL2(510,m1,m2);
  if (((m1==0) && (m2!=0)) || ((m1!=0) && (m2==0)))
    stopMexFunctionL2(511,m1,m2);
  if (m2!=0) {
    if (m1%m2!=0) stopMexFunctionL2(512,m1,m2);
    paramRadau.mm=m1/m2;
  }
  paramRadau.IWORK[9-1]=m1;
  paramRadau.IWORK[10-1]=m2;

  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_NSMIN,3);
  if ((i!=1) && (i!=3) && (i!=5) && (i!=7)) 
    stopMexFunctionL1(523,i);
  if (i>nsmax) stopMexFunctionL2(524,i,nsmax);
  paramRadau.IWORK[11-1]=i;

  paramRadau.IWORK[12-1]=nsmax;  /* see above */
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_NSFIRST,paramRadau.IWORK[11-1]);
  if ((i!=1) && (i!=3) && (i!=5) && (i!=7)) 
    stopMexFunctionL1(525,i);
  if ((i<paramRadau.IWORK[11-1]) || (i>paramRadau.IWORK[12-1])) 
    stopMexFunctionL1(526,i);
  paramRadau.IWORK[13-1]=i;
}

static void prepareWORKArray (void) {
  Fint i,ljac,lmas,le,d,m1,nsmax;
  double dValue;
  
  d=tif_mws2Fint(paramGlobal.d);m1=paramRadau.IWORK[9-1];nsmax=paramRadau.IWORK[12-1];
  if (m1>0) { 
    /* mit Spezialstruktur */
    /* ljac */
    if (paramJacobimatrix.MLJAC==d-m1) {
      ljac=d-m1; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d-m1) {
        lmas=d-m1; 
      } else {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le */
    if (paramJacobimatrix.MLJAC==d-m1) {
      le=d; 
    } else {
      le=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
    
    paramRadau.LWORK=d*(ljac+3*nsmax+3)+(d-m1)*(lmas+nsmax*le)+20;
    paramRadau.WORK=(double*)mxMalloc((size_t)paramRadau.LWORK*sizeof(double));
  } else { 
    /* keine Spezialstruktur */
    /* ljac */
    if (paramJacobimatrix.MLJAC==d) {
      ljac=d; 
    } else {
      ljac=1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
      
    /* lmas */
    if (paramMassmatrix.IMAS==0) {
      lmas=0; 
    } else {
      if (paramMassmatrix.MLMAS==d) {
        lmas=d; 
      } else {
        lmas=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
      }
    }
    
    /* le */
    if (paramJacobimatrix.MLJAC==d) {
      le=d; 
    } else {
      le=1+2*paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC;
    }
    
    paramRadau.LWORK=d*(ljac+lmas+nsmax*le+3*nsmax+3)+20;
    paramRadau.WORK=mxMalloc((size_t)paramRadau.LWORK*sizeof(double));
  } 
  
  /* std-Values */
  for (i=1-1; i<=20-1; i++) paramRadau.WORK[i]=0.0;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_EPS,1.0e-16);
  if (!((dValue>1e-19) && (dValue<1.0))) stopMexFunctionD1(513,dValue);
  paramRadau.WORK[1-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RHO,0.9);
  if (!(dValue>0)) stopMexFunctionD1(514,dValue);
  paramRadau.WORK[2-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_JACRECOMPFACTOR,0.001);
  paramRadau.WORK[3-1]=dValue;  
    
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_FREEZESSLEFT,1.0);
  if (!((dValue<=1.0) && (dValue>=0.0))) stopMexFunctionD1(517,dValue);
  paramRadau.WORK[5-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_FREEZESSRIGHT,1.2);
  if (!(dValue>=1.0)) stopMexFunctionD1(518,dValue);
  paramRadau.WORK[6-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_MAXSS,
    paramRadau.tEnd-paramRadau.tStart);
  if (!(dValue!=0.0)) stopMexFunctionD1(519,dValue);
  paramRadau.WORK[7-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSMINSEL,0.2);
  if (!((dValue<=1.0) && (dValue>0.0))) stopMexFunctionD1(520,dValue);
  paramRadau.WORK[8-1]=dValue;
  
  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSMAXSEL,8.0);  
  if (!(dValue>=1.0)) stopMexFunctionD1(521,dValue);
  paramRadau.WORK[9-1]=dValue;

  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERINCFAC,0.002);
  if (!(dValue>=0.0)) stopMexFunctionD1(527,dValue);
  paramRadau.WORK[10-1]=dValue;

  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERDECFAC,0.8);
  if (!(dValue>=0.0)) stopMexFunctionD1(528,dValue);
  if (!(dValue>=paramRadau.WORK[10-1])) stopMexFunctionD1(529,dValue);
  paramRadau.WORK[11-1]=dValue;

  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERDECSSUFAC,1.2);
  if (!(dValue>=0.0)) stopMexFunctionD1(530,dValue);
  paramRadau.WORK[12-1]=dValue;

  dValue=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERDECSSLFAC,0.8);
  if (!(dValue>=0.0)) stopMexFunctionD1(531,dValue);
  if (!(paramRadau.WORK[12-1]>=dValue)) stopMexFunctionD1(532,dValue);
  paramRadau.WORK[13-1]=dValue;
}

static void prepareHelpMxArrays (void) {
  mwSize d;

  d=paramGlobal.d;
  
  paramRightSide.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
  paramRightSide.xArg=mxCreateDoubleMatrix(d,1,mxREAL);
  
  if ((paramOutput.outputFcnH!=NULL) || (paramRadau.denseFlag)) {
    paramOutput.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramOutput.xArg=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);    
  }
  
  if (paramJacobimatrix.IJAC!=0) {
    paramJacobimatrix.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramJacobimatrix.xArg=mxCreateDoubleMatrix(d,1,mxREAL);  
  }
}

static int callOutputFcn (int reason, double t, double *x, int doCopy) {
  int doPoint,erg,offset;
  double *dpointer;
  mxArray* rhs[4];
  mxArray* lhs[1];
    
  if (paramOutput.outputFcnH==NULL) return 0;
  doPoint=0;lhs[0]=NULL;erg=0;
  switch (reason) {
    case 1: /* Init-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction0(1002);break;
      }
      rhs[offset]=mxCreateDoubleMatrix(1,2,mxREAL);
      dpointer=mxGetPr(rhs[offset]);
      *dpointer=paramRadau.tStart;dpointer++;
      *dpointer=paramRadau.tEnd;
      offset++;
      
      rhs[offset]=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);
      memcpy(mxGetPr(rhs[offset]),paramRadau.xStart,(size_t)paramGlobal.d*sizeof(double));
      offset++;

      rhs[offset++]=mxCreateString("init");

      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction0(1002);break;
      }
      break;
    case 2: /* Done-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction0(1002);break;
      }
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateString("done");
      
      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction0(1002);break;
      }
      break;
    case 3: /* Neuer Grid-Punkt */
      if ((paramRadau.denseFlag) && (paramOutput.outputCallMode==1)) break;
      doPoint=1;
      break;
    case 4: /* Neuer dense-Punkt */
      if ((paramRadau.denseFlag) && (paramOutput.outputCallMode==2)) break;
      doPoint=1;
      break;
    case 5: /* Neuer dense und Grid-Punkt */
      doPoint=1;
      break;
    default: stopMexFunction0(1001);
  }
  
  if (doPoint) {
    *mxGetPr(paramOutput.tArg)=t;
    if (doCopy)
      memcpy(mxGetPr(paramOutput.xArg),x,(size_t)paramGlobal.d*sizeof(double));

    offset=0;
    switch (paramGlobal.funcCallMethod) {
      case 0: break;
      case 1:
        rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
        break;
      default: stopMexFunction0(1002);break;
    }
    rhs[offset++]=paramOutput.tArg;rhs[offset++]=paramOutput.xArg;
    
    switch (paramGlobal.funcCallMethod) {
      case 0:
        mexCallMATLAB(1,lhs,offset,rhs,paramOutput.outputFcn);
        break;
      case 1:
        mexCallMATLAB(1,lhs,offset,rhs,"feval");
        break;
      default: stopMexFunction0(1002);break;
    }

    if (lhs[0]==NULL) {
      erg=0; 
    } else {
      erg=(int)mxGetScalar(lhs[0]);
      mxDestroyArray(lhs[0]);
    }
  }

  return erg;
}

void RadauRightSideFunc (Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar) {
  Fint i,d,m1,m2;
  int offset;
  mxArray *rhs[3];
  mxArray *lhs[1];

  (void)rpar; (void)ipar;
  
  d=*n;lhs[0]=NULL;

  /* Call by value */
  /* Use always the SAME Matlab tArg and xArg */
  /* IMPORTANT NOTICE (if the right side is also a MEX-File)
     the right side must not "garble" the passed mxArrays:
     the size must not be changed and the memory must not
     be freed. 
     Hence: the right side has to take care, that the
     passed mxArrays have the same size and enough memory
     when returning. The values in the memory(-block)
     may be overwritten.
     If the right side is an m-file MATLAB obeys this
     restriction automatically. */
  /* WICHTIGE Anmerkung (falls rechte Seite auch MEX-File ist)
     die rechte Seite darf die übergebenen mxArrays nicht
     "verstümmeln": die Größe darf nicht verändert werden
     und auch der Speicherplatz darf nicht freigegeben werden.
     Also: die rechte Seite muss sicherstellen, dass die
     übergebenen mxArrays am Ende wieder diesselbe Größe
     und ausreichend Speicher haben. Der Speicher selbst
     darf natürlich zu rechenzwecken überschrieben werden.
     Bei m-Files achtet MATLAB automatisch darauf.
  */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramRightSide.rightSideFcnH;
      break;
    default: stopMexFunction0(1002);
  }
  rhs[offset]=paramRightSide.tArg;*mxGetPr(rhs[offset])= *t;
  offset++;

  rhs[offset]=paramRightSide.xArg;
  memcpy(mxGetPr(rhs[offset]),x,(size_t)d*sizeof(double));
  offset++;   
  
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramRightSide.rightSideFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction0(1002);break;
  }
  
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction0(301);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction0(302);
  m1=paramRadau.IWORK[9-1];m2=paramRadau.IWORK[10-1];
  if (m1==0) { 
    /* keine Spezialstruktur */
    if (!(((mxGetM(lhs[0])==(size_t)d) && (mxGetN(lhs[0])==1)) ||
          ((mxGetM(lhs[0])==1) && (mxGetN(lhs[0])==(size_t)d))))
      stopMexFunctionI2(303,mxGetM(lhs[0]),mxGetN(lhs[0]));
    
    /* copy back */
    memcpy(f,mxGetPr(lhs[0]),(size_t)d*sizeof(double));
  } else { 
    /* mit Spezialstruktur */
    if (!(((mxGetM(lhs[0])==(size_t)(d-m1)) && (mxGetN(lhs[0])==1)) ||
          ((mxGetM(lhs[0])==1) && (mxGetN(lhs[0])==(size_t)(d-m1)))))
      stopMexFunctionI2(304,mxGetM(lhs[0]),mxGetN(lhs[0]));  
      
    /* Spezialstruktur eintragen: */
    for (i=0; i<m1; i++,f++) *f=x[i+m2];
    
    /* der Rest */
    memcpy(f,mxGetPr(lhs[0]),(size_t)(d-m1)*sizeof(double));
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);  
}

void RadauSoloutFunc (Fint *nr, double *told,
  double *t, double *x, double *cont, Fint *lrc, 
  Fint *n,	
  double *rpar, Fint *ipar, Fint *irtrn) {
  Fint i,erg,ilast;
  double *dpointer;
  double tdense;
  int alreadySaved;

  (void)n; (void)told; (void)rpar; (void)ipar;
  
  if (*nr==1) paramOutput.tPos=0;
  
  erg=0;
  if (paramRadau.denseFlag) {
    alreadySaved=0;
    while (1) {
      if (paramOutput.tPos>=paramGlobal.tLength) break;
      tdense=paramGlobal.tPointer[paramOutput.tPos];
      if (tdense==*t) {
        addTXtoList(*t,x);paramOutput.tPos++;
        alreadySaved=1;
        erg=callOutputFcn(5,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
        if (erg==1) {erg=-1;break;} /* Stop, NOW */
        continue;
      }
      if (paramGlobal.direction*(tdense-(*t))>0) break;
      
      dpointer=mxGetPr(paramOutput.xArg);
      
      ilast=tif_mws2Fint(paramGlobal.d);
      for (i=1; i<=ilast; i++,dpointer++)
        *dpointer=CONTRA_ (&i,&tdense,cont,lrc);
        
      dpointer=mxGetPr(paramOutput.xArg);
      addTXtoList(tdense,dpointer);
      erg=callOutputFcn(4,tdense,dpointer,0);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;break;} /* Stop, NOW */
      
      paramOutput.tPos++;
    }
    if (!alreadySaved) {
      if (paramOutput.includeGrid) addTXtoList(*t,x);
      erg=callOutputFcn(3,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;} /* Stop, NOW */
    }
  } else {
    addTXtoList(*t,x);
    erg=callOutputFcn(3,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
    if (erg==1) {erg=-1;} /* Stop, NOW */
  }
  
  *irtrn=erg;
}
void RadauMASFullFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint d;

  (void)n; (void)lmas; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);

  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASFullFunc: m1!=0");
  mxAssert(*lmas==d,"internal error: RadauMASFullFunc: unexpected lmas");

  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe überprüft */
  memcpy(am,mxGetPr(mxGetField(paramIO.opt,0,OPT_MASSMATRIX)),
    (size_t)d*(size_t)d*sizeof(double));
}

void RadauMASFullLRFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint d,m1,len;

  (void)n; (void)lmas; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);m1=paramRadau.IWORK[9-1];len=d-m1;
  mxAssert(m1!=0,"internal error: RadauMASFullLRFunc: m1==0");
  mxAssert(*lmas==len,"internal error: RadauMASFullLRFunc: unexpected lmas");
  
  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe überprüft */
  memcpy(am,mxGetPr(mxGetField(paramIO.opt,0,OPT_MASSMATRIX)),
    (size_t)len*(size_t)len*sizeof(double));
}

void RadauMASBandedMatrixFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint d,len;
  mxArray *mField;

  (void)n; (void)lmas; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASBandedMatrixFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedMatrixFunc: enexpected lmas");
    
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe überprüft */
  memcpy(am,mxGetPr(mField),(size_t)len*(size_t)d*sizeof(double));
}

void RadauMASBandedCellFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint i,j,len,d;
  double *dpointer;
  mxArray *mField,*cellField;

  (void)n; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauMASBandedCellFunc: m1!=0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe des cells 
     überprüft, NCIHT aber der Typ/Dimension/Größe der cell-Einträge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,(mwIndex)(paramMassmatrix.MUMAS-i)); 
    len=d-Fabs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunctionI1(111,(size_t)(paramMassmatrix.MUMAS-i+1));
    if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=(size_t)len))
      stopMexFunctionI4(112,(size_t)(paramMassmatrix.MUMAS-i+1),
        mxGetM(cellField),mxGetN(cellField),(size_t)len);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }  
}

void RadauMASBandedLRMatrixFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint d,m1,len;
  mxArray *mField;

  (void)n; (void)lmas; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramRadau.IWORK[9-1];
  mxAssert(m1!=0,"internal error: RadauMASBandedMatrixFunc: m1==0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedMatrixFunc: enexpected lmas");
    
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe überprüft */
  
  memcpy(am,mxGetPr(mField),(size_t)len*(size_t)(d-m1)*sizeof(double));  
}

void RadauMASBandedLRCellFunc (Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar) {
  Fint i,j,m1,len,d;
  double *dpointer;
  mxArray *mField,*cellField;

  (void)n; (void)rpar; (void)ipar;
  
  d=tif_mws2Fint(paramGlobal.d);len=1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS;
  m1=paramRadau.IWORK[9-1];
  
  mxAssert(m1!=0,"internal error: RadauMASBandedLRCellFunc: m1==0");
  mxAssert(len==*lmas,"internal error: RadauMASBandedCellFunc: unexpected lmas");
  
  mField=mxGetField(paramIO.opt,0,OPT_MASSMATRIX);
  /* durch extractMassMatrix wurde schon Typ/Dimension/Größe des cells 
     überprüft, NCIHT aber der Typ/Dimension/Größe der cell-Einträge */
     
  for (i=paramMassmatrix.MUMAS; i>=-paramMassmatrix.MLMAS; i--) {
    /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
    cellField=mxGetCell(mField,(mwIndex)(paramMassmatrix.MUMAS-i)); 
    len=d-m1-Fabs(i);
    if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
        (mxGetNumberOfDimensions(cellField)!=2))
      stopMexFunctionI1(113,(size_t)(paramMassmatrix.MUMAS-i+1));
    if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=(size_t)len))
      stopMexFunctionI4(114,(size_t)(paramMassmatrix.MUMAS-i+1),
        mxGetM(cellField),mxGetN(cellField),(size_t)len);
    dpointer=mxGetPr(cellField);
    for (j=0; j<len; j++,dpointer++)
      am[paramMassmatrix.MUMAS+(j+(i>0?i:0))*(*lmas)-i]= *dpointer;
  }  
}

void RadauJACFullFunc (Fint *n, double *t,
  double *x, double *dfy, Fint *ldfy, double *rpar, Fint *ipar) {
  Fint d;
  int offset;
  mxArray *rhs[3],*lhs[1];

  (void)n; (void)ldfy; (void)rpar; (void)ipar;

  d=tif_mws2Fint(paramGlobal.d);lhs[0]=NULL;  
  
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauJACFullFunc: m1!=0");
  mxAssert(*ldfy==d,"internal error: RadauJACFullFunc: unexpected ldfy");      
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction0(1002);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,(size_t)d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction0(1002);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction0(204);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction0(205);
  if ((mxGetM(lhs[0])!=(size_t)d) || (mxGetN(lhs[0])!=(size_t)d))
    stopMexFunctionI2(206,mxGetM(lhs[0]),mxGetN(lhs[0]));
  
  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),(size_t)d*(size_t)d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACFullLFunc (Fint *n, double *t,
  double *x, double *dfy, Fint *ldfy, double *rpar, Fint *ipar) {
  Fint d,m1,len;
  int offset;
  mxArray *rhs[3],*lhs[1];

  (void)n; (void)ldfy; (void)rpar; (void)ipar;

  d=tif_mws2Fint(paramGlobal.d);m1=paramRadau.IWORK[9-1];lhs[0]=NULL;  
  len=d-m1;
  mxAssert(m1!=0,"internal error: RadauJACFullLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: RadauJACFullLFunc: unexpected ldfy");
    
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction0(1002);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,(size_t)d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction0(1002);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction0(204);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction0(207);
  if ((mxGetM(lhs[0])!=(size_t)len) || (mxGetN(lhs[0])!=(size_t)paramGlobal.d))
    stopMexFunctionI2(208,mxGetM(lhs[0]),mxGetN(lhs[0]));

  /* copy back */
  memcpy(dfy,mxGetPr(lhs[0]),(size_t)len*(size_t)paramGlobal.d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACBandedFunc (Fint *n, double *t,
  double *x, double *dfy, Fint *ldfy, double *rpar, Fint *ipar) {
  Fint i,j,d,len;
  int offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField;

  (void)rpar; (void)ipar; (void)n;

  d=tif_mws2Fint(paramGlobal.d);lhs[0]=NULL;  
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramRadau.IWORK[9-1]==0,"internal error: RadauJACBandedFunc: m1!=0");
  mxAssert(*ldfy==len,"internal error: RadauJACBandedFunc: unexpected ldfy");  
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction0(1002);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,(size_t)d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction0(1002);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction0(204);
  if ((!mxIsCell(lhs[0])) && (!mxIsDouble(lhs[0]))) stopMexFunction0(209);
  if (mxIsCell(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction0(224);
    if ((mxGetM(lhs[0])!=1) || (mxGetN(lhs[0])!=(size_t)len))
      stopMexFunctionI2(210,mxGetM(lhs[0]),mxGetN(lhs[0]));
    for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) {
      /* ACHTUNG: cells beginnen bei 0 mit der Indizierung */
      cellField=mxGetCell(lhs[0],(mwIndex)(paramJacobimatrix.MUJAC-i));
      len=d-Fabs(i);
      if ((cellField==NULL) || (!mxIsDouble(cellField)) || 
          (mxGetNumberOfDimensions(cellField)!=2))
        stopMexFunctionI1(211,(size_t)(paramJacobimatrix.MUJAC-i+1));
      if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=(size_t)len))
        stopMexFunctionI4(212,(size_t)(paramJacobimatrix.MUJAC-i+1),(size_t)len,
        mxGetM(cellField),mxGetN(cellField));
      dpointer=mxGetPr(cellField);
      for (j=0; j<len; j++,dpointer++)
        dfy[paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
    }
  }
  if (mxIsDouble(lhs[0])) {
    if (mxGetNumberOfDimensions(lhs[0])!=2) stopMexFunction0(213);
    if ((mxGetM(lhs[0])!=(size_t)len) || (mxGetN(lhs[0])!=(size_t)d))
      stopMexFunctionI2(214,mxGetM(lhs[0]),mxGetN(lhs[0]));
    memcpy(dfy,mxGetPr(lhs[0]),(size_t)len*(size_t)d*sizeof(double));
  }
    
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void RadauJACBandedLFunc (Fint *n, double *t,
  double *x, double *dfy, Fint *ldfy, double *rpar, Fint *ipar) {
  Fint i,j,k,d,m2,len;
  int offset;
  double *dpointer;
  mxArray *rhs[3],*lhs[1];
  mxArray *cellField,*innerField;

  (void)rpar; (void)ipar; (void)n;
  
  d=tif_mws2Fint(paramGlobal.d);lhs[0]=NULL;
  m2=paramRadau.IWORK[10-1];
  len=paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC+1;
  mxAssert(paramRadau.IWORK[9-1]!=0,"internal error: RadauJACBandedLFunc: m1==0");
  mxAssert(*ldfy==len,"internal error: RadauJACBandedLFunc: unexpected ldfy");
  
  /* Call by value */
  offset=0;
  switch (paramGlobal.funcCallMethod) {
    case 0: break;
    case 1:
      rhs[offset++]=(mxArray*)paramJacobimatrix.jacFcnH;
      break;
    default: stopMexFunction0(1002);
  }
  rhs[offset]=paramJacobimatrix.tArg;*mxGetPr(rhs[offset])=*t;
  offset++;

  rhs[offset]=paramJacobimatrix.xArg;
  memcpy(mxGetPr(rhs[offset]),x,(size_t)d*sizeof(double));
  offset++;
  
  /* Call User's jac function */
  switch (paramGlobal.funcCallMethod) {
    case 0:
      mexCallMATLAB(1,lhs,offset,rhs,paramJacobimatrix.jacFcn);
      break;
    case 1:
      mexCallMATLAB(1,lhs,offset,rhs,"feval");
      break;
    default: stopMexFunction0(1002);
  }
  
  /* check return value */
  if (lhs[0]==NULL) stopMexFunction0(204);
  if ((!mxIsCell(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2)) stopMexFunction0(215);
  if ((mxGetM(lhs[0])!=1) || (mxGetN(lhs[0])!=(size_t)paramRadau.mm+1))
    stopMexFunctionI2(216,mxGetM(lhs[0]),mxGetN(lhs[0]));
  for (k=0; k<paramRadau.mm+1; k++) { 
    /* Schleife über alle Teilmatrizen */
    cellField=mxGetCell(lhs[0],(size_t)k);
    if (cellField==NULL) stopMexFunctionI1(217,(size_t)k);
    if ((!mxIsDouble(cellField)) && (!mxIsCell(cellField)))
      stopMexFunctionI1(218,(size_t)k);
    if (mxGetNumberOfDimensions(cellField)!=2) stopMexFunctionI1(219,(size_t)k);
    if (mxIsDouble(cellField)) { 
      /* diese banded Teilmatrix wird als Matrix übergeben */
      if ((mxGetM(cellField)!=(size_t)len) || (mxGetN(cellField)!=(size_t)m2))
        stopMexFunctionI3(220,(size_t)k,mxGetM(cellField),mxGetN(cellField));
      memcpy(dfy+(k*(*ldfy)*m2),mxGetPr(cellField),(size_t)len*(size_t)m2*sizeof(double));
    }
    if (mxIsCell(cellField)) { 
      /* diese banded Teilmatrix wird als cell übergeben */
      if ((mxGetM(cellField)!=1) || (mxGetN(cellField)!=(size_t)len))
        stopMexFunctionI3(221,(size_t)k,mxGetM(cellField),mxGetN(cellField));
      for (i=paramJacobimatrix.MUJAC; i>=-paramJacobimatrix.MLJAC; i--) { 
        /* Schleife über alle diag-Vektoren */
        innerField=mxGetCell(cellField,(mwIndex)(paramJacobimatrix.MUJAC-i));
        if ((innerField==NULL) || (!mxIsDouble(innerField)) ||
            (mxGetNumberOfDimensions(innerField)!=2))
          stopMexFunctionI2(222,(size_t)k,(size_t)(paramJacobimatrix.MUJAC-i+1));
        len=m2-Fabs(i);
        if ((mxGetM(innerField)!=1) || (mxGetN(innerField)!=(size_t)len))
          stopMexFunctionI5(223,(size_t)k,(size_t)(paramJacobimatrix.MUJAC-i+1),(size_t)len,
          mxGetM(innerField),mxGetN(innerField));
        dpointer=mxGetPr(innerField);
        for (j=0; j<len; j++,dpointer++)
          dfy[k*(*ldfy)*m2+paramJacobimatrix.MUJAC+(j+(i>0?i:0))*(*ldfy)-i]= *dpointer;
      }
    }
  }
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

static void createTXArrays (mxArray* plhs[]) {
  mwSize i,d,count,n;
  PListElement current;
  double *tPointer, *xPointer, *vPointer;
  
  d=paramGlobal.d;n=paramOutput.numberOfElements;
  plhs[0]=mxCreateDoubleMatrix(n,1,mxREAL);
  plhs[1]=mxCreateDoubleMatrix(n,d,mxREAL);
  
  tPointer=mxGetPr(plhs[0]);
  xPointer=mxGetPr(plhs[1]);
  
  current=paramOutput.txList.next;
  count=0;
  while (current!=NULL) {
    vPointer=current->values;
    *tPointer= *vPointer; tPointer++; vPointer++;
    for (i=0; i<d; i++,vPointer++) xPointer[count+i*n]= *vPointer;
    
    current=current->next;count++;
  }
}

static void createStatVector (mxArray* plhs[]) {
  int i;
  double *dpointer;
  
  plhs[2]=mxCreateDoubleMatrix(1,8,mxREAL);
  dpointer=mxGetPr(plhs[2]);
  
  *dpointer=(double)paramRadau.IDID;dpointer++;
  for (i=14-1; i<=20-1; i++) {
    *dpointer=(double)paramRadau.IWORK[i];dpointer++;
  }
}

static void createHPred (mxArray* plhs[]) {
  plhs[3]=mxCreateDoubleMatrix(1,1,mxREAL);
  
  *mxGetPr(plhs[3])=paramRadau.h;
}

static void createOutput (int nlhs, mxArray* plhs[]) {
  createTXArrays(plhs);
  
  if (nlhs>=3) createStatVector(plhs);
  if (nlhs>=4) createHPred(plhs);
}

void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {
  Fint d;

  initVars();
  
  checkNumberOfArgs(nlhs,nrhs);
  processArgs(nrhs,prhs);
  
  extractOptionsPart1();  
  prepareIWORKArray();
  extractOptionsPart2();
  prepareWORKArray();
  prepareHelpMxArrays();
  
  d=tif_mws2Fint(paramGlobal.d);
  callOutputFcn(1,0.0,NULL,0);
  RADAU_(&d,&RadauRightSideFunc,
    &paramRadau.tStart,paramRadau.xStart,&paramRadau.tEnd,&paramRadau.h,
    paramRadau.RTOL,paramRadau.ATOL,&paramRadau.ITOL,
    paramJacobimatrix.radauJACFunc,&paramJacobimatrix.IJAC,
    &paramJacobimatrix.MLJAC,&paramJacobimatrix.MUJAC,
    paramMassmatrix.radauMASFunc,&paramMassmatrix.IMAS,
    &paramMassmatrix.MLMAS,&paramMassmatrix.MUMAS,
    &RadauSoloutFunc,&paramRadau.IOUT,
    paramRadau.WORK,&paramRadau.LWORK,
    paramRadau.IWORK,&paramRadau.LIWORK,
    paramRadau.RPAR,paramRadau.IPAR,&paramRadau.IDID);
  callOutputFcn(2,0.0,NULL,0);
  
  createOutput(nlhs,plhs);
  
  doneVars();
}
