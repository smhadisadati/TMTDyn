% Linking C and Fortran files
% Different compilers have different conventions:
% If you call a Fortran function "func" from C some compilers
% append an underscore (when compiling the Fortran file).
% Hence you have to append the underscore when calling: "func_".
% Some compilers need "FUNC_" and others "FUNC" and again others
% need "_FUNC" or "_func" or "_FUNC_" or "_func_".
%
% There are compile-time switches you can adapt the MEX-Interface 
% to your compiler:
%
%  FORTRANUPP: 
%    if set, all Fortran-routines are called with uppercase letters
%  FORTRANNOUNDER: 
%    if set, all Fortran-routines are called without a trailing underscore
%  FORTRANLEADUNDER:
%    if set, all Fortran-routines are called with a leading underscore
%
% The default: all switches are turned off:
%    lowercase with trailing underscore and without leading underscore
%
% Example:
% mex -DFORTRANUPP ...
% 
% When using
%    -largeArrayDims  
% be sure to use the right Fortran-Compiler options, e.g.
%    -fdefault-integer-8 for GNU Fortran compiler for largeArrayDims
%
% Here are two examples how radauMex is compiled
% for compatibleArrayDims and largeArrayDims 
% on a 64bit Fedora-Linux with GCC:
%
% ==== Example-Output for -compatibleArrayDims (gcc on Fedora Linux) 
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -DMX_COMPAT_32 -O -DNDEBUG  "radauMex.c"
% 
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -DMX_COMPAT_32 -O -DNDEBUG  "options.c"
% 
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -DMX_COMPAT_32 -O -DNDEBUG  "tif.c"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer  -DMX_COMPAT_32 -O  "radau.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer  -DMX_COMPAT_32 -O  "dc_lapack.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer  -DMX_COMPAT_32 -O  "lapack.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer  -DMX_COMPAT_32 -O  "lapackc.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer  -DMX_COMPAT_32 -O  "tif_test.f"
% 
% -> gfortran -O -pthread -shared -Wl,--version-script,/usr/local/share/matlabR2013a/extern/lib/glnxa64/mexFunction.map -Wl,--no-undefined -o  "radauMex.mexa64"  radauMex.o options.o tif.o radau.o dc_lapack.o lapack.o lapackc.o tif_test.o  -Wl,-rpath-link,/usr/local/share/matlabR2013a/bin/glnxa64 -L/usr/local/share/matlabR2013a/bin/glnxa64 -lmx -lmex -lmat -lm -lstdc++ -Wl,-rpath-link,/usr/local/share/matlabR2013a/bin/glnxa64 -L/usr/local/share/matlabR2013a/bin/glnxa64 -lmx -lmex -lmat -lm
% 
% ==== Example-Output for -largeArrayDims (gcc on Fedora Linux) 
%
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -O -DNDEBUG  "radauMex.c"
% 
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -O -DNDEBUG  "options.c"
% 
% -> gcc -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -DMATLAB_MEX_FILE -std=c99 -D_GNU_SOURCE  -fexceptions -fPIC -fno-omit-frame-pointer -pthread -Wall -Wextra -pedantic -Wmissing-prototypes -Wmissing-declarations -Wshadow -Wpointer-arith -Wcast-align -Wwrite-strings -Wredundant-decls -Wnested-externs -Winline -Wno-long-long -Wconversion -Wstrict-prototypes  -O -DNDEBUG  "tif.c"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -fdefault-integer-8  -O  "radau.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -fdefault-integer-8  -O  "dc_lapack.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -fdefault-integer-8  -O  "lapack.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -fdefault-integer-8  -O  "lapackc.f"
% 
% -> gfortran -c  -I/usr/local/share/matlabR2013a/extern/include -I/usr/local/share/matlabR2013a/simulink/include -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -fdefault-integer-8  -O  "tif_test.f"
% 
% -> gfortran -O -pthread -shared -Wl,--version-script,/usr/local/share/matlabR2013a/extern/lib/glnxa64/mexFunction.map -Wl,--no-undefined -o  "radauMex.mexa64"  radauMex.o options.o tif.o radau.o dc_lapack.o lapack.o lapackc.o tif_test.o  -Wl,-rpath-link,/usr/local/share/matlabR2013a/bin/glnxa64 -L/usr/local/share/matlabR2013a/bin/glnxa64 -lmx -lmex -lmat -lm -lstdc++ -Wl,-rpath-link,/usr/local/share/matlabR2013a/bin/glnxa64 -L/usr/local/share/matlabR2013a/bin/glnxa64 -lmx -lmex -lmat -lm
% 
mex radauMex.c options.c tif.c radau.f dc_lapack.f lapack.f lapackc.f tif_test.f

