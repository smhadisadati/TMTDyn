function dx=f(t,x)
% right side
dx=[x(2);x(1)];
