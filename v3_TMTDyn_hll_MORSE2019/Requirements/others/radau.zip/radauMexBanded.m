% English:
% ========
% RADAU5MEXBANDED: How to pass banded matrices
%
% This text gives additional help for radauMex. 
% Here it is described how banded matrices 
% are passed to radauMex.
%
% All definitions will be explained with the 
% following (4,4) matrix:
%
%   [ a   b   0   0 ]
%   [ c   d   e   0 ]
%   [ f   g   h   0 ]
%   [ 0   0   i   j ]
%
% Upper bandwidth U:
% ------------------
% U is the number of the last superdiagonal that is not 0.
% In our example we have U=1 because the (b,e,0) 
% superdiagonal is the last one above the diagonal 
% which is not 0.
%
% Lower bandwidth L:
% ------------------
% L is the number of the last subdiagonal that is not 0.
% In our example we have L=2 because the (f,0) 
% subdiagnonal is the last one below the diagonal
% which is not 0.
%
% Number of non-zero diagonals 
% ----------------------------
% A matrix with upper bandwidth U and lower bandwith L
% has 1+U+L non-zero diagnoals.
%
% Passing to RadauMex
% --------------------
% After telling radauMex that a matrix is banded
% there are two possibilities to pass such a banded matrix
% to radauMex. Let A bei a (d,d) matrix with upper and
% lower diagonal U and L, respectively. 
%
% 1. as (1+U+L,d) matrix
% "Here the diagonals are rotated by 45°" and written 
% in a matrix:
% In our example we have d=4, U=1, L=2 and the (4,4) matrix
% looks like this:
%   [ *  b  e  0 ]
%   [ a  d  h  j ]
%   [ c  g  i  * ]
%   [ f  0  *  * ]
% The values marked with "*" are values that aren't 
% relevant.
%
% 2. as cell
% Here a (1,1+U+L) cell is passed. Every cell entry
% is a vector containing the values on the diagonal.
% In our example: { [b,e,0], [a,d,h,j], [c,g,i], [f,0] }
%
% German:
% =======
% RADAUMEXBANDED: Eingabe von Matrizen mit Bandstruktur
%
% Dieser Text ist eine zusätzliche Hilfestellung zu radauMex.
% Hier wird beschrieben, wie man in radauMex Matrizen mit
% Bandstruktur übergeben kann.
%
% Alle Begriffe und Bezeichnungen werden anhand folgender
% (4,4) Beispielmatrix erklärt:
%
%   [ a   b   0   0 ]
%   [ c   d   e   0 ]
%   [ f   g   h   0 ]
%   [ 0   0   i   j ]
%
% Obere Bandbreite U:
% -------------------
% U bezeichne die letzte Superdiagonale, die nicht 0 ist.
% In unserem Beispiel ist U=1, denn das ist die letzte 
% Nebendiagonale (mit den Werten b,e,0) überhalb der 
% Hauptdiagonale.
% 
% Untere Bandbreite L:
% --------------------
% L bezeichne die letzte Subdiagonale, die nicht 0 ist.
% In unserem Beispiel ist L=2, denn das ist die letzte
% Nebendiagonale (mit den Werten f,0) unterhalb der 
% Hauptdiagonale.
%
% Anzahl der besetzten Diagonalen
% -------------------------------
% Eine Matrix mit oberer bzw. unterer Bandbreite U bzw. L 
% hat dann insgesamt 1+U+L besetzte Diagonalen.
%
% Übergabe an RadauMex
% ---------------------
% Hat man radauMex mitgeteilt, dass es sich um eine Matrix
% mit Bandstruktur handelt, so kennt radauMex zwei Möglichkeiten
% eine Matrix mit Bandstruktur zu übergeben. Sei A
% eine (d,d) Matrix mit oberer bzw. unterer Bandbreite U bzw. L.
% 
% 1. als (1+U+L,d)-Matrix
% "Hier werden die Diagonalen um 45° gedreht" und in eine
% Matrix geschrieben:
% In unserem Beispiel ist d=4, U=1, L=2 und die (4,4) Matrix
% sieht so aus:
%   [ *  b  e  0 ]
%   [ a  d  h  j ]
%   [ c  g  i  * ]
%   [ f  0  *  * ]
% Die "*" Werte sind dabei egal und können beliebig sein.
% (Natürlich spart man sich bei unserem Beispiel keinen 
% Speicherplatz.)
%
% 2. als cell 
% Hier wird eine (1,1+U+L) cell übergeben. Jeder Cell-Eintrag
% enthält einen Vektor mit den Werten auf der entsprechenden
% Diagonalen.
% In unserem Beispiel: { [b,e,0], [a,d,h,j], [c,g,i], [f,0] }
