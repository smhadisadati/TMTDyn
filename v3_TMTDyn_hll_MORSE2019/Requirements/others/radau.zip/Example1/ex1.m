% Example 1 for radau5Mex
%    x1'=x1 
%    x2'=x2
%    x1(1)=1, x2(1)=2
close all;clear classes;
opt.RelTol=1e-6;opt.AbsTol=1e-6;
% Jacobian is banded (Jacobimatrix hat Bandstruktur)
% Jacobian is not given (Jacobimatrix wird nicht explizit angegeben)
%   => numerical differentiation (numerische Differentation verwenden)
opt.JacobianLowerBandwidth=0;
opt.JacobianUpperBandwidth=0;
[tG,xG,stats]=radauMex(@f,[1,2],[1;2],opt);
% also possible:

t=linspace(1,2,100);
plot(t,exp(t-1),'g',t,2*exp(t-1),'g',tG,xG(:,1),'rx',tG,xG(:,2),'bx');