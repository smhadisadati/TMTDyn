function dx=f(t,x)
% right side
dx=x;
