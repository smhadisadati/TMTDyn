function dx=f(t,x)
% right side
% only the nontrivial part
dx=[x(1)+t*x(2)+x(3)+x(5)+x(6); % x5'
         2*x(2)+x(4)];     % x6'
