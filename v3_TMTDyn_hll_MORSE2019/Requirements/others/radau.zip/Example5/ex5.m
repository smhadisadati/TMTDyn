% Example 5
%  x1'=x3
%  x2'=x4
%  x3'=x5
%  x4'=x6
%  x5'= x1 + t*x2 + x3 + x5 + x6
%  x6'=      2*x2 + x4 
%  x1(1)=x2(1)=x3(1)=x4(1)=x5(1)=x6(1)=1
close all;clear classes;
opt.RelTol=1e-6;opt.AbsTol=1e-6;
% System has special structure (System hat Spezialstruktur)
opt.M1=4;opt.M2=2;
% nontrivial jacobi blocks are banded 
%  (nichttriviale Jacobibl�cke haben Bandstruktur)
% Jacobi blocks given (Bl�cke werden explizit angegeben)
opt.JacobianLowerBandwidth=0;
opt.JacobianUpperBandwidth=1;
opt.Jacobian=@jac;
% Jacobiauswertung ist so billig, deshalb
opt.RecomputeJACFactor=-1;

% with dense output:
[tG,xG,stats]=radauMex(@f,linspace(1,2,100),[1;1;1;1;1;1],opt);

plot(tG,xG);