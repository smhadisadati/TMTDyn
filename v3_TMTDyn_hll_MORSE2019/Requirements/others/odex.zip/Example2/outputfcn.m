function status=outputfcn(a,b,cmd)
if (nargin<3) cmd='default';end
switch (cmd) 
    case 'init'
        clf;hold on;
    case 'done'
        hold off;
    case 'default'
        status=0;
        plot(a,b,'rx');
end
end