opt=[];
opt.RelTol=1e-6;opt.AbsTol=1e-6;
opt.OutputFcn=@odeplot;
%opt.OutputFcn=@outputfcn;
opt.OutputCallMode=2;

[tNodes,xNodes,stats]=odexMex(inline('x','t','x'),linspace(0,3,500),1,opt);

