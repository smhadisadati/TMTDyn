% Linking C and Fortran files
% Different compilers have different conventions:
% If you call a Fortran function "func" from C some compilers
% append an underscore (when compiling the Fortran file).
% Hence you have to append the underscore when calling: "func_".
% Some compilers need "FUNC_" and others "FUNC" and again others
% need "_FUNC" or "_func" or "_FUNC_" or "_func_".
%
% There are compile-time switches you can adapt the MEX-Interface 
% to your compiler:
%
%  FORTRANUPP: 
%    if set, all Fortran-routines are called with uppercase letters
%  FORTRANNOUNDER: 
%    if set, all Fortran-routines are called without a trailing underscore
%  FORTRANLEADUNDER:
%    if set, all Fortran-routines are called with a leading underscore
%
% The default: all switches are turned off:
%    lowercase with trailing underscore and without leading underscore
%
% Example:
% mex -DFORTRANUPP ...
% 
% When using
%    -largeArrayDims  
% be sure to use the right Fortran-Compiler options, e.g.
%    -fdefault-integer-8 for GNU Fortran compiler for largeArrayDims
%
% Here are two examples how odexMex is compiled
% for compatibleArrayDims and largeArrayDims 
% on a 64bit Fedora-Linux with GCC:
%
% ==== Example-Output for -compatibleArrayDims (gcc on Fedora Linux) 
%   /bin/gcc -c -DMX_COMPAT_32   -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/odexMex.c -o odexMex.o
%   /bin/gcc -c -DMX_COMPAT_32   -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/options.c -o options.o
%   /bin/gcc -c -DMX_COMPAT_32   -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/tif.c -o tif.o
%   /bin/gfortran -c -DMX_COMPAT_32    -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -O /mnt/data/docs/uni/mexfiles/odex/odex.f -o odex.o
%   /bin/gfortran -c -DMX_COMPAT_32    -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -O /mnt/data/docs/uni/mexfiles/odex/tif_test.f -o tif_test.o
%   /bin/gcc -pthread -Wl,--no-undefined -Wl,-rpath-link,/usr/local/share/matlabR2014b/bin/glnxa64 -shared  -O -Wl,--version-script,"/usr/local/share/matlabR2014b/extern/lib/glnxa64/mexFunction.map" odexMex.o options.o tif.o odex.o tif_test.o  -lgfortran   -L"/usr/local/share/matlabR2014b/bin/glnxa64" -lmx -lmex -lmat -lm -lstdc++ -o odexMex.mexa64
%
% ==== Example-Output for -largeArrayDims (gcc on Fedora Linux) 
%
%  /bin/gcc -c -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/odexMex.c -o odexMex.o
%  /bin/gcc -c -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/options.c -o options.o
%  /bin/gcc -c -D_GNU_SOURCE -DMATLAB_MEX_FILE  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -ansi -fexceptions -fPIC -fno-omit-frame-pointer -pthread -O -DNDEBUG /mnt/data/docs/uni/mexfiles/odex/tif.c -o tif.o
%  /bin/gfortran -c  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -O /mnt/data/docs/uni/mexfiles/odex/odex.f -o odex.o
%  /bin/gfortran -c  -I"/usr/local/share/matlabR2014b/extern/include" -I"/usr/local/share/matlabR2014b/simulink/include" -fexceptions -fbackslash -fPIC -fno-omit-frame-pointer -O /mnt/data/docs/uni/mexfiles/odex/tif_test.f -o tif_test.o
%  /bin/gcc -pthread -Wl,--no-undefined -Wl,-rpath-link,/usr/local/share/matlabR2014b/bin/glnxa64 -shared  -O -Wl,--version-script,"/usr/local/share/matlabR2014b/extern/lib/glnxa64/mexFunction.map" odexMex.o options.o tif.o odex.o tif_test.o  -lgfortran   -L"/usr/local/share/matlabR2014b/bin/glnxa64" -lmx -lmex -lmat -lm -lstdc++ -o odexMex.mexa64

args=cell(0,1);
% Matlab R2014b changed way to compile things:
% "Cannot compile both C and FORTRAN source files in a single call to MEX"

% Add argument for Linker to include Fortran lib
args{end+1}='-lgfortran';  

% Add argument for largeArrayDims?
%args{end+1}='-largeArrayDims';
args{end+1}='-compatibleArrayDims';

% Add verbose argument
args{end+1}='-v';

mex('-c',args{:},'odexMex.c','options.c','tif.c');
mex('-c',args{:},'odex.f','tif_test.f');

mex(args{:},'odexMex.o','options.o','tif.o','odex.o','tif_test.o');

%mex odexMex.c options.c tif.c odex.f tif_test.f
