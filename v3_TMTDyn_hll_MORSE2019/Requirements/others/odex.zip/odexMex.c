/*
 * ODEXMEX-Interface von C. Ludwig
 * Version: $Id: odexMex.c 1243 2014-11-04 19:42:13Z luchr $ */
#define ODEMexVersion "04. November 2014"
/*
 * 
 * Fragen, Wünsche, Probleme, Anregungen, 
 * Anmerkungen, Bemerkungen und Bugs an
 *  ludwig@ma.tum.de
 */
#include <math.h>
#include "mex.h"
#include "string.h"
#include "options.h"
#include "odexMex.h"

#define Fabs(i) (i>0?(i):(-i))
#define FMTS "%" FMT_SIZE_T "u"
#define MPR mexPrintf

static SOptionSettings optSet;
static SParameterGlobal paramGlobal;
static SParameterIO paramIO;
static SParameterRightSide paramRightSide;
static SParameterOdex paramOdex;
static SParameterOutput paramOutput;

static SOdexDense odexDense;
static char isInnerCall=(char)0;

static char ismxArrayString (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  if (mxIsChar(arr)) return (char)1;
  return (char)0;
}

static char ismxArrayFunction (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (mxGetClassID(arr)==mxFUNCTION_CLASS)?(char)1:(char)0;
}

static char ismxArrayInline (const mxArray *arr) {
  if (arr==NULL) return (char)0;
  return (strcmp(mxGetClassName(arr),"inline")==0)?(char)1:(char)0;
}


static void clearList (PListElement current) {
  PListElement next;
  
  while (current!=NULL) {
    next=current->next;
    if (current->values!=NULL)
      {mxFree(current->values);current->values=NULL;}
    mxFree(current);
    current=next;
  }
}

static void initVars (void) {
  /* Option settings */
  optSet.warnMiss=0;optSet.warnType=1;optSet.warnSize=1;     
  
  /* global parameters */
  paramGlobal.tPointer=NULL;
  isInnerCall=(char)0;
  
  /* IO parameters */
  paramIO.opt=NULL;paramIO.optCreated=0;    
  
  /* parameters for odex */
  paramOdex.xStart=NULL;  
  paramOdex.RTOL=NULL;paramOdex.ATOL=NULL;
  paramOdex.WORK=NULL;paramOdex.IWORK=NULL;
  paramOdex.RPAR=NULL;paramOdex.IPAR=NULL;  
    
  /* parameters for rightside */
  paramRightSide.rightSideFcn=NULL;
  paramRightSide.rightSideFcnH=NULL;
  paramRightSide.tArg=NULL;paramRightSide.xArg=NULL;  
  
  /* output parameters */
  paramOutput.txList.values=NULL;
  paramOutput.txList.next=NULL;
  paramOutput.lastTXElement=&paramOutput.txList;
  paramOutput.numberOfElements=0;
  paramOutput.outputFcn=NULL;
  paramOutput.outputFcnH=NULL;
  paramOutput.tArg=NULL;paramOutput.xArg=NULL;paramOutput.emptyArg=NULL;
  paramOutput.toldArg=NULL;
}

static void doneVars (void) {  
  /* global parameters */
  /* tPointer darf auf keinen Fall */
  /* freigegeben werden, er gehört dem Aufrufer */  
  
  /* IO parameters */
  if ((paramIO.optCreated) && (paramIO.opt!=NULL)) 
    {mxDestroyArray((mxArray*)paramIO.opt);paramIO.opt=NULL;}    
  
  /* parameters for odex */
  if (paramOdex.xStart!=NULL)
    {mxFree(paramOdex.xStart);paramOdex.xStart=NULL;}
  if (paramOdex.RTOL!=NULL)
    {mxFree(paramOdex.RTOL);paramOdex.RTOL=NULL;}
  if (paramOdex.ATOL!=NULL)
    {mxFree(paramOdex.ATOL);paramOdex.ATOL=NULL;}
  if (paramOdex.WORK!=NULL)
    {mxFree(paramOdex.WORK);paramOdex.WORK=NULL;}
  if (paramOdex.IWORK!=NULL)
    {mxFree(paramOdex.IWORK);paramOdex.IWORK=NULL;}
  if (paramOdex.RPAR!=NULL)
    {mxFree(paramOdex.RPAR);paramOdex.RPAR=NULL;}
  if (paramOdex.IPAR!=NULL)
    {mxFree(paramOdex.IPAR);paramOdex.IPAR=NULL;}    
  
  /* parameters for right side */
  if (paramRightSide.rightSideFcn!=NULL)
    {mxFree(paramRightSide.rightSideFcn);paramRightSide.rightSideFcn=NULL;}
  paramRightSide.rightSideFcnH=NULL; /* gehört Aufrufer => nicht freigeben */
  if (paramRightSide.tArg!=NULL)
    {mxDestroyArray(paramRightSide.tArg);paramRightSide.tArg=NULL;}
  if (paramRightSide.xArg!=NULL)
    {mxDestroyArray(paramRightSide.xArg);paramRightSide.xArg=NULL;}  
    
  /* output parameters */
  clearList(paramOutput.txList.next);paramOutput.txList.next=NULL;
  if (paramOutput.outputFcn!=NULL)
    {mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;}
  paramOutput.outputFcnH=NULL; /* gehört Aufrufer => nicht freigeben */
  if (paramOutput.tArg!=NULL)
    {mxDestroyArray(paramOutput.tArg);paramOutput.tArg=NULL;}
  if (paramOutput.xArg!=NULL)
    {mxDestroyArray(paramOutput.xArg);paramOutput.xArg=NULL;}    
  if (paramOutput.emptyArg!=NULL) 
    {mxDestroyArray(paramOutput.emptyArg);paramOutput.emptyArg=NULL;}
  if (paramOutput.toldArg!=NULL) 
    {mxDestroyArray(paramOutput.toldArg);paramOutput.toldArg=NULL;}
}

static void stopMexFunctionImpl (int errNo,
  size_t i1, size_t i2, size_t i3,
  long l1, double d1, char doneFlag) {
  const char *msg;
  size_t d;

  isInnerCall=(char)0;
  mexPrintf("Error (%i) [Version: %s]:\n",errNo,ODEMexVersion);
  mexPrintf("Fehler (%i) [Version: %s]:\n",errNo,ODEMexVersion);
  d = (size_t)paramGlobal.d;
  switch (errNo) {
    #include "errors.c"
    default: msg="Unbekannte Fehlernummer";break;
  }
  
  if (doneFlag) {doneVars();}
  mexErrMsgTxt(msg);
}

static void stopMexFunction (int errNo,
  size_t i1, size_t i2, size_t i3, 
  long l1, double d1) {
  
  stopMexFunctionImpl(errNo,i1,i2,i3,l1,d1,(char)1);
}
static void stopMexFunction0 (int errNo) {
  stopMexFunction(errNo,0,0,0,0,0);
}
static void stopMexFunctionI1 (int errNo, size_t i1) {
  stopMexFunction(errNo,i1,0,0,0,0);
}
static void stopMexFunctionI2 (int errNo, size_t i1, size_t i2) {
  stopMexFunction(errNo,i1,i2,0,0,0);
}
static void stopMexFunctionI3 (int errNo, size_t i1, size_t i2, size_t i3) {
  stopMexFunction(errNo,i1,i2,i3,0,0);
}
static void stopMexFunctionL1 (int errNo, long l1) {
  stopMexFunction(errNo,0,0,0,l1,0);
}
static void stopMexFunctionD1 (int errNo, double d1) {
  stopMexFunction(errNo,0,0,0,0,d1);
}

static void addTXtoList (double t, double *x) {
  double* dpointer;
  PListElement target;
  
  target=(PListElement)mxMalloc(sizeof(SListElement));
  target->next=NULL;paramOutput.lastTXElement->next=target;
  paramOutput.lastTXElement=target;paramOutput.numberOfElements++;
  target->values=(double*)mxMalloc((size_t)(paramGlobal.d+1)*sizeof(double));
  dpointer=target->values;
  *dpointer=t;dpointer++;
  memcpy(dpointer,x,(size_t)paramGlobal.d*sizeof(double));
}

static void checkNumberOfArgs (int nlhs, int nrhs) {
  if ((nlhs<2) || (nlhs>4)) stopMexFunctionI1(1,(size_t)nlhs);
  if ((nrhs!=3) && (nrhs!=4)) stopMexFunctionI1(2,(size_t)nrhs);
}

static void processArgs (int nrhs, const mxArray* prhs[]) {
  size_t len;
  mwSize buflen;
  double *dpointer;
 
  /* 1st arg: right side */
  if (ismxArrayString(prhs[0])) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1))
      stopMexFunctionI2(4,(size_t)mxGetNumberOfDimensions(prhs[0]),mxGetM(prhs[0]));
    
    paramRightSide.rightSideFcn=mxArrayToString(prhs[0]);
    paramRightSide.rightSideFcnH=prhs[0];
  } else 
  if ( (ismxArrayFunction(prhs[0])) || (ismxArrayInline(prhs[0])) ) {
    if ((mxGetNumberOfDimensions(prhs[0])!=2) || (mxGetM(prhs[0])!=1) ||
        (mxGetN(prhs[0])!=1))
      stopMexFunctionI3(15,(size_t)mxGetNumberOfDimensions(prhs[0]),
                      mxGetM(prhs[0]),mxGetN(prhs[0]));
    paramRightSide.rightSideFcn=NULL; /* kein String */
    paramRightSide.rightSideFcnH=prhs[0];
  } else {
    stopMexFunction0(3);
  }
  
  /* 2nd arg: row-vector containing time-values */
  if (!mxIsDouble(prhs[1])) stopMexFunction0(5);
  if ((mxGetNumberOfDimensions(prhs[1])!=2) || (mxIsSparse(prhs[1])) || 
      (mxGetM(prhs[1])!=1))
    stopMexFunctionI2(6,(size_t)mxGetNumberOfDimensions(prhs[1]),mxGetM(prhs[1]));
  len=mxGetN(prhs[1]);
  if (!tif_fits_st_in_mws(len)) stopMexFunctionI2(19,len,(size_t)MWSIZE_MAX);
  paramGlobal.tLength=tif_st2mws(len);
  if (paramGlobal.tLength<2) stopMexFunction0(7);
  if (paramGlobal.tLength>2) {
    paramOdex.denseFlag=1;paramOdex.IOUT=2;
  } else {
    paramOdex.denseFlag=0;paramOdex.IOUT=1;
  }
  dpointer=mxGetPr(prhs[1]);paramGlobal.tPointer=dpointer;
  paramOdex.tStart=dpointer[0];
  paramOdex.tEnd=dpointer[paramGlobal.tLength-1];
  if (paramOdex.tStart==paramOdex.tEnd) stopMexFunction0(12);
  paramGlobal.direction=(paramOdex.tEnd-paramOdex.tStart)>0?1.0:-1.0;
  for (buflen=1; buflen<paramGlobal.tLength; buflen++,dpointer++)
    if (paramGlobal.direction*(dpointer[0]-dpointer[1])>0)
      stopMexFunctionD1(14,paramGlobal.direction);

  /* 3rd arg: start vector */
  if (!mxIsDouble(prhs[2])) stopMexFunction0(8);
  if ((mxGetNumberOfDimensions(prhs[2])!=2) || (mxGetN(prhs[2])!=1) ||
      (mxIsSparse(prhs[2])))
    stopMexFunctionI2(9,(size_t)mxGetNumberOfDimensions(prhs[2]),mxGetN(prhs[2]));
  len=mxGetM(prhs[2]);
  if (!tif_fits_st_in_mws(len)) stopMexFunctionI2(19,len,(size_t)MWSIZE_MAX);
  paramGlobal.d=tif_st2mws(len);
  if (paramGlobal.d<1) stopMexFunction0(10);
  dpointer=mxGetPr(prhs[2]);
  paramOdex.xStart=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
  memcpy(paramOdex.xStart,dpointer,(size_t)paramGlobal.d*sizeof(double));
  /* little remark: A COPY of the startvector is made, because
     it will be passed to Fortran code. To be sure, that
     it will not be changed there, a copy will be passed.
     x0 belongs to the caller and it is not allowed 
     (due to Matlab-Contract) to change it. */
  /* kleine Anmerkung: der Startvektor wird KOPIERT, da er an den 
     Fortran code weitergegeben wird. Um ganz sicher zu gehen,
     dass er nicht verändert wird, wird eine Kopie übergeben.
     x0 gehört ja dem Aufrufer und darf nach Matlab-Konvention
     nicht verändert werden. */
     
  /* 4th arg: struct with options */
  if (nrhs==4) {
    if (!mxIsStruct(prhs[3])) stopMexFunction0(11);
    paramIO.opt=prhs[3];paramIO.optCreated=0;
  } else {
    paramIO.opt=mxCreateStructMatrix(1,1,0,NULL);
    paramIO.optCreated=1;
  }
}

static void extractOptionSettings (void) {
  optSet.warnMiss=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNMISS,0);
  optSet.warnType=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNTYPE,1);
  optSet.warnSize=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_WARNSIZE,1);
}

static void extractHandTOLs (void) {
  size_t len1,len2;
  mwSize m1,n1,m2,n2;
  char res1,res2;
  int takeScalar;
  
  paramOdex.h=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_INITIALSS,1e-6);
  if (paramOdex.h<=0.0) stopMexFunction0(216);
  
  res1=opt_getSizeOfOptField(paramIO.opt,OPT_RTOL,&len1,&len2);
  if (!tif_fits_st_in_mws(len1)) stopMexFunctionI1(20,len1);
  if (!tif_fits_st_in_mws(len2)) stopMexFunctionI1(20,len2);
  m1=tif_st2mws(len1); n1=tif_st2mws(len2);

  res2=opt_getSizeOfOptField(paramIO.opt,OPT_ATOL,&len1,&len2);
  if (!tif_fits_st_in_mws(len1)) stopMexFunctionI1(21,len1);
  if (!tif_fits_st_in_mws(len2)) stopMexFunctionI1(21,len2);
  m2=tif_st2mws(len1); n2=tif_st2mws(len2);
  
  takeScalar=0;
  if (((res1!=0) || (res2!=0)) ||
      ((res1==0) && (m1==1)) ||
      ((res2==0) && (m2==1))) {
    takeScalar=1;
  } else {
    if ((n1!=1) || (n2!=1)) takeScalar=1;
    if (m1!=m2) takeScalar=1;
    if (m1!=paramGlobal.d) takeScalar=1;
  }

  if (takeScalar) {
    paramOdex.RTOL=(double*)mxMalloc(1*sizeof(double));
    paramOdex.ATOL=(double*)mxMalloc(1*sizeof(double));
    *paramOdex.RTOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RTOL,1e-3);
    *paramOdex.ATOL=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ATOL,1e-6);
    paramOdex.ITOL=0;
  } else {
    paramOdex.RTOL=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
    paramOdex.ATOL=(double*)mxMalloc((size_t)paramGlobal.d*sizeof(double));
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_RTOL,
      (size_t)paramGlobal.d,1,paramOdex.RTOL);
    opt_getDoubleVectorFromOpt(paramIO.opt,&optSet,OPT_ATOL,
      (size_t)paramGlobal.d,1,paramOdex.ATOL);
    paramOdex.ITOL=1;
  }
}

static void extractOutput (void) {
  mxArray *arr;
  
  if (paramOdex.denseFlag) {
    paramOutput.includeGrid=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_IGPIDO,0);
  }
  
  paramOutput.outputFcnH=NULL;paramOutput.outputFcn=NULL;
  arr=mxGetField(paramIO.opt,0,OPT_OUTPUTFUNCTION);
  if ((arr!=NULL) && (!mxIsEmpty(arr))) {
    if ( (ismxArrayFunction(arr)) || (ismxArrayInline(arr)) ) {   
      if ((mxGetNumberOfDimensions(arr)!=2) || (mxGetM(arr)!=1) ||
          (mxGetN(arr)!=1) || mxIsSparse(arr))
        stopMexFunctionI3(401,(size_t)mxGetNumberOfDimensions(arr),
                        mxGetM(arr),mxGetN(arr));
      paramOutput.outputFcnH=arr;
    } else {
      paramOutput.outputFcn=opt_getStringFromOpt(paramIO.opt,&optSet,
        OPT_OUTPUTFUNCTION,NULL);
      if (paramOutput.outputFcn!=NULL) {
        if (strlen(paramOutput.outputFcn)==0) {
          mxFree(paramOutput.outputFcn);paramOutput.outputFcn=NULL;
        } else {
          paramOutput.outputFcnH=arr;
        }
      }
    }
  }
  
  paramOutput.outputCallMode=1;
  if ((paramOutput.outputFcnH!=NULL) && (paramOdex.denseFlag)) {
    paramOutput.outputCallMode=opt_getIntFromOpt(paramIO.opt,&optSet,
      OPT_OUTPUTCALLMODE,1);
    if ((paramOutput.outputCallMode<1) || (paramOutput.outputCallMode>3))
      paramOutput.outputCallMode=1;
  }
}

static void extractExtrapolParamKM (void) {
  paramOdex.maxExColumn=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_MAXEXCOLUMN,9);
  if (paramOdex.maxExColumn<3) stopMexFunction0(200);
}

static void extractGlobalOptions (void) {
  paramGlobal.funcCallMethod=opt_getIntFromOpt(paramIO.opt,&optSet,
    OPT_FUNCCALLMETHOD,1);
  switch (paramGlobal.funcCallMethod) {
    case 0: /* use mexCallMATLAB direct */
      if (paramRightSide.rightSideFcn==NULL) stopMexFunction0(17);
      if ((paramOutput.outputFcnH!=NULL) && (paramOutput.outputFcn==NULL))
        stopMexFunction0(18);
      break;
    case 1: /* use mexCallMATLAB to call feval */
      break;
    default:
      stopMexFunction0(16);
      break;
  }
}

static void extractOptionsPart1 (void) {
  extractOptionSettings();
  extractHandTOLs();
  extractExtrapolParamKM();
  extractOutput();
  extractGlobalOptions();
}

static void prepareIWorkArray (void) {
  Fint i,d,km,nrdense;

  d=tif_mws2Fint(paramGlobal.d);

  km=paramOdex.maxExColumn;
  
  if (paramOdex.denseFlag) nrdense=d;else nrdense=0;
  
  /* IWORK */
  paramOdex.LIWORK=2*km+21+nrdense;
  paramOdex.IWORK=(Fint*)mxMalloc((size_t)paramOdex.LIWORK*sizeof(Fint));
  
  /* Std-Values */
  for (i=1-1; i<=20-1; i++) paramOdex.IWORK[i]=0;
  
  /* save values we already know */
  paramOdex.IWORK[2-1]=km;
  paramOdex.IWORK[8-1]=nrdense;
}

static void prepareWorkArray (void) {
  Fint i,d,km,nrdense;
  
  d=tif_mws2Fint(paramGlobal.d);km=paramOdex.maxExColumn;
  nrdense=paramOdex.IWORK[8-1];
  
  /* WORK */
  paramOdex.LWORK=d*(km+5)+5*km+20+(2*km*(km+2)+5)*nrdense;
  paramOdex.WORK=(double*)mxMalloc((size_t)paramOdex.LWORK*sizeof(double));
  
  /* Std-Values */
  for (i=1-1; i<=20-1; i++) paramOdex.WORK[i]=0.0;
}

static void extractIWORK (void) {
  Fint i;
  
  i=opt_getIntFromOpt(paramIO.opt,&optSet,OPT_MAXSTEPS,10000);
  if (i<=0) stopMexFunctionL1(201,i);
  paramOdex.IWORK[1-1]=i;
  
  /* IWORK(2) wurde schon in prepareIWorkArray erledigt */
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_STEPSIZESEQUENCE,
    (paramOdex.IOUT<=1)?1:4);
  if ((i<=0) || (i>=6)) stopMexFunctionL1(202,i);
  paramOdex.IWORK[3-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MAXNUMBEROFSTABCHECKS,1);
  if (i<1) stopMexFunctionL1(203,i);
  paramOdex.IWORK[4-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_MAXSTABCHECKLINE,1);
  if (i<1) stopMexFunctionL1(204,i);
  paramOdex.IWORK[5-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_DENSEOUTPUTWOEE,0);
  if ((i!=0) && (i!=1)) stopMexFunctionL1(205,i);
  paramOdex.IWORK[6-1]=i;
  
  i=opt_getFintFromOpt(paramIO.opt,&optSet,OPT_INTERPOLDEGREE,4);
  if ((i<=0) || (i>=7)) stopMexFunctionL1(206,i);
  paramOdex.IWORK[7-1]=i;
  
  /* IWORK(8) wurde schon in prepareIWorkArray erledigt */
}

static void extractWORK (void) {
  double d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_EPS,2.3e-16);
  if (!(d>0.0)) stopMexFunctionD1(207,d);
  paramOdex.WORK[1-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_MAXSS,
    paramOdex.tEnd-paramOdex.tStart);
  if (!(d!=0.0)) stopMexFunctionD1(208,d);
  paramOdex.WORK[2-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSREDUCTION,0.5);
  if (!((d>0.0) && (d<1.0))) stopMexFunctionD1(209,d);
  paramOdex.WORK[3-1]=d;  
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSSELECTPAR1,0.02);
  if (!(d>0.0)) stopMexFunctionD1(210,d);
  paramOdex.WORK[4-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSSELECTPAR2,4.0);
  if (!(d>0.0)) stopMexFunctionD1(211,d);
  paramOdex.WORK[5-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERDECFRAC,0.8);
  if (!(d>0.0)) stopMexFunctionD1(212,d);
  paramOdex.WORK[6-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_ORDERINCFRAC,0.9);
  if (!(d>0.0)) stopMexFunctionD1(213,d);
  paramOdex.WORK[7-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_SSSELECTPAR3,0.65);
  if (!(d>0.0)) stopMexFunctionD1(215,d);
  paramOdex.WORK[8-1]=d;
  
  d=opt_getDoubleFromOpt(paramIO.opt,&optSet,OPT_RHO,0.94);
  if (!(d>0.0)) stopMexFunctionD1(214,d);
  paramOdex.WORK[9-1]=d;  
}

static void extractOptionsPart2 (void) {
  extractIWORK();
  extractWORK();
}

static void prepareHelpMxArrays (void) {
  mwSize d;
   
  d=paramGlobal.d;
   
  paramRightSide.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
  paramRightSide.xArg=mxCreateDoubleMatrix(d,1,mxREAL);
  
  if ((paramOutput.outputFcnH!=NULL) || (paramOdex.denseFlag)) {
    paramOutput.tArg=mxCreateDoubleMatrix(1,1,mxREAL);
    paramOutput.xArg=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);
    paramOutput.emptyArg=mxCreateDoubleMatrix(1,0,mxREAL);
    paramOutput.toldArg=mxCreateDoubleMatrix(1,1,mxREAL);
  }
}

static int callOutputFcn (int reason, double tOld, double t, double *x, int doCopy) {
  int doPoint,erg,offset;
  double *dpointer;
  mxArray *rhs[5];
  mxArray *lhs[1];
  
  if (paramOutput.outputFcnH==NULL) return 0;
  doPoint=0;lhs[0]=NULL;erg=0;
  switch (reason) {
    case 1: /* Init-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction0(1002);break;
      }
      rhs[offset]=mxCreateDoubleMatrix(1,2,mxREAL);
      dpointer=mxGetPr(rhs[offset]);
      *dpointer=paramOdex.tStart;dpointer++;
      *dpointer=paramOdex.tEnd;
      offset++;
      
      rhs[offset]=mxCreateDoubleMatrix(paramGlobal.d,1,mxREAL);
      memcpy(mxGetPr(rhs[offset]),paramOdex.xStart,(size_t)paramGlobal.d*sizeof(double));
      offset++;
      
      rhs[offset++]=mxCreateString("init");

      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction0(1002);break;
      }
      break;
    case 2: /* Done-Fall */
      offset=0;
      switch (paramGlobal.funcCallMethod) {
        case 0: break;
        case 1:
          rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
          break;
        default: stopMexFunction0(1002);break;
      }
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateDoubleMatrix(0,0,mxREAL);
      rhs[offset++]=mxCreateString("done");

      switch (paramGlobal.funcCallMethod) {
        case 0:
          mexCallMATLAB(0,lhs,offset,rhs,paramOutput.outputFcn);
          while (--offset>=0) {mxDestroyArray(rhs[offset]);}
          break;
        case 1:
          mexCallMATLAB(0,lhs,offset,rhs,"feval");
          while (--offset>=1) {mxDestroyArray(rhs[offset]);}
          break;
        default: stopMexFunction0(1002);break;
      }
      break;
    case 3: /* Neuer Grid-Punkt */
      if ((paramOdex.denseFlag) && (paramOutput.outputCallMode==1)) break;
      doPoint=1;
      break;
    case 4: /* Neuer dense-Punkt */
      if ((paramOdex.denseFlag) && (paramOutput.outputCallMode==2)) break;
      doPoint=1;
      break;
    case 5: /* Neuer dense und Grid-Punkt */
      doPoint=1;
      break;
    default: stopMexFunction0(1001);
  }
  
  if (doPoint) {
    *mxGetPr(paramOutput.tArg)=t;
    *mxGetPr(paramOutput.toldArg)=tOld;
    if (doCopy)
      memcpy(mxGetPr(paramOutput.xArg),x,(size_t)paramGlobal.d*sizeof(double));
    
    offset=0;
    switch (paramGlobal.funcCallMethod) {
      case 0: break;
      case 1:
        rhs[offset++]=(mxArray*)paramOutput.outputFcnH;
        break;
      default: stopMexFunction0(1002);break;
    }
    rhs[offset++]=paramOutput.tArg;rhs[offset++]=paramOutput.xArg;
    rhs[offset++]=paramOutput.emptyArg;
    rhs[offset++]=paramOutput.toldArg;

    switch (paramGlobal.funcCallMethod) {
      case 0:
        mexCallMATLAB(1,lhs,offset,rhs,paramOutput.outputFcn);
        break;
      case 1:
        mexCallMATLAB(1,lhs,offset,rhs,"feval");
        break;
      default: stopMexFunction0(1002);break;
    }
    
    if (lhs[0]==NULL) {
      erg=0; 
    } else {
      erg=(int)mxGetScalar(lhs[0]);
      mxDestroyArray(lhs[0]);
    }
  }
  
  return erg;
}

void OdexRightSideFunc (Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar) {
  Fint d;
  mxArray *rhs[3];
  mxArray *lhs[1];

  (void)rpar; (void)ipar;
  
  d=*n;lhs[0]=NULL;

  /* Call by value */
  /* Use always the SAME Matlab tArg and xArg */
  /* IMPORTANT NOTICE (if the right side is also a MEX-File)
     the right side must not "garble" the passed mxArrays:
     the size must not be changed and the memory must not
     be freed. 
     Hence: the right side has to take care, that the
     passed mxArrays have the same size and enough memory
     when returning. The values in the memory(-block)
     may be overwritten.
     If the right side is an m-file MATLAB obeys this
     restriction automatically. */
  /* WICHTIGE Anmerkung (falls rechte Seite auch MEX-File ist)
     die rechte Seite darf die übergebenen mxArrays nicht
     "verstümmeln": die Größe darf nicht verändert werden
     und auch der Speicherplatz darf nicht freigegeben werden.
     Also: die rechte Seite muss sicherstellen, dass die
     übergebenen mxArrays am Ende wieder diesselbe Größe
     und ausreichend Speicher haben. Der Speicher selbst
     darf natürlich zu rechenzwecken überschrieben werden.
     Bei m-Files achtet MATLAB automatisch darauf.
  */
  *mxGetPr(paramRightSide.tArg)= *t;
  memcpy(mxGetPr(paramRightSide.xArg),x,(size_t)d*sizeof(double));
  switch (paramGlobal.funcCallMethod) {
    case 0:
        rhs[0]=paramRightSide.tArg;
        rhs[1]=paramRightSide.xArg;

        /* Call User's right side */
        mexCallMATLAB(1,lhs,2,rhs,paramRightSide.rightSideFcn);
      break;
    case 1:
        rhs[0]=(mxArray*)paramRightSide.rightSideFcnH;
        rhs[1]=paramRightSide.tArg;
        rhs[2]=paramRightSide.xArg;

        /* Call User's right side */  
        mexCallMATLAB(1,lhs,3,rhs,"feval");
      break;
    default: stopMexFunction0(1002);break;
  }
  
  /* check return values */
  if (lhs[0]==NULL) stopMexFunction0(301);
  if ((!mxIsDouble(lhs[0])) || (mxGetNumberOfDimensions(lhs[0])!=2))
    stopMexFunction0(302);

  if (!(((mxGetM(lhs[0])==(size_t)d) && (mxGetN(lhs[0])==1)) ||
        ((mxGetM(lhs[0])==1) && (mxGetN(lhs[0])==(size_t)d))))
    stopMexFunctionI2(303,mxGetM(lhs[0]),mxGetN(lhs[0]));
    
    /* copy back */
  memcpy(f,mxGetPr(lhs[0]),(size_t)d*sizeof(double));
  
  /* free memory */
  mxDestroyArray(lhs[0]);
}

void OdexSoloutFunc(Fint *nr, double *told,
    double *t, double *x, Fint *d, 
        double *con, Fint *ncon, Fint *icomp, Fint *nd,
        double *rpar, Fint *ipar, Fint *irtrn) {
  Fint i,erg,ilast;
  double *dpointer;
  double tdense;
  int alreadySaved;

  (void)d; (void)rpar; (void)ipar;
  
  if (*nr==1) paramOutput.tPos=0;
  
  erg=0;
  if (paramOdex.denseFlag) {
    odexDense.con=con;odexDense.ncon=ncon;
    odexDense.icomp=icomp;odexDense.nd=nd;
    isInnerCall=(char)1;
    alreadySaved=0;
    while (1) {
      if (paramOutput.tPos>=paramGlobal.tLength) break;
      tdense=paramGlobal.tPointer[paramOutput.tPos];
      if (tdense==*t) {
        addTXtoList(*t,x);paramOutput.tPos++;
        alreadySaved=1;
        erg=callOutputFcn(5,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
        if (erg==1) {erg=-1;break;} /* Stop, NOW */
        continue;
      }
      if (paramGlobal.direction*(tdense-(*t))>0) break;
      
      dpointer=mxGetPr(paramOutput.xArg);
      
      ilast=tif_mws2Fint(paramGlobal.d);
      for (i=1; i<=ilast; i++,dpointer++)
        *dpointer=CONTEX_(&i,&tdense,con,ncon,icomp,nd);
        
      dpointer=mxGetPr(paramOutput.xArg);
      addTXtoList(tdense,dpointer);
      erg=callOutputFcn(4,*told,tdense,dpointer,0);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;break;} /* Stop, NOW */
      
      paramOutput.tPos++;
    }
    if (!alreadySaved) {
      if (paramOutput.includeGrid) addTXtoList(*t,x);
      erg=callOutputFcn(3,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
      if (erg==1) {erg=-1;} /* Stop, NOW */
    }
    isInnerCall=(char)0;
    odexDense.con=NULL;odexDense.ncon=NULL;
    odexDense.icomp=NULL;odexDense.nd=NULL;
  } else {
    addTXtoList(*t,x);
    erg=callOutputFcn(3,*told,*t,x,1);if ((erg!=0) && (erg!=1)) erg=0;
    if (erg==1) {erg=-1;} /* Stop, NOW */
  }
  
  *irtrn=erg;
}

static void createTXArrays (mxArray* plhs[]) {
  mwSize i,d,count,n;
  PListElement current;
  double *tPointer, *xPointer, *vPointer;
  
  d=paramGlobal.d;n=paramOutput.numberOfElements;
  plhs[0]=mxCreateDoubleMatrix(n,1,mxREAL);
  plhs[1]=mxCreateDoubleMatrix(n,d,mxREAL);
  
  tPointer=mxGetPr(plhs[0]);
  xPointer=mxGetPr(plhs[1]);
  
  current=paramOutput.txList.next;
  count=0;
  while (current!=NULL) {
    vPointer=current->values;
    *tPointer= *vPointer; tPointer++; vPointer++;
    for (i=0; i<d; i++,vPointer++) xPointer[count+i*n]= *vPointer;
    
    current=current->next;count++;
  }
}

static void createStatVector (mxArray* plhs[]) {
  int i;
  double *dpointer;
  
  plhs[2]=mxCreateDoubleMatrix(1,6,mxREAL);
  dpointer=mxGetPr(plhs[2]);
  
  *dpointer=(double)paramOdex.IDID;dpointer++;
  for (i=17-1; i<=20-1; i++,dpointer++)
    *dpointer=(double)paramOdex.IWORK[i];
  
  *dpointer=paramOdex.h;
}

static void createHPred (mxArray* plhs[]) {  
  plhs[3]=mxCreateDoubleMatrix(1,1,mxREAL);
  
  *mxGetPr(plhs[3]) = paramOdex.h;
}

static void createOutput (int nlhs, mxArray* plhs[]) {
  createTXArrays(plhs);
  
  if (nlhs>=3) createStatVector(plhs);
  if (nlhs>=4) createHPred(plhs);
}

static void doInnerCall (int nlhs, mxArray *plhs[],
                          int nrhs, const mxArray *prhs[]) {
  /* So jetzt wird es trickreich: Wenn wir jetzt
       stopMexFunction(...);
     aufrufen, so ist das für Matlab tödlich!
     Begründung:
     Schauen wir uns jetzt einmal den Stack in diesem Moment an:
       odexMex (InnerCall)
       Matlab m-file
       odexMex (NormalCall)
       Matlab (bsp. Command-Line)
     Wenn ich jetzt stopMexFunction mache, dann wird ALLES
     von odexMex aufgeräumt und dann mexErrMsgTxt aufgerufen.
     Matlab will jetzt gepfelgt den kompletten Stack von oben
     nach unten abarbeiten und den Speicher aufräumen. Aber 
     da wären wir ja schon schneller gewesen, so dass Matlab
     auf dem Stack ungültige Speicherhandles findet ... und sich
     damit verabschiedet!! 
     Deshalb beenden wir uns jetzt, OHNE unseren Speicher 
     aufzuräumen. Damit verlassen wir uns darauf, dass Matlab
     unseren ganzen Sch... aufräumt! Dies sollte problemlos funktionieren,
     aber ich habe mich noch NIE auf sowas verlassen, bis jetzt ... */
  
  Fint i,ilast;
  double t;
  double *dpointer;
  const mxArray *tArg;
  mxArray *xArg;

  if ((nlhs!=1) || (nrhs!=1)) stopMexFunctionImpl(501,0,0,0,0,0,(char)0);

  tArg=prhs[0];
  if ((tArg==NULL) || (mxIsEmpty(tArg))) stopMexFunctionImpl(502,0,0,0,0,0,(char)0);

  if (!mxIsDouble(tArg) || (mxIsSparse(tArg)) ||
     (mxGetNumberOfDimensions(tArg)!=2) || 
     (mxGetM(tArg)!=1) || (mxGetN(tArg)!=1))
    stopMexFunctionImpl(503,0,0,0,0,0,(char)0);
  t= *mxGetPr(tArg);
  
  xArg=mxCreateDoubleMatrix(1,paramGlobal.d,mxREAL);
  dpointer=mxGetPr(xArg);
  ilast=tif_mws2Fint(paramGlobal.d);
  for (i=1; i<=ilast; i++,dpointer++) {
    *dpointer=CONTEX_(&i,&t,
      odexDense.con,odexDense.ncon,odexDense.icomp,odexDense.nd);
  }

  plhs[0]=xArg;
}

void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {  
  Fint d;
  /* check for inner call during Solout routine */
  if (isInnerCall && (nrhs==1)) {doInnerCall(nlhs,plhs,nrhs,prhs);return;}
  initVars();
  
  checkNumberOfArgs(nlhs,nrhs); 
  processArgs(nrhs,prhs);

  extractOptionsPart1();
  prepareIWorkArray();
  prepareWorkArray();
  extractOptionsPart2();
  prepareHelpMxArrays();
  
  d=tif_mws2Fint(paramGlobal.d);
  callOutputFcn(1,0.0,0.0,NULL,0);
  ODEX_ (&d,&OdexRightSideFunc,
    &paramOdex.tStart,paramOdex.xStart,&paramOdex.tEnd,
    &paramOdex.h,paramOdex.RTOL,paramOdex.ATOL,
    &paramOdex.ITOL,&OdexSoloutFunc,&paramOdex.IOUT,
    paramOdex.WORK,&paramOdex.LWORK,
    paramOdex.IWORK,&paramOdex.LIWORK,
    paramOdex.RPAR,paramOdex.IPAR,&paramOdex.IDID);
  callOutputFcn(2,0.0,0.0,NULL,0);
  
  createOutput(nlhs,plhs);
    
  doneVars();  
}

