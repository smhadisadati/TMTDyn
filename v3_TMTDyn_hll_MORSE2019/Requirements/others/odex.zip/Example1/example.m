opt=[];
opt.RelTol=1e-6;opt.AbsTol=1e-6;

[tNodes,xNodes,stats]=odexMex(@f,[0,3],1,opt);
% also possible (auch m�glich):
% [tNodes,xNodes,stats]=odexMex('f',[0,3],1,opt);
% [tNodes,xNodes,stats]=odexMex(inline('x','t','x'),[0,3],1,opt);

t=linspace(0,3,200);
plot(t,exp(t),'b-',tNodes,xNodes,'rx');

