function dx=f(t,x)
dx=x;
end