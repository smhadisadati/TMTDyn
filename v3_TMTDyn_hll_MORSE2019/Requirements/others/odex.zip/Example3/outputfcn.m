function status=outputfcn(t,x,flag,tOld)

if (isempty(flag) && (abs(t-tOld)>0))
    % Try to find event x==20 with bisection
    xOld=odexMex(tOld); % inner call during ouput function

    eOld=eventfcn(xOld);
    e=eventfcn(x);
    while (e*eOld<=0)
        tMid=tOld+0.5*(t-tOld);
        % Event is in interval [tOld,t], try bisection
        if (abs(t-tOld)<1e-5) 
            fprintf('Found event time t=%f.\n',tMid);
            status=1; % Stop Integration
            return;
        end
        eMid=eventfcn(odexMex(tMid));
        if (eOld*eMid<=0), e=eMid;t=tMid;else eOld=eMid;tOld=tMid;end
    end
end

status=0;
end

function erg=eventfcn(x)
erg=x-20.0;
end