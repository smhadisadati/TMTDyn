#ifndef odexMexh
#define odexMexh

#include "tif.h"

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* Extrapolation */
#define OPT_MAXEXCOLUMN "MaxExtrapolationColumn"
#define OPT_MAXNUMBEROFSTABCHECKS "MaxNumberOfStabilityChecks"
#define OPT_MAXSTABCHECKLINE "MaxLineForStabilityCheck"
#define OPT_INTERPOLDEGREE "DegreeOfInterpolation"
#define OPT_ORDERDECFRAC "OrderDecreaseFraction"
#define OPT_ORDERINCFRAC "OrderIncreaseFraction"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_MAXSTEPS "MaxNumberOfSteps"
#define OPT_STEPSIZESEQUENCE "StepSizeSequence"
#define OPT_MAXSS "MaxStep"
#define OPT_SSREDUCTION "StepSizeReduction"
#define OPT_SSSELECTPAR1 "StepSizeSelectionParam1"
#define OPT_SSSELECTPAR2 "StepSizeSelectionParam2"
#define OPT_SSSELECTPAR3 "StepSizeSelectionParam3"

/* Output */
#define OPT_DENSEOUTPUTWOEE "DeactivateErrorEstInDenseOutput"
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"

/* Rest */
#define OPT_EPS "eps"
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*OdexRightSide)(Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar);
  
typedef void (*OdexSolout)(Fint *nr, double *told,
  double *t, double *x, Fint *d, 
  double *con, Fint *ncon, Fint *icomp, Fint *nd,
  double *rpar, Fint *ipar, Fint *irtrn);

void OdexRightSideFunc (Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar);

void OdexSoloutFunc(Fint *nr, double *told,
    double *t, double *x, Fint *d, 
        double *con, Fint *ncon, Fint *icomp, Fint *nd,
        double *rpar, Fint *ipar, Fint *irtrn);

struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der Länge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  mwSize d;           /* Dimension des Systems */
  mwSize tLength;     /* Länge des t-Vektors */  
  double* tPointer;   /* Pointer auf Zeitdaten in tArray */  
  double direction;   /* sign(tEnd-tStart) */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterIO 
{ /* Parameter für Input/Output zwischen Matlab und C */    
  const mxArray *opt;  /* Optionen */
  char optCreated;     /* Flag, ob Optionen selbst generiert wurden */
};
typedef struct ParameterIO SParameterIO;

struct ParameterRightSide 
{ /* Parameter für rechte Seite f */
  char *rightSideFcn;           /* Funktionsname für rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function für rightSide */
  mxArray *tArg;                /* Zum Aufruf von f: t */
  mxArray *xArg;                /* Zum Aufruf von f: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterOdex
{ /* Parameter für odex */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double h;         /* Startschrittweite */  
  char denseFlag;   /* Flag, ob dense-Output aktiv */
  Fint maxExColumn; /* maximale Spalte im Extrapolationstableau */
  double *xStart;   /* Startwert */  
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  Fint ITOL;        /* Switch für RTOL und ATOL */      
  Fint IOUT;        /* Switch für SOLOUT */    
  double *WORK;     /* Double-Arbeits-Array */
  Fint LWORK;       /* Länge von WORK */
  Fint *IWORK;      /* Integer-Arbeits-Array */
  Fint LIWORK;      /* Länge von IWORK */  
  double *RPAR;     /* Zusatz double-array */
  Fint *IPAR;       /* Zusatz int-array */  
  Fint IDID;        /* Status */    
};
typedef struct ParameterOdex SParameterOdex;

struct ParameterOutput
{ /* Parameter zum Speichern der Odex-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  mwSize numberOfElements;    /* Anzahl der Einträge in txListe */
  mwSize tPos;                /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus für outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */
  mxArray *emptyArg;          /* Zum Aufruf von outputFcn: empty array [] */
  mxArray *toldArg;           /* Zum Aufruf von outputFcn: tOld */
};
typedef struct ParameterOutput SParameterOutput;

struct OdexDense
{ /* Argumente zum Aufruf von CONTEX */
  double *con;
  Fint *ncon;
  Fint *icomp;
  Fint *nd;
};
typedef struct OdexDense SOdexDense;

#ifdef FORTRANNOUNDER
/* Fotran functions without underscore */
#ifdef FORTRANUPP
/* Fotran functions without underscore  & UPPERCASE letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions without underscore & UPPERCASE letters & leading underscore */
#define ODEX_ _ODEX
#define CONTEX_ _CONTEX
#else
/* Fortran functions without underscore & UPPERCASE letters & without leading underscore */
#define ODEX_ ODEX
#define CONTEX_ CONTEX
#endif
#else
/* Fotran functions without underscore  & lowercase letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions without underscore & lowercase letters & leading underscore */
#define ODEX_ _odex
#define CONTEX_ _contex
#else
/* Fortran functions without underscore & lowercase letters & without leading underscore */
#define ODEX_ odex
#define CONTEX_ contex
#endif
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions with underscore & UPPERCASE letters & leading underscore */
#define ODEX_ _ODEX_
#define CONTEX_ _CONTEX_
#else
/* Fortran functions with underscore & UPPERCASE letters & without leading underscore*/
#endif
#else
/* Fortran functions with underscore & lowercase letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions with underscore & lowercase letters  & leading underscore*/
#define ODEX_ _odex_
#define CONTEX_ _contex_
#else
/* Fortran functions with underscore & lowercase letters  & without leading underscore*/
#define ODEX_ odex_
#define CONTEX_ contex_
#endif
#endif
#endif

extern void ODEX_ (Fint *n, OdexRightSide fcn,
  double *t, double *x, double *tend, double *h,
  double *rtol, double *atol, Fint *itol,
  OdexSolout solout, Fint *iout,
  double *work, Fint *lwork, Fint *iwork, Fint *liwork,
  double *rpar, Fint *ipar, Fint *idid);

extern double CONTEX_ (Fint *i, double *s, double *con, Fint *ncon,
  Fint *icomp, Fint *nd);

#endif
