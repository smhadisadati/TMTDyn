/* description of errors, included in dopri5Mex.c and dop853Mex */
/* Fehlerbeschreibungen, werden in dopri5Mex.c und dop853Mex.c included */

/* general Errors */
/* allgemeine Fehler */
case 1:
  tif_printInfos();
  MPR("English: \n");
  MPR("Only 2,3 or 4 output arguments are possible, but "FMTS" were requested.\n",i1);
  MPR("German: \n");
  MPR("Es werden 2,3 oder 4 Ausgabeargumente unterstützt. Verlangt wurden\n");
  MPR("aber "FMTS" Ausgabeargumente.\n",i1);
  msg="Invalid number of output arguments (Ungültige Anzahl von Ausgabeargumenten)";break;
case 2:
  MPR("English: \n");
  MPR("Only 3 or 4 input arguments are possible, but "FMTS" were passed.\n",i1);
  MPR("German: \n");
  MPR("Es werden 3 oder 4 Eingabeargumente unterstützt. Es wurden aber\n");
  MPR(""FMTS" Argumente übergeben.\n",i1);
  msg="Invalid number of input arguments (Ungültige Anzahl von Eingabeargumenten)";break;
case 3:
  MPR("English: \n");
  MPR("1st argument has to be a string (function name), a function handle\n");
  MPR("or an inline function.\n");
  MPR("German: \n");
  MPR("1. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  MPR("oder eine inline-Funktion sein.\n");
  msg="1. Arg: Function (String,handle,inline) expected";break;
case 4:
  MPR("English: \n");
  MPR("1st argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a matrix containing strings.");
  MPR("\n");
  MPR("German: \n");
  MPR("1. Argument enthält Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine Matrix aus Strings.");
  MPR("\n");
  msg="1. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 5:
  MPR("English: \n");
  MPR("2nd argument has to be a double row vector.\n");
  MPR("German: \n");
  MPR("2. Argument muss ein double-Zeilenvektor sein.\n");
  msg="2. Arg: double row vector expected (double-Vektor erwartet)";break;
case 6:
  MPR("English: \n");
  MPR("2nd argument has to be a double row vector. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a double matrix");
  MPR("\n");
  MPR("German: \n");
  MPR("2. Argument muss ein double-Vektor sein. ");
  if (i1!=2)
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine double-Matrix.");
  MPR("\n");
  msg="2. Arg: (1,k) double vector expected ((1,k) double-Vektor erwartet)";break;
case 7:
  MPR("English: \n");
  MPR("2nd argument has to be a double vector with at least 2 components.\n");
  MPR("The length of the vector found is "FMTS".\n",paramGlobal.tLength);
  MPR("German: \n");
  MPR("2. Argument muss double-Vektor mit mindestens der\n");
  MPR("Länge 2 sein. Der übergebene Vektor hat Länge "FMTS".\n",
    paramGlobal.tLength);
  msg="2. Arg: (1,k) double vector (k>=2) expected ((1,k) double-Vektor (k>=2) erwartet)";break;
case 8:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector.\n");
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor sein.\n");
  msg="3. Arg: double vector expected (double-Vektor erwartet)";break;
case 9:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector.\n");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a double matrix");
  MPR("\n");
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor sein. ");
  if (i1!=2)
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine double-Matrix.");
  MPR("\n");
  msg="3. Arg: (d,1) double vector expected ((d,1) double-Vektor erwartet)";break;
case 10:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector with at least one component.\n");
  MPR("The length of the vector found was "FMTS".\n",d);
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor mit mindestens\n");
  MPR("der Länge 1 sein. Der übergebene Vektor hat Länge "FMTS".\n",d);
  msg="3. Arg: (d,1) double vector (d>=1) expected ((d,1) double-Vektor (d>=1) erwartet)";break;    
case 11:
  MPR("English: \n");
  MPR("4th argument has to be a struct.\n");
  MPR("German: \n");
  MPR("4. Argument muss eine struct sein.\n");
  msg="4. Arg: struct expected (struct erwartet)";break;
case 12:
  MPR("English: \n");
  MPR("2nd arg: start- and end-time are the same.\n");
  MPR("German: \n");
  MPR("2. Argument: Start- und Endzeitpunkt dürfen nicht\n");
  MPR("übereinstimmen!\n");
  msg="2. Arg: tStart==tEnd";break;  
case 14:
  MPR("English: \n");
  MPR("2nd argument has to be ordered.\n");
  if (i1>0)
    MPR("Because of %f=tStart<tEnd=%f, the 2nd argument has to be ascending.\n",
      paramOdex.tStart,paramOdex.tEnd);
  else
    MPR("Because of %f=tStart>tEnd=%f, the 2nd argument has to be descending.\n",
      paramOdex.tStart,paramOdex.tEnd);
  MPR("German: \n");
  MPR("2. Argument muss sortiert sein.\n");
  if (i1>0)
    MPR("Da %f=tStart<tEnd=%f ist, muss das zweite Argument steigend\n",
     paramOdex.tStart,paramOdex.tEnd); 
  else    
    MPR("Da %f=tStart>tEnd=%f ist, muss das zweite Argument fallend\n",
     paramOdex.tStart,paramOdex.tEnd); 
  MPR("sortiert sein.\n");
  msg="2. Arg: has to be ordered (muss sortiert sein)";break;
case 15:
  MPR("English: \n");
  MPR("1st argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Not a matrix containing inline-funcs or function handles.");
  MPR("\n");
  MPR("German: \n");
  MPR("1. Argument enthält zwar Inline-Funktionen oder Funktions-Handles, aber");
  MPR("benötigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  MPR("\n");
  msg="1. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 16:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Requirement: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es muss gelten: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  msg="Invalid call method (ungültige Methode für Funktionsaufruf)";break;
case 17:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  MPR("But the rightSide was not a string.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es wurde '%s'==0 gewählt. Also müssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  MPR("Aber die rechte Seite war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: müssen Funktionsnamen übergeben werden)";break;
case 18:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("'%s'==0 was chosen. Hence the all Matlab-functions must be given as string.\n",
    OPT_FUNCCALLMETHOD);
  MPR("But the Output Function was not a string.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es wurde '%s'==0 gewählt. Also müssen alle Matlab-Funktionen als String angegeben werden.\n",
    OPT_FUNCCALLMETHOD);
  MPR("Aber die Output Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: müssen Funktionsnamen übergeben werden)";break;
case 19:
  MPR("English: \n");
  MPR("2nd or 3rd argument is too large (length is "FMTS"). I was compiled\n",i1);
  MPR("with a maximal vector size of "FMTS". Try recompiling\n",i2);
  MPR("with largeArrayDims turned on.\n");
  MPR("German: \n");
  MPR("2. oder 3. Argument ist zu groß (Länge ist "FMTS"). Ich wurde für \n",i1);
  MPR("Vektoren mit maximal "FMTS" Einträge kompiliert. Versuchen\n",i2);
  MPR("Sie ein erneutes Kompilieren mit aktivierten largeArrayDims.\n");
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;
case 20:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_RTOL);
  MPR("'%s' was too large (length is "FMTS") for mwSize.\n",OPT_RTOL,i1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_RTOL);
  MPR("'%s'==0 war zu groß (Länge ist "FMTS") für mwSize.\n",OPT_RTOL,i1);
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;
case 21:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_ATOL);
  MPR("'%s' was too large (length is "FMTS") for mwSize.\n",OPT_RTOL,i1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_ATOL);
  MPR("'%s'==0 war zu groß (Länge ist "FMTS") für mwSize.\n",OPT_RTOL,i1);
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;

/* Errors concering WORK and IWORK-options */
/* Fehler bei WORK und IWORK-Options */
case 200:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_MAXEXCOLUMN);
  MPR("Requirement: 3<='%s'.\n",OPT_MAXEXCOLUMN);
  MPR("But I found: '%s'="FMTS".\n",OPT_MAXEXCOLUMN,paramOdex.maxExColumn);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXEXCOLUMN);
  MPR("Es muss gelten: 3<='%s'.\n",OPT_MAXEXCOLUMN);
  MPR("Gefunden wurde aber '%s'="FMTS".\n",OPT_MAXEXCOLUMN,paramOdex.maxExColumn);
  msg="invalid maximal columns in tableau for extrapolation (ungültige max. Anzahl von Spalten im Extrapolationstableau";break;
case 201:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXSTEPS);
  MPR("Requirement: 0<'%s'.\n",OPT_MAXSTEPS);
  MPR("But I found '%s'=%li.\n",OPT_MAXSTEPS,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXSTEPS);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_MAXSTEPS);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_MAXSTEPS,l1);
  msg="invalid maximal number of steps (ungültige maximale Schrittanzahl)";break;
case 202:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_STEPSIZESEQUENCE);
  MPR("Requirement: 1<='%s'<=5.\n",OPT_STEPSIZESEQUENCE);
  MPR("But I found '%s'=%li.\n",OPT_STEPSIZESEQUENCE,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_STEPSIZESEQUENCE);
  MPR("Es muss gelten: 1<='%s'<=5.\n",OPT_STEPSIZESEQUENCE);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_STEPSIZESEQUENCE,l1);
  msg="invalid step size sequence (ungültige Angabe bei der Schrittweitenabfolge)";break;
case 203:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXNUMBEROFSTABCHECKS);
  MPR("Requirement: 1<='%s'.\n",OPT_MAXNUMBEROFSTABCHECKS);
  MPR("But I found '%s'=%li.\n",OPT_MAXNUMBEROFSTABCHECKS,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXNUMBEROFSTABCHECKS);
  MPR("Es muss gelten: 1<='%s'.\n",OPT_MAXNUMBEROFSTABCHECKS);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_MAXNUMBEROFSTABCHECKS,l1);
  msg="invalid number of maximal stability checks (ungültige Angabe für max. Anzahl von Stabilitätsprüfungen)";break;  
case 204:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXSTABCHECKLINE);
  MPR("Requirement: 1<='%s'.\n",OPT_MAXSTABCHECKLINE);
  MPR("But I found '%s'=%li.\n",OPT_MAXSTABCHECKLINE,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXSTABCHECKLINE);
  MPR("Es muss gelten: 1<='%s'.\n",OPT_MAXSTABCHECKLINE);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_MAXSTABCHECKLINE,l1);
  msg="invalid last line for stability check (ungültige Angabe für letztmögliche Zeile bei Stabilitätsprüfung)";break;
case 205:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_DENSEOUTPUTWOEE);
  MPR("Requirement: 0<='%s'<=1.\n",OPT_DENSEOUTPUTWOEE);
  MPR("But I found '%s'=%li.\n",OPT_DENSEOUTPUTWOEE,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_DENSEOUTPUTWOEE);
  MPR("Es muss gelten: 0<='%s'<=1.\n",OPT_DENSEOUTPUTWOEE);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_DENSEOUTPUTWOEE,l1);
  msg="invalid flag for dense output without error estimator (ungültige Angabe beim Flag: dense output ohne Fehlerschätzung)";break;
case 206:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_INTERPOLDEGREE);
  MPR("Requirement: 1<='%s'<=6.\n",OPT_INTERPOLDEGREE);
  MPR("But I found '%s'=%li.\n",OPT_INTERPOLDEGREE,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_INTERPOLDEGREE);
  MPR("Es muss gelten: 1<='%s'<=6.\n",OPT_INTERPOLDEGREE);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_INTERPOLDEGREE,l1);
  msg="invalid number for degree determination of interpolation formula (ungültige Angabe zur Bestimmung des Interpolationsgrades)";break;
case 207:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_EPS);
  MPR("Requirement: 0<'%s'.\n",OPT_EPS);
  MPR("But I found '%s'=%e.\n",OPT_EPS,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_EPS);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_EPS);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_EPS,d1);
  msg="invalid precision (ungültige Maschinengenauigkeit)";break;
case 208:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXSS);
  MPR("Requirement: '%s'!=0.\n",OPT_MAXSS);
  MPR("But I found '%s'=%e.\n",OPT_MAXSS,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXSS);
  MPR("Es muss gelten: '%s'!=0.\n",OPT_MAXSS);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_MAXSS,d1);
  msg="invalid maximal number of steps (ungültige maximale Schrittweite)";break;
case 209:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_SSREDUCTION);
  MPR("Requirement: 0<'%s'<1.\n",OPT_SSREDUCTION);
  MPR("But I found '%s'=%e.\n",OPT_SSREDUCTION,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSREDUCTION);
  MPR("Es muss gelten: 0<'%s'<1.\n",OPT_SSREDUCTION);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSREDUCTION,d1);
  msg="invalid step size reduction (ungültige Schrittweitenreduktion)";break;
case 210:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_SSSELECTPAR1);
  MPR("Requirement: 0<'%s'.\n",OPT_SSSELECTPAR1);
  MPR("But I found '%s'=%e.\n",OPT_SSSELECTPAR1,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSSELECTPAR1);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_SSSELECTPAR1);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR1,d1);
  msg="invalid first step size control parameter (ungültiger erster Schrittweitensteuerungsparameter)";break;
case 211:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_SSSELECTPAR2);
  MPR("Requirement: 0<'%s'.\n",OPT_SSSELECTPAR2);
  MPR("But I found '%s'=%e.\n",OPT_SSSELECTPAR2,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSSELECTPAR2);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_SSSELECTPAR2);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR2,d1);
  msg="invalid second step size control parameter (ungültiger zweiter Schrittweitensteuerungsparameter)";break;
case 212:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_ORDERDECFRAC);
  MPR("Requirement: 0<'%s'.\n",OPT_ORDERDECFRAC);
  MPR("But I found '%s'=%e.\n",OPT_ORDERDECFRAC,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_ORDERDECFRAC);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_ORDERDECFRAC);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_ORDERDECFRAC,d1);
  msg="invalid factor for decreasing order (ungültiger Faktor für Ordnungsreduzierung)";break;
case 213:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_ORDERINCFRAC);
  MPR("Requirement: 0<'%s'.\n",OPT_ORDERINCFRAC);
  MPR("But I found '%s'=%e.\n",OPT_ORDERINCFRAC,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_ORDERINCFRAC);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_ORDERINCFRAC);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_ORDERINCFRAC,d1);
  msg="invalid factor for increasing order (ungültiger Faktor für Ordnungserhöhung)";break;
case 214:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_RHO);
  MPR("Requirement: 0<'%s'.\n",OPT_RHO);
  MPR("But I found '%s'=%e.\n",OPT_RHO,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_RHO);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_RHO);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_RHO,d1);
  msg="invalid value for safety factor in step size prediction (ungültiger Sicherheitsfaktor bei der Schrittweitensteuerung)";break;
case 215:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_SSSELECTPAR3);
  MPR("Requirement: 0<'%s'.\n",OPT_SSSELECTPAR3);
  MPR("But I found '%s'=%e.\n",OPT_SSSELECTPAR3,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSSELECTPAR3);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_SSSELECTPAR3);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSSELECTPAR3,d1);
  msg="invalid thrid step size control parameter (ungültiger dritter Schrittweitensteuerungsparameter)";break;
case 216:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_INITIALSS);
  MPR("Requirement: 0<'%s'.\n",OPT_INITIALSS);
  MPR("But I found '%s'=%e.\n",OPT_INITIALSS,paramOdex.h);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_INITIALSS);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_INITIALSS);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_INITIALSS,paramOdex.h);
  msg="invalid first step size (ungültige Startschrittweite)";break;

/* Errors concering rightSide */
/* Fehler im Zusammenhang mit der rechten Seite */
case 301:
  MPR("English: \n");
  MPR("Problem calling the right side '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("I have not got return values.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("Habe keine Rückgabe erhalten.\n");
  msg="Right side without return values (Rechte Seite ohne Rückgabe)";break;
case 302:
  MPR("English: \n");
  MPR("Problem calling the right side '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("Return value was not a double vector.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("Die Rückgabe war kein double-Vektor.\n");
  msg="Return value was not a double vector (Rückgabe der rechten Seite kein double-Vektor)";break;
case 303:
  MPR("English: \n");
  MPR("Problem calling the right side '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("The return value was not a (d,1) or (1,d) double Vector.\n");
  MPR("A ("FMTS","FMTS") double matrix was returned.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite '%s'\n",
    paramRightSide.rightSideFcn);
  MPR("Die Rückgabe war kein (d,1) oder (1,d) double-Vektor.\n");
  MPR("Es wurde eine ("FMTS","FMTS") double-Matrix zurückgegeben.\n",i1,i2);
  msg="Return value of right side was not a (d,1) or (1,d) double vector (Rückgabe der rechten Seite kein (d,1) oder (1,d) double-Vektor)";break;

/* Errors concering output options */
/* Fehler im Zusammenhang mit Output Options */
case 401:
  MPR("English: \n");
  MPR("Concering option '%s':\n",OPT_OUTPUTFUNCTION);
  MPR("Option contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Not a matrix containing inline-funcs or function handles.");
  MPR("\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_OUTPUTFUNCTION);
  MPR("Option enthält zwar Inline-Funktionen oder Funktions-Handles, aber");
  MPR("benötigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  MPR("\n");
  msg="only ONE function expected (nur EINE Funktion erwartet)";break;

/* Errors in inner Call during SolOut routine */
/* Fehler während des inner Calls zum Zeitpunkt der SolOut Routine */
case 501:
  MPR("English:\n");
  MPR("Only one input and output argument is allowed\n");
  MPR("in a call during the output function.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Bei Aufrufen innerhalb der Output Function wird nur\n");
  MPR("ein Eingabe- und ein Ausgabeargument unterstützt.\n");
  msg="wrong number of input and/or output parameters";break;
case 502:
  MPR("English:\n");
  MPR("1st input argument in the call during the ouput function is empty.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Das erste Eingabeargument während des Aufrufs aus der Output Function ist leer.\n");
  msg="1st arg was empty at call inside output function";break;
case 503:
  MPR("English:\n");
  MPR("1st input argument in the call during the ouput function\n");
  MPR("must be a scalar.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Das erste Eingabeargument während des Aufrufs aus der\n");
  MPR("Output Function muss ein Skalar sein.\n");
  msg="1st arg at call inside output function must be a scalar";break;

/* Errors that should never occur */
/* Fehler, die niemals auftreten sollten */
case 1001:
  msg="internal error: callOutputFcn: unknown reason";
  break;
case 1002:
  msg="internal error: unknown funcCallMethod";
  break;
