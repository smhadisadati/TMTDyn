% English:
% ========
% ODEXMEX: Interface for ODEX
% [tNodes,xNodes,stats,taupred]=ODEXMex(f,t,x0,opt)
%
% Input:
%   f       right side: Either the name of a function or
%           a function handle or an inline function
%           Function must be declared as
%             function dx=f(t,x)
%           (also see "FuncCallMethod" option)
%   t       row (double) vector containing the t nodes where the
%           solution has to be evaluated. Minimal requirement: 
%           two components (Start- and End-value). If t has more than two
%           components then dense output will be enabled.
%   x0      (d,1) double-Startvector (d dimension)
%   opt     optional struct with options; see below 
% 
% Output:
%   tNodes  evaluated t nodes 
%   xNodes  solution at nodes in t 
%   stats   optional (1,6) vector for statistics:
%           1. IDID of ODEX: 
%              +1 successfull intergration
%              -1 early abort
%           2. number of f-evaluations 
%           3. number of calculated steps 
%           4. number of accepted steps 
%           5. number of discarded steps 
%           6. next step size prediction
%   taupred optional scalar for the next step size prediction
% 
% Options:
% (in round braces: defaults)   
% [in square brackets: parameter name in ODEX] 
% 
% If a option is needed and not found in the opt struct (or even the opt struct
% is missing), then the default-value in braces are used.
%
%  * RelTol (1e-3) [RTOL]
%      relative tolerance 
%      either RelTol and AbsTol are both scalars or both are
%      (d,1) double vectors with RelTol and AbsTol for each
%      component.
%  * AbsTol (1e-6) [ATOL]
%      absolute tolerance 
%      either RelTol and AbsTol are both scalars or both are
%      (d,1) double vectors with RelTol and AbsTol for each
%      component.
%  * eps (2.3e-16) [WORK(1)]
%      rounding unit
%  * InitialStep (1e-6) [H]
%      initial step size. Requirement: InitialStep>0. 
%  * MaxNumberOfSteps (10000) [IWORK(1)]
%      maximal number of steps. Requirement: MaxNumberOfSteps>0.
%  * MaxStep (tEnd-tStart) [WORK(2)]
%      maximal step size. Requirement: MaxStep!=0 
%  * StepSizeReduction (0.5) [WORK(3)]
%      factor for reducing the step size after stability check is negative.
%      Requirement: 0<StepSizeReduction<1 sein.
%  * StepSizeSelectionParam1 (0.02) [WORK(4)] 
%  * StepSizeSelectionParam2 (4.0) [WORK(5)] 
%      parameters for step size selection. The new step size for
%      the j-th diagonal entry is chosen such, that
%        facmin/StepSizeSelectionParam2 <= tauNew(j)/tauOld <= 1/facmin
%      where facmin=StepSizeSelectionParam1^(1/(2*j-1)).
%      Requirement: StepSizeSelectionParam1,StepSizeSelectionParam2>0.
%  * OrderDecreaseFraction (0.8) [WORK(6)] 
%  * OrderIncreaseFraction (0.9) [WORK(7)]
%      parameters for order selection. The order is
%        decreased if  W(K-1) <= W(K)  *OrderDecreaseFraction
%        increased if  W(K)   <= W(K-1)*OrderIncreaseFraction
%      Requirement: OrderDecreaseFraction,OrderIncreaseFraction>0.
%  * StepSizeSelectionParam3 (0.65) [WORK(8)]
%  * rho (0.94) [WORK(9)]
%      safety factors for step size control
%      Hnew=Hold*rho*(StepSizeSelectionParam3*Tol/Err)^(1/(j-1))
%      Requirement: StepSizeSelectionParam3,rho>0.
%  * MaxExtrapolationColumn (9) [IWORK(2)]
%      maximal number of columns in the extrapolation table. 
%      Requirement: MaxExtrapolationColumn>=3.
%  * StepSizeSequence (1 without dense output, 4 with dense output) [IWORK(3)]
%      Switch for choosing step size sequence. Requirement: 1<=StepSizeSequence<=5
%           1: 2,4,6,8,10,12,14,16,...
%           2: 2,4,8,12,16,20,24,28,...
%           3: 2,4,6,8,12,16,24,32,...
%           4: 2,6,10,14,18,22,26,30,...
%           5: 4,8,12,16,20,24,28,32,...
%  * MaxNumberOfStabilityChecks (1) [IWORK(4)]
%      stability check is activated at most MaxNumberOfStabilityChecks
%      times in one line of the extrapolation table. 
%  * MaxLineForStabilityCheck (1) [IWORK(5)]
%      stability check is activated only in the lines 1 to MaxLineForStabilityCheck
%  * DeactivateErrorEstInDenseOutput (0) [IWORK(6)]
%      Switch to deactivate the error estimator for dense output.
%  * DegreeOfInterpolation (4) [IWORK(7)]
%      Determines the degree of interpolation
%        mu = 2*kappa - DegreeOfInterpolation + 1
%      Requirement: 1<=DegreeOfInterpolation<=6.
% 
% --- Below are the options for the MEX-File; they do not belong to ODEX
%
%  * IncludeGridPointsInDenseOutput (0) 
%      if t has more than two components, dense output will be
%      enabled to make it possible to evaluate the solution at the
%      given t nodes. For the output vectors (tNodes,xNodes) there
%      are two possibilites:
%      If IncludeGridPointsInDenseOutput is 0, then (tNodes,xNodes) 
%      consists only of the evaluted solution at the given nodes.
%      If IncludeGridPointsInDenseOutput is not 0, then also the
%      additionally generated nodes are included.
%  * OutputFcn (<none>)
%      Output Function (name, handle or inline)
%      Let the name of the output function be outfcn. At the
%      beginning of the integration outfcn is called:
%      outfcn([tStart,tEnd],x0,'init')
%      After every successfull integration step outfcn is called:
%      status=outfcn(t,x,[],tOld) 
%      If outfcn returns status=1, then the integration is stopped/aborted
%      (even if tEnd was not reached).
%      At the end of the integration outfcn is called:
%      outfcn([],[],'done')
%      If dense output is enabled you can call odexMex INSIDE the
%      OutputFcn to get the solution at intermediate values in
%      the intervall [tOld,t], e.g.
%        xCenter = odexMex(tOld + 0.5*(t-tOld));
%      This is called an inner call or an call inside the output routine.
%      You can use this for Event Location.
%      There are already output functions available in Matlab:
%      cf: odeplot, odephas2, odephas3, odeprint
%  * OutputCallMode (1)
%      only relevant if dense output is enabled and an output function is given.
%      OutputCallMode defines when outfcn got called:
%        1 at the nodes given in t
%        2 at the nodes generated by ODEX
%        3 case 1 and 2
%  * FuncCallMethod (1)
%      option to indicate, which method to use for calling external functions 
%      (like the right side or the output function) 
%        0 call maxCALLMATLAB direct
%          then ONLY names (strings) can be passed for functions
%        1 use maxCALLMATLAB to call feval
%          then ALSO function handles and inline-functions can be used
%  * OptWarnMiss (0)
%      Flag to warn if option is missing 
%        1 Warn if needed option in opt-struct is missing
%        0 don't warn
%  * OptWarnType (1)
%      Flag to warn if wrong type is found in options 
%        1 warn if a entry with wrong type is found in opt struct
%        0 don't warn
%  * OptWarnSize (1)
%      Flag to warn if option value has wrong size 
%        1 warn if a option value has wrong size 
%        0 don't warn
%
% The opt struct can be generated with odeset, although there are
% some additional entries and some other entries are missing. With
% odeset ONLY the following parameters can be set:
%  AbsTol,RelTol,OutputFcn,InitialStep,MaxStep,Jacobian,Mass
%
%  IMPORTANT NOTICE (if the right side is also a MEX-File)
%     the right side must not "garble" the passed mxArrays:
%     the size must not be changed and the memory must not
%     be freed. 
%     Hence: the right side has to take care, that the
%     passed mxArrays have the same size and enough memory
%     when returning. The values in the memory(-block)
%     may be overwritten.
%     If the right side is an m-file MATLAB obeys this
%     restriction automatically.
%
%
%
% German:
% =======
% ODEXMEX: Interface zu ODEX
% [tNodes,xNodes,stats,taupred]=ODEXMex(f,t,x0,opt)
% Input:
%   f       rechte Seite: entweder Funktionsname oder Funktions-Handle
%           oder inline-Funktion
%           Funktion muss folgende Form haben:
%             function dx=f(t,x)
%           (siehe in diesem Zusammenhang "FuncCallMethod" Option)
%   t       Zeilenvektor mit auszuwertenden t Stellen, muss mindestens 
%           2 Werte (Start- und Endwert) enthalten. Bei mehr als zwei Werten
%           wird auf dense-Output umgeschaltet
%   x0      (d,1) double-Startvektor (d Dimension)
%   opt     optionale struct mit Optionen: vgl. Beschreibung unten
% 
% Output:
%   tNodes  ausgewertete t Zeitpunkte
%   xNodes  Lösung für Zeitpunkte tNodes
%   stats   optionaler (1,6)-Vektor mit Statistik:
%           1. IDID von ODEX: 
%              +1 Erfolgreiche Integration
%              -1 vorzeitiger Abbruch
%           2. Anzahl der f-Auswertungen
%           3. Anzahl der berechneten Schritte
%           4. Anzahl der akzeptierten Schritte
%           5. Anzahl der verworfenen Schritte 
%           6. Schrittweitenvorschlag des letzten Schritts
%   taupred optionaler Skalar mit dem nächsten Schrittweitenvorschlag
% 
% Optionen:
% (in runden Klammern: defaults)
% [in eckigen Klammern: entsprechender Name bei ODEX]
%
% Falls eine Option benötigt wird und nicht in der opt-struct vorhanden ist 
% (oder die opt-struct selbst fehlt), so wird der in Klammern angegebene
% default-Wert verwendet.
%
%  * RelTol (1e-3) [RTOL]
%      relative Toleranz 
%      entweder sind RelTol und AbsTol beide Skalare oder beide 
%      (d,1)-double-Vektoren für die einzelnen Zustands-Komponenten
%  * AbsTol (1e-6) [ATOL]
%      absolute Toleranz 
%      entweder sind RelTol und AbsTol beide Skalare oder beide 
%      (d,1)-double-Vektoren für die einzelnen Zustands-Komponenten
%  * eps (2.3e-16) [WORK(1)]
%      Maschinengenauigkeit. Es muss eps>0 sein.
%  * InitialStep (1e-6) [H]
%      Startschrittweite. Es muss InitialStep>0 sein.
%  * MaxNumberOfSteps (10000) [IWORK(1)]
%      maximale Anzahl von Schritten. Es muss MaxNumberOfSteps>0 sein.
%  * MaxStep (tEnd-tStart) [WORK(2)]
%      größtmögliche Schrittweite. Es muss MaxStep!=0 sein.
%  * StepSizeReduction (0.5) [WORK(3)]
%      Faktor, um den die Schrittweite reduziert wird, wenn
%      der Stabilitätstest negativ ausfällt. Es muss
%        0<StepSizeReduction<1 sein.
%  * StepSizeSelectionParam1 (0.02) [WORK(4)] 
%  * StepSizeSelectionParam2 (4.0) [WORK(5)] 
%      Parameter für die Schrittweitenwahl. Die neue Schrittweite
%      für den j-ten Diagonaleintrag wird so gewählt, dass 
%        facmin/StepSizeSelectionParam2 <= tauNew(j)/tauOld <= 1/facmin
%      gilt. Dabei ist facmin=StepSizeSelectionParam1^(1/(2*j-1)).
%      Es muss StepSizeSelectionParam1,StepSizeSelectionParam2>0 sein.
%  * OrderDecreaseFraction (0.8) [WORK(6)] 
%  * OrderIncreaseFraction (0.9) [WORK(7)]
%      Parameter für die Ordnungssteuerung. Die Ordnung wird
%        erniedrigt, falls  W(K-1) <= W(K)  *OrderDecreaseFraction
%        erhöhlt   , falls  W(K)   <= W(K-1)*OrderIncreaseFraction
%      Es muss OrderDecreaseFraction,OrderIncreaseFraction>0 sein.
%  * StepSizeSelectionParam3 (0.65) [WORK(8)]
%  * rho (0.94) [WORK(9)]
%      Sicherheitsfaktoren bei der Schrittweitensteuerung.
%      Hnew=Hold*rho*(StepSizeSelectionParam3*Tol/Err)^(1/(j-1))
%      Es muss StepSizeSelectionParam3,rho>0 sein.
%  * MaxExtrapolationColumn (9) [IWORK(2)]
%      Die maximal mögliche Anzahl von Spalten im Extrapolationstableau.
%      Es muss MaxExtrapolationColumn>=3 gelten.
%  * StepSizeSequence (1 ohne dense output, 4 bei dense output) [IWORK(3)]
%      Legt die Schrittweitenfolge fest. Es muss gelten
%      1<=StepSizeSequence<=5, wobei gilt:
%           1: 2,4,6,8,10,12,14,16,...
%           2: 2,4,8,12,16,20,24,28,...
%           3: 2,4,6,8,12,16,24,32,...
%           4: 2,6,10,14,18,22,26,30,...
%           5: 4,8,12,16,20,24,28,32,...
%  * MaxNumberOfStabilityChecks (1) [IWORK(4)]
%      Der Stabilitätstest wird höchstens MaxNumberOfStabilityChecks
%      pro Zeile im Extrapolationstableau aktiviert.
%  * MaxLineForStabilityCheck (1) [IWORK(5)]
%      Der Stabilitätstest wird im Extrapolationstableu nur in den
%      Zeilen 1 bis MaxLineForStabilityCheck aktiviert.
%  * DeactivateErrorEstInDenseOutput (0) [IWORK(6)]
%      Hiermit kann man den Fehlerschätzer während der kontinuierlichen
%      Ausgabe deaktivieren. 
%  * DegreeOfInterpolation (4) [IWORK(7)]
%      Legt fest, wie der Grad der Interpolationsformel bestimmt wird:
%        mu = 2*kappa - DegreeOfInterpolation + 1
%      Es muss gelten: 1<=DegreeOfInterpolation<=6
% 
% --- Ab jetzt kommen Optionen, die zum MEX-File gehören,
% --- nicht mehr zu DOPRI.
%
%  * IncludeGridPointsInDenseOutput (0) 
%      falls t mehr als zwei Werte enthält, wird auf dense-Output 
%      umgeschaltet, damit an den angegeben Stellen ausgewertet werden kann.
%      Für die Ausgabe (tGitter,xGitter) gibt es nun zwei Möglichkeiten: 
%      IncludeGridPointsInDenseOutput ist 0, dann enthält (tGitter,xGitter) 
%      nur die Ausgabe an den vorgegebenen Stellen. Ist  
%      IncludeGridPointsInDenseOutput verschieden von 0, so werden 
%      zusätzlich auch noch die von ODEX generierten Gitterpunkte 
%      ausgegeben.
%  * OutputFcn (<keine>)
%      Output Funktion (Name oder Handle oder Inline)
%      Sei der Name der OutputFunction outfcn. Dann wird zu Beginn der 
%      Integration aufgerufen: 
%      outfcn([tStart,tEnd],x0,'init'). 
%      Nach jedem erfolgreichen Integrationsschritt wird aufgerufen: 
%      status=outfcn(t,x,[],tOld).
%      Liefert outfcn einen status=1, so wird die Integration abgebrochen 
%      (auch wenn tEnd noch nicht erreicht). Sonst geht es weiter. Am Ende 
%      der Integration wird aufgerufen: 
%      outfcn([],[],'done')
%      Falls die kontinuierliche Ausgabe (dense output) aktiviert ist,
%      kann man odexMex INNERHALB der OutputFcn aufrufen, um die
%      Lösung an Zwischenstellen im Intervall [tOld,t] zu bekommen, z.B.
%        xCenter = odexMex(tOld + 0.5*(t-tOld));
%      Das wird inner call oder Aufruf aus der Output Routine genannt.
%      Dies kann für Event Location verwendet werden.
%      Es gibt schon vorgefertigte OutputFunctions in Matlab:
%      vgl.: odeplot, odephas2, odephas3, odeprint
%  * OutputCallMode (1)
%      nur bei dense-Output mit OutputFunction interessant. Bestimmt wann 
%      outfcn aufgerufen wird:
%        1 bei den in t angegeben Stellen
%        2 bei den von ODEX erstellen Gitterpunkten
%        3 sowohl 1 und 2
%  * FuncCallMethod (1)
%      gibt an, welche Methode zum Aufruf "externer" Funktionen (z.B.
%      rechte Seite oder Output-Funktion) verwendet werden soll:
%        0 direkt mexCallMATLAB verwenden 
%          dann können NUR Funktionsnamen übergeben werden
%        1 feval mit mexCALLMATLAB verwenden
%          dann können AUCH Funktions-Handle und Inline-Funktionen
%          übergeben werden.
%  * OptWarnMiss (0)
%      Warnungsflag bei fehlenden Optionen
%        1 Warnung, wenn in opt-struct eine benötigte Option fehlt
%        0 keine Warnung
%  * OptWarnType (1)
%      Warnungsflag bei Optionen mit falschem Typ
%        1 Warnung, wenn in opt-struct ein Eintrag den falschen Datentyp hat
%        0 keine Warnung
%  * OptWarnSize (1)
%      Warnungsflag bei Optionen mit falscher Größe
%        1 Warnung, wenn in opt-struct ein Eintrag die falsche Größe hat
%        0 keine Warnung
%
% opt kann auch mit odeset generiert werden, obwohl dort dann  mehr 
% Felder generiert werden, als benötigt und einige Optionen von hier 
% nicht unterstützt werden. Also kann man mit odeset NUR einstellen:
%  AbsTol,RelTol,OutputFcn,InitialStep,MaxStep,Jacobian,Mass
%
%  WICHTIGE Anmerkung (falls rechte Seite "f" auch MEX-File ist)
%     die rechte Seite darf die übergebenen mxArrays nicht "verstümmeln": 
%     die Größe darf nicht verändert werden und auch der Speicherplatz 
%     darf nicht freigegeben werden. Also: die rechte Seite muss 
%     sicherstellen, dass die übergebenen mxArrays am Ende wieder 
%     diesselbe Größe und ausreichend Speicher haben. Der Speicher 
%     selbst darf natürlich zu rechenzwecken überschrieben werden.
%     Bei m-Files muss man darauf keine Rücksicht nehmen, denn da achtet 
%     MATLAB automatisch darauf.
%
