#ifndef radau5Mexh
#define radau5Mexh

#include "tif.h"

/* Optionsettings */
#define OPT_WARNMISS "OptWarnMiss"
#define OPT_WARNTYPE "OptWarnType"
#define OPT_WARNSIZE "OptWarnSize"

/* H and Tols */
#define OPT_INITIALSS "InitialStep"
#define OPT_RTOL "RelTol"
#define OPT_ATOL "AbsTol"

/* Output */
#define OPT_OUTPUTFUNCTION "OutputFcn"
#define OPT_OUTPUTCALLMODE "OutputCallMode"

/* StepSizeSelection */
#define OPT_RHO "rho"
#define OPT_SSMINSEL "StepSizeMinSelection"
#define OPT_SSMAXSEL "StepSizeMaxSelection"
#define OPT_FREEZESSLEFT "FreezeStepSizeLeftBound"
#define OPT_FREEZESSRIGHT "FreezeStepSizeRightBound"
#define OPT_MAXSS "MaxStep"
#define OPT_MAXSTEPS "MaxNumberOfSteps"
#define OPT_STEPSIZESTRATEGY "StepSizeStrategy"

/* Newton */
#define OPT_MAXNEWTONITER "MaxNewtonIterations"
#define OPT_NEWTONSTARTSWITCH "StartNewtonWithZeros"
#define OPT_NEWTONSTOPCRIT "NewtonStopCriterion"

/* Mass */
#define OPT_MASSMATRIX "Mass"
#define OPT_MASSLBAND "MassLowerBandwidth"
#define OPT_MASSUBAND "MassUpperBandwidth"

/* Jacobi */
#define OPT_TRANSJTOH "TransfromJACtoHess"
#define OPT_JACRECOMPFACTOR "RecomputeJACFactor"
#define OPT_JACOBIMATRIX "Jacobian"
#define OPT_JACOBILBAND "JacobianLowerBandwidth"
#define OPT_JACOBIUBAND "JacobianUpperBandwidth"

/* Index-Vars */
#define OPT_DIMOFIND1VAR "DimensionOfIndex1Vars"
#define OPT_DIMOFIND2VAR "DimensionOfIndex2Vars"
#define OPT_DIMOFIND3VAR "DimensionOfIndex3Vars"

/* Special structure */
#define OPT_M1 "M1"
#define OPT_M2 "M2"

/* Rest */
#define OPT_EPS "eps"
#define OPT_IGPIDO "IncludeGridPointsInDenseOutput"
#define OPT_FUNCCALLMETHOD "FuncCallMethod"

typedef void (*RadauRightSide)(Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar);

typedef void (*RadauSolout)(Fint *nr, double *told,
  double *t, double *x, double *cont, Fint *lrc, 
  Fint *n,	double *rpar, Fint *ipar, Fint *irtrn);
  
typedef void (*RadauMAS)(Fint *n, double *am,
  Fint *lmas, double *rpar, Fint *ipar);
  
typedef void (*RadauJAC)(Fint *n, double *t,
  double *x, double *dfy, Fint *ldfy, double *rpar, Fint *ipar);

void RadauRightSideFunc (Fint *n, double *t,
  double *x, double *f,double *rpar, Fint *ipar);

void RadauSoloutFunc (Fint *nr, double *told,
  double *t, double *x, double *cont, Fint *lrc, 
  Fint *n, double *rpar, Fint *ipar, Fint *irtrn);

void RadauMASFullFunc (Fint*, double*, Fint*, double*, Fint*);
void RadauMASFullLRFunc (Fint*, double*, Fint*, double*, Fint*);
void RadauMASBandedMatrixFunc (Fint*, double*, Fint*, double*, Fint*);
void RadauMASBandedCellFunc (Fint*, double*, Fint*, double*, Fint*);
void RadauMASBandedLRMatrixFunc (Fint*, double*, Fint*, double*, Fint*);
void RadauMASBandedLRCellFunc (Fint*, double*, Fint*, double*, Fint*); 

void RadauJACFullFunc (Fint*, double*,double*, double*, Fint*, double*, Fint*);
void RadauJACFullLFunc (Fint*, double*,double*, double*, Fint*, double*, Fint*);
void RadauJACBandedFunc (Fint*, double*,double*, double*, Fint*, double*, Fint*);
void RadauJACBandedLFunc (Fint*, double*,double*, double*, Fint*, double*, Fint*); 


struct ListElement
{ /* Verkettete Liste mit (t,x)-Paaren, also Vektoren der Länge d+1 */
  double* values;
  struct ListElement *next;
};
typedef struct ListElement SListElement;
typedef SListElement* PListElement;

struct ParameterIO 
{ /* Parameter für Input/Output zwischen Matlab und C */    
  const mxArray *opt;  /* Optionen */
  char optCreated;     /* Flag, ob Optionen selbst generiert wurden */
};
typedef struct ParameterIO SParameterIO;

struct ParameterGlobal 
{ /* globale Variablen usw. */
  mwSize d;           /* Dimension des Systems */
  mwSize tLength;     /* Länge des t-Vektors */  
  double* tPointer;   /* Pointer auf Zeitdaten in tArray */  
  double direction;   /* sign(tEnd-tStart) */
  int funcCallMethod; /* Methode, um Matlab-Funktionen aufzurufen */
};
typedef struct ParameterGlobal SParameterGlobal;

struct ParameterRadau
{ /* Parameter für Radau (soweit nicht ausgelagert) */
  double tStart;    /* Startzeitpunkt */
  double tEnd;      /* Endzeitpunkt */
  double h;         /* Startschrittweite */
  char denseFlag;   /* Flag, ob dense-Output aktiv */
  double *xStart;   /* Startwert */
  double *RTOL;     /* releative Toleranz */
  double *ATOL;     /* absolute Toleranz */
  Fint ITOL;        /* Switch für RTOL und ATOL */  
  Fint IOUT;        /* Switch für SOLOUT */  
  double *WORK;     /* Double-Arbeits-Array */
  Fint LWORK;       /* Länge von WORK */
  Fint *IWORK;      /* Integer-Arbeits-Array */
  Fint LIWORK;      /* Länge von IWORK */
  double *RPAR;     /* Zusatz double-array */
  Fint *IPAR;       /* Zusatz int-array */
  Fint IDID;        /* Status */  
  Fint mm;          /* m1=mm*m2, falls m1,m2!=0 */
};
typedef struct ParameterRadau SParameterRadau;

struct RadauDense
{ /* Argumente zum Aufruf von CONTR5 */
  double *cont;
  Fint *lrc;
};
typedef struct RadauDense SRadauDense;

struct ParameterRightSide 
{ /* Parameter für rechte Seite f */
  char *rightSideFcn;           /* Funktionsname für rechte Seite */
  const mxArray *rightSideFcnH; /* Funktionshandle oder inline-function für rightSide */
  mxArray *tArg;                /* Zum Aufruf von f: t */
  mxArray *xArg;                /* Zum Aufruf von f: x */
};
typedef struct ParameterRightSide SParameterRightSide;

struct ParameterMassmatrix
{ /* Parameter für Massenmatrix */
  Fint IMAS;             /* Switch zur Berechnungsmethode für Massenmatrix */
  Fint MLMAS;            /* untere Bandbreite von Massenmatrix */
  Fint MUMAS;            /* obere Bandbreite von Massenmatrix */  
  RadauMAS radauMASFunc; /* Funktion für Massenmatrix aus Radau */
};
typedef struct ParameterMassmatrix SParameterMassmatrix;

struct ParameterJacobimatrix
{ /* Parameter für Jacobimatrix */
  Fint IJAC;              /* Switch zur Berechnungsmethode für Jacobi */
  Fint MLJAC;             /* untere Bandbreite von Jacobi */
  Fint MUJAC;             /* obere Bandbreite von Jacobi */
  RadauJAC radauJACFunc;  /* Funktion für Jacobimatrix aus Radau */
  char *jacFcn;           /* Funktion zur Berechnung der Jacobimatrix */
  const mxArray *jacFcnH; /* Funktionshandle oder inline-function für Jacobi */
  mxArray *tArg;          /* Zum Aufruf von jac: t */
  mxArray *xArg;          /* Zum Aufruf von jac: x */
};
typedef struct ParameterJacobimatrix SParameterJacobimatrix;

struct ParameterOutput
{ /* Parameter zum Speichern der Radau-Ausgabe */
  SListElement txList;        /* Start der txListe */
  PListElement lastTXElement; /* letzter Eintrag in txListe */
  mwSize numberOfElements;    /* Anzahl der Einträge in txListe */
  mwSize tPos;                /* Position im t-Vektor */
  int includeGrid;            /* Flag, dense Ausgabe mit Gridpoints */
  char* outputFcn;            /* Outputfunction */
  const mxArray *outputFcnH;  /* Outputfunction: handle oder inline-function */
  int outputCallMode;         /* Modus für outputFcn-Aufruf */
  mxArray *tArg;              /* Zum Aufruf von outputFcn: t */
  mxArray *xArg;              /* Zum Aufruf von outputFcn: x */
  mxArray *emptyArg;          /* Zum Aufurf von outputFcn: empty array [] */
  mxArray *toldArg;           /* Zum Aufruf von outputFcn: tOld */
};
typedef struct ParameterOutput SParameterOutput;

#ifdef FORTRANNOUNDER
/* Fortran functions without underscore */
#ifdef FORTRANUPP
/* Fortran functions without underscore  & UPPERCASE letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions without underscore & UPPERCASE letters & leading underscore */
#define RADAU5_ _RADAU5
#define CONTR5_ _CONTR5
#else
/* Fortran functions without underscore & UPPERCASE letters & without leading underscore */
#define RADAU5_ RADAU5
#define CONTR5_ CONTR5
#endif
#else
/* Fortran functions without underscore  & lowercase letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions without underscore & lowercase letters & leading underscore */
#define RADAU5_ _radau5
#define CONTR5_ _contr5
#else
/* Fortran functions without underscore & lowercase letters & without leading underscore */
#define RADAU5_ radau5
#define CONTR5_ contr5
#endif
#endif
#else
/* Fortran functions with underscore */
#ifdef FORTRANUPP
/* Fortran functions with underscore & UPPERCASE letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions with underscore & UPPERCASE letters & leading underscore */
#define RADAU5_ _RADAU5_
#define CONTR5_ _CONTR5_
#else
/* Fortran functions with underscore & UPPERCASE letters */
#endif
#else
/* Fortran functions with underscore & lowercase letters */
#ifdef FORTRANLEADUNDER
/* Fortran functions with underscore & lowercase letters  & leading underscore*/
#define RADAU5_ _radau5_
#define CONTR5_ _contr5_
#else
/* Fortran functions with underscore & lowercase letters  & without leading underscore*/
#define RADAU5_ radau5_
#define CONTR5_ contr5_
#endif
#endif
#endif

extern double CONTR5_ (Fint *i,
  double *x, double *cont, Fint *lrc);

extern void RADAU5_ (Fint *n, RadauRightSide fcn, 
  double *t, double *x, double *tend, double *h, 
  double *rtol, double *atol,Fint *itol,
  RadauJAC jac, Fint *ijac, Fint *mljac, Fint *mujac,
  RadauMAS mas, Fint *imas, Fint *mlmas, Fint *mumas,
  RadauSolout solout, Fint *iout,
  double *work, Fint *lwork,
  Fint *iwork, Fint *liwork,
  double *rpar, Fint *ipar, Fint* idid);

#endif
