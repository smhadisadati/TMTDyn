% example 2
%    x1'=x2
%    x2'=x1
%    x1(1)=1, x2(1)=2
close all;clear classes;
opt.RelTol=1e-6;opt.AbsTol=1e-6;
% Jacobimatrix full (Jacobimatrix vollbesetzt)
% Jacobimatrix given (Jacobimatrix wird explizit angegeben)
opt.JacobianLowerBandwidth=2;
opt.Jacobian=@jac; % also possible: opt.Jacobian='jac';
% Jacobian is really cheap (Jacobiauswertung ist so billig)
opt.RecomputeJACFactor=-1;

[tG,xG,stats]=radau5Mex(@f,[1,2],[1;2],opt);

t=linspace(1,2,100);
h1=1.5*exp(t-1);h2=0.5*exp(1-t);
plot(t,h1-h2,'g',t,h1+h2,'g',tG,xG(:,1),'rx',tG,xG(:,2),'bx');