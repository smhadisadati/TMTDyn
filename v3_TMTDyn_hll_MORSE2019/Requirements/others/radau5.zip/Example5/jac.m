function df=jac(t,x)
% Jacobian
df={{t,[1,2]},{0,[1,1]},{1,[1,0]}};
% also possible:
% df={[0,t;1,2],[0,0;1,1],[0,1;1,0]};
% oder
% df={{t,[1,2]},[0,0;1,1],[0,1;1,0]};
