function dx=f(t,x)
% right side
dx=t*[x(2);x(1)];

