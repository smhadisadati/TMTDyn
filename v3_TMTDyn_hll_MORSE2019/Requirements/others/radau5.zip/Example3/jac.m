function df=jac(t,x)
% Jacobian
df=[0,t*x(2); t*x(1),0];

