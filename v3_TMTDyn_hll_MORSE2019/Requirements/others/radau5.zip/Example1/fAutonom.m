function dx=fAutonom(x)
% right side
dx=x;
