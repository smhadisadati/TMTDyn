/* mögliche Fehler, werden in radau5Mex.c included */

/* allgemeine Fehler */
case 1:
  tif_printInfos();
  MPR("English: \n");
  MPR("Only 2,3 or 4 output arguments are possible, but "FMTS" were requested.\n",i1);
  MPR("German: \n");
  MPR("Es werden 2,3 oder 4 Ausgabeargumente unterstützt. Verlangt wurden\n");
  MPR("aber "FMTS" Ausgabeargumente.\n",i1);
  msg="Invalid number of output arguments (Ungültige Anzahl von Ausgabeargumenten)";break;
case 2:
  MPR("English: \n");
  MPR("Only 3 or 4 input arguments are possible, but "FMTS" were passed.\n",i1);
  MPR("German: \n");
  MPR("Es werden 3 oder 4 Eingabeargumente unterstützt. Es wurden aber\n");
  MPR(FMTS" Argumente übergeben.\n",i1);
  msg="Invalid number of input arguments (Ungültige Anzahl von Eingabeargumenten)";break;
case 3:
  MPR("English: \n");
  MPR("1st argument has to be a string (function name), a function handle\n");
  MPR("or an inline function.\n");
  MPR("German: \n");
  MPR("1. Argument muss ein String (Funktionsname), ein Funktions-Handle\n");
  MPR("oder eine inline-Funktion sein.\n");
  msg="1. Arg: Function (String,handle,inline) expected";break;
case 4:
  MPR("English: \n");
  MPR("1st argument has characters, but needs to be ONE string. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a matrix containing strings.");
  MPR("\n");
  MPR("German: \n");
  MPR("1. Argument enthält Zeichen, muss aber EIN String sein. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine Matrix aus Strings.");
  MPR("\n");
  msg="1. Arg: only ONE string expected (nur EIN String erwartet)";break;
case 5:
  MPR("English: \n");
  MPR("2nd argument has to be a double row vector.\n");
  MPR("German: \n");
  MPR("2. Argument muss ein double-Zeilenvektor sein.\n");
  msg="2. Arg: double row vector expected (double-Vektor erwartet)";break;
case 6:
  MPR("English: \n");
  MPR("2nd argument has to be a double row vector. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a double matrix");
  MPR("\n");
  MPR("German: \n");
  MPR("2. Argument muss ein double-Vektor sein. ");
  if (i1!=2)
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine double-Matrix.");
  MPR("\n");
  msg="2. Arg: (1,k) double vector expected ((1,k) double-Vektor erwartet)";break;
case 7:
  MPR("English: \n");
  MPR("2nd argument has to be a double vector with at least 2 components.\n");
  MPR("The length of the vector found is "FMTS".\n",(size_t)paramGlobal.tLength);
  MPR("German: \n");
  MPR("2. Argument muss double-Vektor mit mindestens der\n");
  MPR("Länge 2 sein. Der übergebene Vektor hat Länge "FMTS".\n",(size_t)paramGlobal.tLength);
  msg="2. Arg: (1,k) double vector (k>=2) expected ((1,k) double-Vektor (k>=2) erwartet)";break;
case 8:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector.\n");
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor sein.\n");
  msg="3. Arg: double vector expected (double-Vektor erwartet)";break;
case 9:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector.\n");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("Not a double matrix");
  MPR("\n");
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor sein. ");
  if (i1!=2)
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("Keine double-Matrix.");
  MPR("\n");
  msg="3. Arg: (d,1) double vector expected ((d,1) double-Vektor erwartet)";break;
case 10:
  MPR("English: \n");
  MPR("3rd argument has to be a double column vector with at least one component.\n");
  MPR("The length of the vector found was "FMTS".\n",d);
  MPR("German: \n");
  MPR("3. Argument muss ein double-Spaltenvektor mit mindestens\n");
  MPR("der Länge 1 sein. Der übergebene Vektor hat Länge "FMTS".\n",d);
  msg="3. Arg: (d,1) double vector (d>=1) expected ((d,1) double-Vektor (d>=1) erwartet)";break;
case 11:
  MPR("English: \n");
  MPR("4th argument has to be a struct.\n");
  MPR("German: \n");
  MPR("4. Argument muss eine struct sein.\n");
  msg="4. Arg: struct expected (struct erwartet)";break;
case 12:
  MPR("English: \n");
  MPR("2nd arg: start- and end-time are the same.\n");
  MPR("German: \n");
  MPR("2. Argument: Start- und Endzeitpunkt dürfen nicht\n");
  MPR("übereinstimmen!\n");
  msg="2. Arg: tStart==tEnd";break;
case 14:
  MPR("English: \n");
  MPR("2nd argument has to be ordered.\n");
  if (d1>0)
    MPR("Because of %f=tStart<tEnd=%f, the 2nd argument has to be ascending.\n",
      paramRadau.tStart,paramRadau.tEnd);
  else
    MPR("Because of %f=tStart>tEnd=%f, the 2nd argument has to be descending.\n",
      paramRadau.tStart,paramRadau.tEnd);
  MPR("German: \n");
  MPR("2. Argument muss sortiert sein.\n");
  if (d1>0)
    MPR("Da %f=tStart<tEnd=%f ist, muss das zweite Argument steigend\n",
     paramRadau.tStart,paramRadau.tEnd); 
  else    
    MPR("Da %f=tStart>tEnd=%f ist, muss das zweite Argument fallend\n",
     paramRadau.tStart,paramRadau.tEnd); 
  MPR("sortiert sein.\n");
  msg="2. Arg: has to be ordered (muss sortiert sein)";break;
case 16:
  MPR("English: \n");
  MPR("Concerning option '%s' and '%s':\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  MPR("Requirement: '%s'<='%s'.\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  MPR("But I found: '%s'="FMTS" and '%s'="FMTS".\n",OPT_MASSLBAND,i1,OPT_JACOBILBAND,i2);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  MPR("Es muss gelten: '%s'<='%s'.\n",OPT_MASSLBAND,OPT_JACOBILBAND);
  MPR("Gefunden wurde: '%s'="FMTS" und '%s'="FMTS"\n",OPT_MASSLBAND,i1,OPT_JACOBILBAND,i2);
  msg="MLMAS > MLJAC";break;
case 18:
  MPR("English: \n");
  MPR("Concering Options '%s' and '%s':\n",OPT_MASSMATRIX,OPT_TRANSJTOH);
  MPR("Transformation of the Jacobian to Hessenberg form is not supported\n");
  MPR("for implicit systems.\n");
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_MASSMATRIX,OPT_TRANSJTOH);
  MPR("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  MPR("wird nicht bei impliziten Systeme unterstützt.\n");
  msg="Jacobian transformation to Hessenberg for implicit systems not possible (Hessenbergtransformation der Jacobischen bei impliziten System nicht möglich)";break;
case 19:
  MPR("English: \n");
  MPR("Concerning option '%s' and '%s':\n",OPT_M1,OPT_TRANSJTOH);
  MPR("Transformation of the Jacobian to Hessenberg form is not supported\n");
  MPR("for systems with special structure ('%s'>0).\n",OPT_M1);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_TRANSJTOH);
  MPR("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  MPR("wird nicht bei Systemen mit Spezialstruktur ('%s'>0) unterstützt.\n",OPT_M1);
  msg="Hessenbergtransformation not supported if system has special structure (Hessenbergtransformation bei Systemen mit Spezialstruktur)";break;
case 20:
  MPR("English: \n");
  MPR("Concerning option '%s' and '%s':\n",OPT_JACOBILBAND,OPT_TRANSJTOH);
  MPR("Transformation of the Jacobian to Hessenberg form is not supported\n");
  MPR("for systems with band structure.\n");
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_JACOBILBAND,OPT_TRANSJTOH);
  MPR("Die Transformation der Jacobimatrix auf Hessenberggestalt\n");
  MPR("wird nicht bei Jacobimatrizen mit Bandstruktur unterstützt.\n");
  msg="Hessenbergtransformation of the Jacobian not supported for banded Jacobians (Hessenbergtransformation bei Jacobimatrizen mit Bandstruktur)";break;
case 21:
  MPR("English: \n");
  MPR("1st argument contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Not a matrix containing inline-funcs or function handles.");
  MPR("\n");
  MPR("German: \n");
  MPR("1. Argument enthält zwar Inline-Funktionen oder Funktions-Handles, aber");
  MPR("benötigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  MPR("\n");
  msg="1. Arg: only ONE function expected (nur EINE Funktion erwartet)";break;
case 22:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("'%s'==0 was chosen. Hence all Matlab-functions must be given as string.\n",OPT_FUNCCALLMETHOD);
  MPR("But the rightSide was not a string.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es wurde '%s'==0 gewählt. Also müssen alle Matlab-Funktionen als String angegeben werden.\n",OPT_FUNCCALLMETHOD);
  MPR("Aber die rechte Seite war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: müssen Funktionsnamen übergeben werden)";break;
case 23:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("'%s'==0 was chosen. Hence the all Matlab-functions must be given as string.\n",OPT_FUNCCALLMETHOD);
  MPR("But the Output Function was not a string.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es wurde '%s'==0 gewählt. Also müssen alle Matlab-Funktionen als String angegeben werden.\n",OPT_FUNCCALLMETHOD);
  MPR("Aber die Output Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: müssen Funktionsnamen übergeben werden)";break;
case 24:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("'%s'==0 was chosen. Hence the all Matlab-functions must be given as string.\n",OPT_FUNCCALLMETHOD);
  MPR("But the Jacobimatrix Function was not a string.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es wurde '%s'==0 gewählt. Also müssen alle Matlab-Funktionen als String angegeben werden.\n",OPT_FUNCCALLMETHOD);
  MPR("Aber die Jacobimatrix Funktion war kein String mit Funktionsname.\n");
  msg="CallMethod 0 => all Matlab-Funcs must be given as Strings (Bei Aufrufmethode 0: müssen Funktionsnamen übergeben werden)";break;
case 25:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Requirement: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FUNCCALLMETHOD);
  MPR("Es muss gelten: '%s'==0 or '%s'==1\n",OPT_FUNCCALLMETHOD,OPT_FUNCCALLMETHOD);
  msg="Invalid call method (ungültige Methode für Funktionsaufruf)";break;
case 26:
  MPR("English: \n");
  MPR("2nd argument is too large (length is "FMTS"). I was compiled\n",i1);
  MPR("with a maximal vector size of "FMTS". Try recompiling\n",i2);
  MPR("with largeArrayDims turned on.\n");
  MPR("German: \n");
  MPR("2. Argument ist zu groß (Länge ist % " FMT_SIZE_T "u). Ich wurde für \n",i1);
  MPR("Vektoren mit maximal "FMTS" Einträge kompiliert. Versuchen\n",i2);
  MPR("Sie ein erneutes Kompilieren mit aktivierten largeArrayDims.\n");
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;
case 27:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_RTOL);
  MPR("'%s' was too large (length is "FMTS") for mwSize.\n",OPT_RTOL,i1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_RTOL);
  MPR("'%s'==0 war zu groß (Länge ist "FMTS") für mwSize.\n",OPT_RTOL,i1);
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;
case 28:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_ATOL);
  MPR("'%s' was too large (length is "FMTS") for mwSize.\n",OPT_RTOL,i1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_ATOL);
  MPR("'%s'==0 war zu groß (Länge ist "FMTS") für mwSize.\n",OPT_RTOL,i1);
  msg="Dimension too large for mwSize (Dimension zu groß für mwSize)";break;
    
/* errors concerning the massmatrix */
/* Fehler im Zusammenhang mit der Massenmatrix */
case 101:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("The system has dimension d="FMTS". Because of\n",i1);
    MPR("'%s'=d="FMTS" the massmatrix is full (not banded).\n",OPT_MASSLBAND,i1);
    MPR("Hence in '%s' this double-matrix is expected.\n",OPT_MASSMATRIX);
  } else {
    MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",i1,OPT_M1,i2);
    MPR("Because of '%s'=d-'%s'="FMTS" the lower right\n",OPT_MASSLBAND,OPT_M1,i1-i2);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block of the massmatrix is full (not banded)",
      OPT_M1,OPT_M1,i1-i2,i1-i2);
    MPR("Hence in '%s' this block is expected.\n",OPT_MASSMATRIX);
  }
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("Die Systemdimension ist d="FMTS". Da aber\n",i1);
    MPR("'%s'=d="FMTS" ist, ist die Massenmatrix vollbesetzt.\n",OPT_MASSLBAND,i1);
    MPR("Deshalb wird in '%s' diese double-Matrix erwartet.\n",OPT_MASSMATRIX);
  } else {
    MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",i1,OPT_M1,i2);
    MPR("Da nun '%s'=d-'%s'="FMTS" ist, ist der rechte untere\n",OPT_MASSLBAND,OPT_M1,i1-i2);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS")-Block der Massenmatrix vollbesetzt.\n",OPT_M1,OPT_M1,i1-i2,i1-i2);
    MPR("Deshalb wird in '%s' dieser unter Block\n",OPT_MASSMATRIX);
    MPR("erwartet.\n");
  }
  msg="Massmatrix has to be double-matrix (Massenmatrix muss double-Matrix sein)";break;
case 102:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("I expected a double-matrix, not a 0-, 1- or >=3-dimensional thing.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Es wird eine double-Matrix erwartet. ");
  MPR("Kein 0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="Massmatrix must be 2-dimensional (Massenmatrix muss 2-dimensional sein)";break;
case 103:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("A quadratic double-matrix is expected.\n");
  MPR("But I found a ("FMTS","FMTS")-matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Es wird eine quadratische double-Matrix erwartet.\n");
  MPR("Gefunden wurde aber eine ("FMTS","FMTS")-Matrix.\n",i1,i2);
  msg="Massmatrix must be quadratic (Massenmatrix muss quadratisch sein)";break;
case 104:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("The system has dimension d="FMTS". Because of\n",d);
    MPR("'%s'=d="FMTS" the massmatrix is full (not banded).\n",OPT_MASSLBAND,d);
    MPR("Hence in '%s' this double-matrix is expected.\n",OPT_MASSMATRIX);
  } else {
    MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,i2);
    MPR("Because of '%s'=d-'%s'="FMTS" the lower right\n",OPT_MASSLBAND,OPT_M1,d-i2);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block of the massmatrix is full (not banded)",OPT_M1,OPT_M1,d-i2,d-i2);
    MPR("Hence in '%s' this Block is expected.\n",OPT_MASSMATRIX);
  }
  MPR("I found a ("FMTS","FMTS")-Matrix.\n",i1,i1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("Die Systemdimension ist d="FMTS". Da aber\n",d);
    MPR("'%s'=d="FMTS" ist, ist die Massenmatrix vollbesetzt.\n",OPT_MASSLBAND,d);
    MPR("Deshalb wird in '%s' diese double-Matrix erwartet.\n",OPT_MASSMATRIX);
  } else {
    MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,i2);
    MPR("Da nun '%s'=d-'%s'="FMTS" ist, ist der rechte untere\n",OPT_MASSLBAND,OPT_M1,d-i2);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS")-Block der Massenmatrix vollbesetzt.\n",OPT_M1,OPT_M1,d-i2,d-i2);
    MPR("Deshalb wird in '%s' dieser unter Block\n",OPT_MASSMATRIX);
    MPR("erwartet.\n");
  }
  MPR("Die gefundene Matrix war eine ("FMTS","FMTS")-Matrix.\n",i1,i1);
  msg="Massmatrix has to be a (d-m1,d-m1) Matrix (Massenmatrix muss eine (d-m1,d-m1) Matrix sein)";break;
case 105:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("The system has dimension d="FMTS". Because of\n",d);
    MPR(""FMTS"='%s'!=d="FMTS" the massmatrix is banded.\n",i1,OPT_MASSLBAND,d);
    MPR("Hence a cell or a double-matrix (containing the bands) is expected.\n");
  } else {
    MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,i2);
    MPR("Because of "FMTS"='%s'!=d="FMTS" the lower right\n",i1,OPT_MASSLBAND,d);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block is banded.\n",OPT_M1,OPT_M1,d-i2,d-i2);
    MPR("Hence a cell or a double-matrix (containing the bands for this block)\n");
    MPR("is expected.\n");
  }
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  if (i2==0) {
    MPR("Die Systemdimension ist d="FMTS". Da aber\n",d);
    MPR(""FMTS"='%s'!=d="FMTS" ist, hat die Massenmatrix\n",i1,OPT_MASSLBAND,d);
    MPR("Bandstruktur. Deshalb wird entweder eine cell oder eine\n");
    MPR("double-Matrix erwartet, die die Einträge der Bänder enthalten.\n");
  } else {
    MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,i2);
    MPR("Da nun "FMTS"='%s'!=d="FMTS" ist, hat der rechte untere\n",i1,OPT_MASSLBAND,d);
    MPR("(d-'%s',d-'%s')=("FMTS","FMTS") Block Bandstruktur.\n",OPT_M1,OPT_M1,d-i2,d-i2);
    MPR("Deshalb wird entweder eine cell oder eine double-Matrix\n");
    MPR("erwartet, die die Einträge der Bänder dieses Blocks enthalten.\n");
  }
  msg="Massmatrix: double-matrix or cell expected (Massenmatrix: double-Matrix oder cell erwartet)";break;
case 106:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d="FMTS" the massmatrix is banded.\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("I found a double-matrix and I expected it containing the bands.\n");
  MPR("Hence I expected a (1+'%s'+'%s',d)=("FMTS","FMTS") matrix.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS),d);
  MPR("But I found a ("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Die Systemdimension ist d="FMTS". Da aber\n",d);
  MPR(""FMTS"='%s'!=d="FMTS" ist, hat die Massenmatrix\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("Bandstruktur. Deshalb wird erwartet, dass die gefundene\n");
  MPR("double-Matrix die Einträge der Bänder enthält. Es wird also eine\n");
  MPR("(1+'%s'+'%s',d)=("FMTS","FMTS") Matrix erwartet.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS),d);
  MPR("Gefunden wurde aber eine ("FMTS","FMTS") Matrix.\n",i1,i2);
  msg="Massmatrix: double-matrix with unexpected size (Massenmatrix: double-Matrix mit unerwarteter Größe)";break;
case 107:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d="FMTS" the massmatrix is banded.\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("I found a cell and I expected it containing the bands.\n");
  MPR("Hence I expected a (1,1+'%s'+'%s')=(1,"FMTS") cell.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS));
  MPR("But I found a ("FMTS","FMTS") cell.\n",i1,i2);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Die Systemdimension ist d="FMTS". Da aber\n",d);
  MPR(""FMTS"='%s'!=d="FMTS" ist, hat die Massenmatrix\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("Bandstruktur. Deshalb wird erwartet, dass die gefundene\n");
  MPR("cell die Einträge der Bänder enthält. Es wird also eine\n");
  MPR("(1,1+'%s'+'%s')=(1,"FMTS") cell erwartet.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS));
  MPR("Gefunden wurde aber eine ("FMTS","FMTS") cell.\n",i1,i2);
  msg="Massmatrix: cell with unexpected size (Massenmatrix: cell mit unerwarteter Größe)";break;
case 108:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because of "FMTS"='%s'!=d-m1="FMTS" the lower right\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block is banded.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("I found a double-matrix and I expected it containing the bands.\n");
  MPR("Hence I expected a (1+'%s'+'%s',d-'%s')=("FMTS","FMTS") matrix.\n",OPT_MASSLBAND,OPT_MASSUBAND,OPT_M1,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS), d-(size_t)paramRadau.IWORK[9-1]);
  MPR("But I found a ("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Da aber "FMTS"='%s'!=d-m1="FMTS" ist, hat der rechte untere\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS")-Block Bandstruktur. Deshalb wird\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("erwartet, dass die gefundene double-Matrix die Einträge\n");
  MPR("der Bänder für diesen Block enthält. Es wird also eine\n");
  MPR("(1+'%s'+'%s',d-'%s')=("FMTS","FMTS") Matrix erwartet.\n",OPT_MASSLBAND,OPT_MASSUBAND,OPT_M1,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS),d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Gefunden wurde aber eine ("FMTS","FMTS") Matrix.\n",i1,i2);
  msg="Massmatrix: double-matrix with unexpected size (Massenmatrix: double-Matrix mit unerwarteter Größe)";break;
case 109:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MASSMATRIX);
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because of "FMTS"='%s'!=d-m1="FMTS" the lower right\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block is banded.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("I found a cell and I excpected it containing the bands.\n");
  MPR("Hence I excpected a (1,1+'%s'+'%s')=(1,"FMTS") cell.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS));
  MPR("But I found a ("FMTS","FMTS") cell.\n",i1,i2);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MASSMATRIX);
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,paramRadau.IWORK[9-1]);
  MPR("Da aber "FMTS"='%s'!=d-m1="FMTS" ist, hat der rechte untere\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-m1,d-m1)=("FMTS","FMTS")-Block Bandstruktur. Deshalb wird\n",d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("erwartet, dass die gefundene cell die Einträge der Bänder\n");
  MPR("für diesen Block enthält. Es wird also eine\n");
  MPR("(1,1+'%s'+'%s')=(1,"FMTS") cell erwartet.\n",OPT_MASSLBAND,OPT_MASSUBAND,(size_t)(1+paramMassmatrix.MLMAS+paramMassmatrix.MUMAS));
  MPR("Gefunden wurde aber eine ("FMTS","FMTS") cell.\n",i1,i2);      
  msg="Massmatrix: cell with unexpected size (Massenmatrix: cell mit unerwarteter Größe)";break;
case 110:
  MPR("English: \n");
  MPR("Concerning Options '%s' and '%s':\n",OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Requirements:\n");
  MPR("0<='%s'<=d-m1="FMTS" and\n",OPT_MASSLBAND,d-i1);
  MPR("0<='%s'<=d-m1="FMTS"\n",OPT_MASSUBAND,d-i1);
  MPR("But I found '%s'="FMTS" and '%s'="FMTS".\n",OPT_MASSLBAND,(size_t)paramMassmatrix.MLMAS,OPT_MASSUBAND,(size_t)paramMassmatrix.MUMAS);
  MPR("German: \n");
  MPR("Zur Option '%s' bzw. '%s':\n",OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Es muss gelten:\n");
  MPR("0<='%s'<=d-m1="FMTS" und\n",OPT_MASSLBAND,d-i1);
  MPR("0<='%s'<=d-m1="FMTS"\n",OPT_MASSUBAND,d-i1);
  MPR("Gefunden wurde aber '%s'="FMTS" und '%s'="FMTS".\n",OPT_MASSLBAND,(size_t)paramMassmatrix.MLMAS,OPT_MASSUBAND,(size_t)paramMassmatrix.MUMAS);
  msg="Massmatrix: impossible values for bandwidth (Massenmatrix: unmögliche Werte für Bandbreite)";break;
case 111:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("The system has dimension d="FMTS".\n",d);
  MPR("Because of "FMTS"='%s'!=d="FMTS" the mass matrix is banded.\n",paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("'%s' is a cell. In every cell entry I expect\n",OPT_MASSMATRIX);
  MPR("a double-Vector. But the entry "FMTS" ist not\n",i1);
  MPR("double-vector.\n");
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Die Systemdimension ist d="FMTS".\n",d);
  MPR("Da aber "FMTS"='%s'!=d="FMTS" ist, hat die Massenmatrix\n",paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("Bandstruktur.\n");
  MPR("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",OPT_MASSMATRIX);
  MPR("einen double-Vektor enthält. Aber der Eintrag "FMTS" ist\n",i1);
  MPR("kein double-Vektor.\n");        
  msg="Massmatrix: cell entry is not a double-vector (Massenmatrix: ein cell-Eintrag ist kein double-Vektor)";break;
case 112:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("The system has dimension d="FMTS".\n",d);
  MPR("Because of "FMTS"='%s'!=d="FMTS" the mass matrix is banded.\n",paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("'%s' is a cell. In every cell entry I expect\n",OPT_MASSMATRIX);
  MPR("a double-Vector. In the entry "FMTS" I expect a\n",i1);
  MPR("(1,"FMTS") double-vector.\n",i4);
  MPR("But I found a ("FMTS","FMTS") double-Vector.\n",i2,i3);
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Die Systemdimension ist d="FMTS".\n",d);
  MPR("Da aber "FMTS"='%s'!=d="FMTS" ist, hat die Massenmatrix\n",paramMassmatrix.MLMAS,OPT_MASSLBAND,d);
  MPR("Bandstruktur.\n");
  MPR("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",OPT_MASSMATRIX);
  MPR("einen double-Vektor enthält. Der Eintrag "FMTS"\n",i1);
  MPR("hat die Größe ("FMTS","FMTS"); erwartet wurde aber (1,"FMTS").\n",i2,i3,i4);
  msg="Massmatrix: cell entry has vector with wrong length (Massenmatrix: ein cell-Eintrag hat Vektor mit falscher Länge)";break;
case 113:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because of "FMTS"='%s'!=d-'%s'="FMTS" the lower right\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block is banded.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("'%s' is a cell. For every entry in this cell I expect a double-vector,\n",OPT_MASSMATRIX);
  MPR("but entry "FMTS" is not a double-vector.\n",i1);
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Da aber "FMTS"='%s'!=d-'%s'="FMTS" ist, hat der rechte untere\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS")-Block Bandstruktur.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",OPT_MASSMATRIX);
  MPR("einen double-Vektor enthält. Aber der Eintrag "FMTS" ist\n",i1);
  MPR("kein double-Vektor.\n");
  msg="Massmatrix: one cell entry is not a double-vector (Massenmatrix: ein cell-Eintrag ist kein double-Vektor)";break;
case 114:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because of "FMTS"='%s'!=d-'%s'="FMTS" the lower right\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS") block is banded.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("'%s' is a cell. For every entry in this cell I expect a double-vector.\n",OPT_MASSMATRIX);
  MPR("In the entry "FMTS" I expect a (1,"FMTS") double-vector.\n",i1,i4);
  MPR("But I found a ("FMTS","FMTS") double-vector.\n",i2,i3);
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s':\n",OPT_MASSMATRIX,OPT_MASSLBAND,OPT_MASSUBAND);
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Da aber "FMTS"='%s'!=d-'%s'="FMTS" ist, hat der rechte untere\n",(size_t)paramMassmatrix.MLMAS,OPT_MASSLBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d-'%s')=("FMTS","FMTS")-Block Bandstruktur.\n",OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d-(size_t)paramRadau.IWORK[9-1]);
  MPR("'%s' ist eine cell. Es wird erwartet, dass jeder cell-Eintrag\n",OPT_MASSMATRIX);
  MPR("einen double-Vektor enthält. Der Eintrag "FMTS"\n",i1);
  MPR("hat die Größe ("FMTS","FMTS"); erwartet wurde aber (1,"FMTS").\n",i2,i3,i4);
  msg="Massmatrix: one cell entry has vector with wrong length (Massenmatrix: ein cell-Eintrag hat Vektor mit falscher Länge)";break;
  
/* errors concerning the jacobian */
/* Fehler im Zusammenhang mit der Jacobimatrix */
case 201: 
  MPR("English: \n");
  MPR("Concerning options '%s' and '%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  MPR("Requirements:\n");
  MPR("0<='%s'<=d-'%s'="FMTS" and\n",OPT_JACOBILBAND,OPT_M1,i1-i2);
  MPR("0<='%s'<=d-'%s'="FMTS"\n",OPT_JACOBIUBAND,OPT_M1,i1-i2);
  MPR("But I found '%s'="FMTS" and '%s'="FMTS".\n",OPT_JACOBILBAND,paramJacobimatrix.MLJAC,OPT_JACOBIUBAND,paramJacobimatrix.MUJAC);
  MPR("German: \n");
  MPR("Zur Option '%s' bzw. '%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  MPR("Es muss natürlich gelten:\n");
  MPR("0<='%s'<=d-'%s'="FMTS" und\n",OPT_JACOBILBAND,OPT_M1,i1-i2);
  MPR("0<='%s'<=d-'%s'="FMTS"\n",OPT_JACOBIUBAND,OPT_M1,i1-i2);
  MPR("Gefunden wurde aber '%s'="FMTS" und '%s'="FMTS".\n",OPT_JACOBILBAND,paramJacobimatrix.MLJAC,OPT_JACOBIUBAND,paramJacobimatrix.MUJAC);
  msg="Jacobimatrix: invalid values for bandwidth (unmögliche Werte für Bandwidth)";break;
case 202:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s','%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  MPR("We have '%s'="FMTS">0 and "FMTS"='%s'!=d-'%s'="FMTS".\n",OPT_M1,(size_t)paramRadau.IWORK[9-1],(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("In such cases band structures are only supported if\n");
  MPR("'%s'+'%s'=d.\n",OPT_M1,OPT_M2);
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s','%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  MPR("Es ist '%s'="FMTS">0 und "FMTS"='%s'!=d-'%s'="FMTS".\n",OPT_M1,(size_t)paramRadau.IWORK[9-1],(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("In einem solchen Fall werden Bandstrukturen nur\n");
  MPR("für '%s'+'%s'=d unterstützt.\n",OPT_M1,OPT_M2);
  msg="Jacobimatrix: Bandstructure for m1>0 only supported if m1+m2=d (Bandstruktur bei m1>0 werden nur für m1+m2=d unterstützt)";
  break;
case 203:
  MPR("English: \n");
  MPR("Concerning options '%s','%s' and '%s','%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  MPR("We have '%s'="FMTS">0 and "FMTS"='%s'!=d-'%s'="FMTS".\n",OPT_M1,(size_t)paramRadau.IWORK[9-1],(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Because we have '%s'+'%s'=d the nontrivial\n",OPT_M1,OPT_M2);
  MPR("(d-'%s',d)=("FMTS","FMTS") lower block of the jacobian\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("is devided into mm+1="FMTS" subblocks ('%s'=mm*'%s')\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("with size ('%s','%s')=("FMTS","FMTS").\n",OPT_M2,OPT_M2,(size_t)paramRadau.IWORK[10-1],(size_t)paramRadau.IWORK[10-1]);
  MPR("The options '%s' and '%s' are related to each of these subblocks.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  MPR("Hence there is the requirement: 0<='%s','%s'<='%s'="FMTS".\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,(size_t)paramRadau.IWORK[10-1]);
  MPR("German: \n");
  MPR("Zu den Optionen '%s','%s' und '%s','%s':\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M1,OPT_M2);
  MPR("Es ist '%s'="FMTS">0 und "FMTS"='%s'!=d-'%s'="FMTS".\n",OPT_M1,(size_t)paramRadau.IWORK[9-1],(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Außerdem ist '%s'+'%s'=d. Dann wird der nichttrivale Teil\n",OPT_M1,OPT_M2);
  MPR("der Jacobimatrix, das ist der (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("in mm+1="FMTS" Blöcke ('%s'=mm*'%s') der Größe ('%s','%s')=("FMTS","FMTS") aufgeteilt.\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2,OPT_M2,OPT_M2,(size_t)paramRadau.IWORK[10-1],(size_t)paramRadau.IWORK[10-1]);
  MPR("Die Optionen '%s' und '%s' werden nun für\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  MPR("jeden dieser Teilblöcke angewendet, folglich muss\n");
  MPR("0<='%s','%s'<='%s'="FMTS" gelten.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,(size_t)paramRadau.IWORK[10-1]);
  msg="Banded Jacobian with m1>0 and m1+m2=d; bandwidth<=m2 expected (Jacobimatrizen mit Bandstruktur bei m1>0 mit m1+m2=d: Bandwidth<=m2 erwartet)";
  break;
case 204:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("No return values found.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Habe keine Rückgabe erhalten.\n");
  msg="Jacobian: no return values (Jacobifunktion ohne Rückgabe)";break;
case 205:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR("'%s'=d the jacobian is full (not banded).\n",OPT_JACOBILBAND);
  MPR("Hence I expect a full matrix, but I didn't found a double-matrix.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Außerdem ist\n",d);
  MPR("'%s'=d, also die Jacobimatrix vollbesetzt.\n",OPT_JACOBILBAND);
  MPR("Deshalb wird als Rückgabe diese vollbesetzte Matrix erwartet.\n");
  MPR("Die Rückgabe war keine double-Matrix.\n");
  msg="Jacobian: didn't return double-matrix (Rückgabe der Jacobifunktion keine double-Matrix)";break;
case 206:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR("'%s'=d the jacobian is full (not banded).\n",OPT_JACOBILBAND);
  MPR("Hence I expect a full matrix, but I found a ("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Außerdem ist\n",d);
  MPR("'%s'=d, also die Jacobimatrix vollbesetzt.\n",OPT_JACOBILBAND);
  MPR("Deshalb wird als Rückgabe diese vollbesetzte Matrix erwartet.\n");
  MPR("Die zurückgegebene Matrix ist aber eine ("FMTS","FMTS") Matrix.\n",i1,i2);    
  msg="Jacobian: didn't return a (d,d)-matrix (Rückagabe der Jacobifunktion keine (d,d)-Matrix)";break;
case 207:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because of '%s'=d-'%s' the nontrivial (d-'%s',d)=("FMTS","FMTS")\n",OPT_JACOBILBAND,OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("lower block of the jacobian is full (not banded).\n");
  MPR("Hence I expect a full matrix, but I didn't find a double-matrix.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen '%s'=d-m1, ist der nichttriviale Teil der\n",OPT_JACOBILBAND);
  MPR("Jacobimatrix, das ist der untere (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("vollbesetzt. Deshalb wird als Rückgabe diese vollbesetzte\n");
  MPR("Matrix erwartet. Die Rückgabe war keine double-Matrix.\n");      
  msg="Jacobian: dind't return double-matrix (Rückgabe der Jacobifunktion keine double-Matrix)";break;
case 208:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because of '%s'=d-'%s' the nontrivial (d-'%s',d)=("FMTS","FMTS")\n",OPT_JACOBILBAND,OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("lower block of the jacobian is full (not banded).\n");
  MPR("Hence I expect a full matrix, but I found a ("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen '%s'=d-'%s', ist der nichttriviale Teil der\n",OPT_JACOBILBAND,OPT_M1);
  MPR("Jacobimatrix, das ist der untere (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("vollbesetzt. Deshalb wird als Rückgabe diese vollbesetzte\n");
  MPR("Matrix erwartet.\n");
  MPR("Die Rückgabe war aber eine ("FMTS","FMTS") Matrix.\n",i1,i2);    
  msg="Jacobian: didn't find (d-m1,d) matrix (Rückgabe der Jacobifunktion keine (d-m1,d)-Matrix)";break;
case 209:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because of '%s'=d-'%s' the nontrivial (d-'%s',d)=("FMTS","FMTS")\n",OPT_JACOBILBAND,OPT_M1,OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("lower block of the jacobian is full (not banded).\n");
  MPR("Hence I expect a full matrix, but I found a ("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen '%s'=d-'%s', ist der nichttriviale Teil der\n",OPT_JACOBILBAND,OPT_M1);
  MPR("Jacobimatrix, das ist der untere (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("vollbesetzt. Deshalb wird als Rückgabe diese vollbesetzte\n");
  MPR("Matrix erwartet.\n");
  MPR("Die Rückgabe war aber eine ("FMTS","FMTS") Matrix.\n",i1,i2);
  msg="Jacobian: didn't find (d-m1,d) matrix (Rückgabe der Jacobifunktion keine (d-m1,d)-Matrix)";break;
case 210:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(FMTS "='%s'!=d the jacobian is banded.\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The Jacobian returned a cell. I expected a\n");
  MPR("(1,1+'%s'+'%s') cell. But I found a ("FMTS","FMTS") cell.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR(""FMTS"='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat eine cell zurückgeliefert.\n");    
  MPR("Es wurde eine (1,1+'%s'+'%s') cell erwartet.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND);
  MPR("Zurückgeliefert wurde aber eine ("FMTS","FMTS") cell.\n",i1,i2);
  msg="Jacobian returned cell with unexpected size (Rückgabe der Jacobifunktion: cell mit unerwarteter Größe)";break;
case 211:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d the jacobian is banded.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The Jacobian returned a cell. Every entry has to be a double-vector.\n");
  MPR("But the entry "FMTS" is not a double-vector.\n",i1);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR(""FMTS"='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat eine cell zurückgeliefert.\n");    
  MPR("Jeder cell-Eintrag muss jetzt ein double-Vektor sein.\n");
  MPR("Der Eintrag "FMTS" ist aber kein double-Vektor.\n",i1);  
  msg="Jacobian: cell entry is not double-vector (Rückgabe der Jacobifunktion: cell-Eintrag ist kein double-Vektor)";break;
case 212:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d the jacobian is banded.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The Jacobian returned a cell. The entry "FMTS" has the wrong size.\n",i1);
  MPR("I expect a (1,"FMTS") double-vector, but I found a ("FMTS","FMTS") matrix.\n",i2,i3,i4);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR(""FMTS"='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat eine cell zurückgeliefert.\n");
  MPR("Der Eintrag "FMTS" ist die falsche Größe.\n",i1);
  MPR("Erwartet wurde ein (1,"FMTS") double-Vektor,\n",i2);
  MPR("gefunden wurde aber eine ("FMTS","FMTS") Matrix.\n",i3,i4);
  msg="Jacobian: cell entry has wrong size (Rückgabe der Jacobifunktion: ein cell-Eintrag hat falsche Länge)";break;
case 213:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d the jacobian is banded.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The jacobian has returned something 0-, 1- or >=3 dimensional thing.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR(""FMTS"='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat aber keine Matrix, sondern\n");
  MPR("ein 0-,1- oder >=3-dimensionales Gebilde zurückgeliefert.\n");  
  msg="Jacobian: Matrix expected (Rückgabe der Jacobifunktion muss Matrix sein)";break;
case 214:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d the jacobian is banded.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The jacobian returned a matrix. I expected a\n");
  MPR("(1+'%s'+'%s',d)=("FMTS","FMTS") matrix, but I found a\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,d);
  MPR("("FMTS","FMTS") matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR(""FMTS"='%s'!=d, hat die Jacobimatrix Bandstruktur.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat eine Matrix zurückgegeben. Erwartet\n");
  MPR("wurde eine (1+'%s'+'%s',d)=("FMTS","FMTS") Matrix,\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC,d);
  MPR("Zurückgeliefert wurde eine ("FMTS","FMTS") Matrix\n",i1,i2);  
  msg="Jacobian: Matrix with unexpected size (Rückgabe der Jacobifunktion: double-Matrix mit unerwarteter Größe)";break;
case 215:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("But the jacobian didn't return such a cell.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion\n.");
  MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-'%s'="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke ('%s'=mm*'%s') eingeteilt. Jeder dieser Teilblöcke\n",OPT_M1,OPT_M2);
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Die Jacobifunktion hat aber keine (1,mm+1) cell zurückgeliefert.\n");  
  msg="Jacobian: (1,mm+1) cell expected (Rückgabe der Jacobifunktion: cell-Vektor erwartet)";break;
case 216:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("But the jacobian didn't return such a cell. I found ("FMTS","FMTS") cell.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion\n.");
  MPR("Die Systemdimension ist d="FMTS" und es ist '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-'%s'="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-'%s',d)=("FMTS","FMTS") Block,\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke ('%s'=mm*'%s') eingeteilt. Jeder dieser Teilblöcke\n",OPT_M1,OPT_M2);
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Die Jacobifunktion hat aber keine (1,mm+1) cell zurückgeliefert.\n");  
  MPR("Gefunden wurde eine ("FMTS","FMTS") cell.\n",i1,i2);
  msg="Jacobian: (1,mm+1) cell expected (Rückgabe der Jacobifunktion: cell-Vektor erwartet)";break;
case 217:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("But the "FMTS" entry of the returned cell is empty.\n",i1);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion\n.");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Der Eintrag "FMTS" in dieser cell ist aber leer.\n",i1);
  msg="Jacobian: returned cell with empty entry (Rückgabe der Jacobifunktion: ein cell-Eintrag war leer)";break;
case 218:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Every entry (for such a subblock) can be a cell or a double-matrix.\n");
  MPR("But the entry "FMTS" is neither a cell nur a double-matrix.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS"\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Jeder solche cell-Eintrag kann nun seinerseits eine cell\n");
  MPR("oder eine double-Matrix sein.\n");
  MPR("Der Eintrag "FMTS" ist aber keines von beidem.\n",i1);
  msg="Jacobian: cell entry is neither cell or double-matrix (Rückgabe der Jacobifunktion: ein cell-Eintrag mit unerwartetem Typ)";
case 219:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Every entry (for such a subblock) can be a cell or a double-matrix.\n");
  MPR("But the entry "FMTS"  is a 0, 1- or >=3-dimensional thing.\n",i1);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Jeder solche cell-Eintrag kann nun seinerseits eine cell\n");
  MPR("oder eine double-Matrix sein.\n");
  MPR("Der Eintrag "FMTS" ist aber ein 0-,1- oder >=3-dimensionales Gebilde.\n",i1);
  msg="Jacobian: cell entry with unexpected dimension (Rückgabe der Jacobifunktion: ein cell-Eintrag mit unerwarteter Dimension)";
  break;
case 220:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Entry %" FMT_SIZE_T " is a matrix. I expected a (1+'%s'+'%s','%s')=("FMTS","FMTS") matrix,\n",i1,OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,(size_t)(1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC),(size_t)paramRadau.IWORK[10-1]);
  MPR("but found a ("FMTS","FMTS") matrix.\n",i2,i3);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Der Eintrag "FMTS" ist eine Matrix; erwartet wurde\n",i1);
  MPR("eine (1+'%s'+'%s','%s')=("FMTS","FMTS") Matrix.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,OPT_M2,(size_t)(1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC),(size_t)paramRadau.IWORK[10-1]);
  MPR("Die Matrix in Eintrag "FMTS" ist aber eine ("FMTS","FMTS") Matrix.\n",i1,i2,i3);
  msg="Jacobian: cell with unexpected matrix size (Rückgabe der Jacobifunktion: Matrix in cell mit unerwarteter Größe)";break;
case 221:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Entry "FMTS" is a cell. I exepected a (1,1+'%s'+'%s')=(1,"FMTS") cell.\n",i1,OPT_JACOBILBAND,OPT_JACOBIUBAND,1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC);
  MPR("But I found a ("FMTS","FMTS") cell.\n",i2,i3);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Der Eintrag "FMTS" ist eine cell; erwartet wurde\n",i1);
  MPR("eine (1,1+'%s'+'%s')=(1,"FMTS") cell.\n",OPT_JACOBILBAND,OPT_JACOBIUBAND,(size_t)(1+paramJacobimatrix.MLJAC+paramJacobimatrix.MUJAC));
  MPR("Die cell in Eintrag "FMTS" ist aber eine ("FMTS","FMTS") cell.\n",i2,i3);
  msg="Jacobian: cell entry cell with wrong size (Rückgabe der Jacobifunktion: cell in cell mit unerwarteter Größe)";break;
case 222:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Entry "FMTS" is a cell. But the entry "FMTS" is not a double vector.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Der Eintrag "FMTS" ist eine cell. Es geht nun um den Eintrag "FMTS"\n",i1,i2);
  MPR("in dieser cell. Es handelt sich um keinen double-Vektor.\n");
  msg="Jacobian: cell entry in cell is not a double-vector (Rückgabe der Jacobifunktion: cell in cell enthält Eintrag, der kein Vektor ist)";
  break;
case 223:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS" and we have '%s'="FMTS".\n",d,OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Because "FMTS"='%s'!=d-'%s'="FMTS" the nontrivial lower\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("(d-'%s',d)=("FMTS","FMTS") block is banded.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("This block is divided into mm+1="FMTS" subblocks ('%s'=mm*'%s').\n",(size_t)paramRadau.mm+1,OPT_M1,OPT_M2);
  MPR("Every subblock is banded. I expect a (1,mm+1) cell containing one entry\n");
  MPR("for each subblock.\n");
  MPR("Entry "FMTS" is a cell. Entry "FMTS" in this cell is a double vector.\n",i1,i2);
  MPR("I expect a (1,"FMTS") vector but found a ("FMTS","FMTS") matrix.\n",i3,i4,i5);
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS" und es ist m1="FMTS".\n",d,(size_t)paramRadau.IWORK[9-1]);
  MPR("Wegen "FMTS"='%s'!=d-m1="FMTS", hat der nichttriviale Teil der\n",(size_t)paramJacobimatrix.MLJAC,OPT_JACOBILBAND,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("Jacobimatrix, das ist der untere (d-m1,d)=("FMTS","FMTS") Block,\n",d-(size_t)paramRadau.IWORK[9-1],d);
  MPR("Bandstruktur. Genauer: dieser block wird in mm+1="FMTS"\n",(size_t)paramRadau.mm+1);
  MPR("Teilblöcke (m1=mm*m2) eingeteilt. Jeder dieser Teilblöcke\n");
  MPR("hat Bandstruktur.\n");
  MPR("Es wird nun eine cell erwartet, in der jeder cell-Eintrag\n");
  MPR("eine solche Teilmatrix beschreibt.\n");
  MPR("Der Eintrag "FMTS" ist eine cell. Es geht nun um den Eintrag "FMTS"\n",i1,i2);
  MPR("in dieser cell. Erwartet wurde ein (1,"FMTS") Vektor.\n",i3);
  MPR("Gefunden wurde aber eine ("FMTS","FMTS") Matrix.\n",i4,i5);    
  msg="Jacobian: cell entry in cell has wrong size (Rückgabe der Jacobifunktion: cell in cell mit Eintrag unerwarteter Größe)";
  break;
case 224:
  MPR("English: \n");
  MPR("Problem calling the jacobian.\n");
  MPR("The system has dimension d="FMTS". Because of\n",d);
  MPR(""FMTS"='%s'!=d the jacobian is banded.\n",paramJacobimatrix.MLJAC,OPT_JACOBILBAND);
  MPR("The jacobian has return a cell. I expected the entries for the bands\n");
  MPR("in the cell. But the cell was 0-, 1- or >=3-dimensional.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der Jacobifunktion.\n");
  MPR("Die Systemdimension ist d="FMTS". Wegen\n",d);
  MPR("'%s'!=d, hat die Jacobimatrix Bandstruktur.\n",OPT_JACOBILBAND);  
  MPR("Die Jacobifunktion hat eine cell zurückgeliefert.\n");    
  MPR("Leider aber ein 0-,1- oder >=3-dimensionales Gebilde.\n");
  msg="Jacobian return cell with unexpected dimension (Rückgabe der Jacobifunktion: cell mit unerwarteter Dimension)";break;

case 225:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Found characters, but expected a string,\n");
  if (i1!=2) 
    MPR("not a 0-, 1- or >=3-dimensional thing.");
  else
    if (i2!=1) MPR("not a matrix containing strings.");
  MPR("\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Habe zwar chars gefunden; habe aber einen String erwartet,\n");
  if (i1!=2) 
    MPR("kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if (i2!=1) MPR("keine Matrix aus Strings.");
  MPR("\n");
  msg="Jacobimatrix: only ONE string expected (nur EIN String erwartet)";break;
  break;
case 226:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Option contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Not a matrix containing inline-funcs or function handles.");
  MPR("\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Option enthält zwar Inline-Funktionen oder Funktions-Handles, aber");
  MPR("benötigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  MPR("\n");
  msg="Jacobimatrix: only ONE function expected (nur EINE Funktion erwartet)";break;
case 227:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Option has to be a string (function name), a function handle\n");
  MPR("or an inline function.\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_JACOBIMATRIX);
  MPR("Option muss ein String (Funktionsname), ein Funktions-Handle\n");
  MPR("oder eine inline-Funktion sein.\n");
  msg="Jacobimatrix: Function (String,handle,inline) expected";break;
  
/* errors concerning the right side */
/* Fehler im Zusammenhang mit der rechten Seite */
case 301:
  MPR("English: \n");
  MPR("Problem calling the right side.\n");
  MPR("No return values found.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite.\n");
  MPR("Habe keine Rückgabe erhalten.\n");
  msg="Right side without return values (Rechte Seite ohne Rückgabe)";break;
case 302:
  MPR("English: \n");
  MPR("Problem calling the right side.\n");
  MPR("The return value was not a double-vector.\n");
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite.\n");
  MPR("Die Rückgabe war kein double-Vektor.\n");
  msg="Right side didn't return double vector (Rückgabe der rechten Seite ist kein double-Vektor)";break;    
case 303:
  MPR("English: \n");
  MPR("Problem calling the right side.\n");
  MPR("The return value was not a (d,1) or (1,d) double-vector.\n");
  MPR("I found a ("FMTS","FMTS") double-matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite.\n");
  MPR("Die Rückgabe war kein (d,1) oder (1,d) double-Vektor.\n");
  MPR("Es wurde eine ("FMTS","FMTS") double-Matrix zurückgegeben.\n",i1,i2);
  msg="Return value of right side was not a (d,1) or (1,d) double vector (Rückgabe der rechten Seite kein (d,1) oder (1,d) double-Vektor)";break;
case 304:
  MPR("English: \n");
  MPR("Problem calling the right side.\n");
  MPR("We have '%s'="FMTS"!=0. Therefore the problem has special structure.\n",OPT_M1,paramRadau.IWORK[9-1]);
  MPR("Hence the right side has return only\n");
  MPR("the non-trivial Part. I expected a\n");
  MPR("(d-'%s',1)=("FMTS",1) or a (1,d-'%s')=(1,"FMTS") double-vector.\n",OPT_M1,d-(size_t)paramRadau.IWORK[9-1],OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("But I found a ("FMTS","FMTS") double-matrix.\n",i1,i2);
  MPR("German: \n");
  MPR("Problem beim Aufruf der rechten Seite.\n");
  MPR("Es ist '%s'="FMTS"!=0. Deshalb hat das Problem Spezialstruktur.\n",OPT_M1,(size_t)paramRadau.IWORK[9-1]);
  MPR("Die rechte Seite muss dann nur noch den\n");
  MPR("nichttrivialen Teil zurückliefern. Erwartet wurde\n");
  MPR("ein (d-'%s',1)=("FMTS",1) oder ein (1,d-'%s')=(1,"FMTS") double-Vektor,\n", OPT_M1,d-(size_t)paramRadau.IWORK[9-1],OPT_M1,d-(size_t)paramRadau.IWORK[9-1]);
  MPR("zurückgegeben wurde aber eine ("FMTS","FMTS") double-Matrix.\n",i1,i2);
  msg="Rückgabe der rechten Seite kein (d-m1,1) oder (1,d-m1) double-Vektor";
  break;
  
/* Errors concering output options */
/* Fehler im Zusammenhang mit Output Options */
case 401:
  MPR("English: \n");
  MPR("Concering option '%s':\n",OPT_OUTPUTFUNCTION);
  MPR("Option contained inline-funcs or function handles, but I need only ONE. ");
  if (i1!=2) 
    MPR("Not a 0-, 1- or >=3-dimensional thing.");
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Not a matrix containing inline-funcs or function handles.");
  MPR("\n");
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_OUTPUTFUNCTION);
  MPR("Option enthält zwar Inline-Funktionen oder Funktions-Handles, aber");
  MPR("benötigt wird nur EIN Handle oder EINE Inline-Funktion. ");
  if (i1!=2) 
    MPR("Kein 0-,1- oder >=3-dimensionales Gebilde."); 
  else
    if ((i2!=1) || (i3!=1)) 
      MPR("Keine Matrix mit Inline-Funktionen oder Funktions-Handles .");
  MPR("\n");
  msg="only ONE function expected (nur EINE Funktion erwartet)";break;

/* Fehler mit WORK-Opt und IWORK-Opt */
case 502:
  MPR("English: \n");
  MPR("Concering Option '%s':\n",OPT_TRANSJTOH);
  MPR("Requirement: 0<='%s'<=1.\n",OPT_TRANSJTOH);
  MPR("But I found: '%s'=%li.\n",OPT_TRANSJTOH,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_TRANSJTOH);
  MPR("Gültige Werte für '%s' sind 0 oder 1.\n",OPT_TRANSJTOH);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_TRANSJTOH,l1);
  msg="invalid JACtoHess transformation flag (ungültiges JACtoHess-Transformationsflag)";break;
case 503:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXSTEPS);
  MPR("Requirement: 0<'%s'.\n",OPT_MAXSTEPS);
  MPR("But I found '%s'=%li.\n",OPT_MAXSTEPS,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXSTEPS);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_MAXSTEPS);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_MAXSTEPS,l1);
  msg="invalid maximal number of steps (ungültige maximale Schrittanzahl)";break;
case 504:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_MAXNEWTONITER);
  MPR("Requirement: 0<'%s'.\n",OPT_MAXNEWTONITER);
  MPR("But I found: '%s'=%li.\n",OPT_MAXNEWTONITER,l1);
  MPR("German: \n");
  MPR("Zur Option '%s'':\n",OPT_MAXNEWTONITER);
  MPR("Es muss gelten: 0<'%s'.\n",OPT_MAXNEWTONITER);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_MAXNEWTONITER,l1);
  msg="invalid maximal number of Newton iterations (ungültige Angabe für die maximale Anzahl von Newtoniterationen)";break;  
case 505:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_DIMOFIND1VAR);
  MPR("Requirement: 0<'%s'<=d="FMTS".\n",OPT_DIMOFIND1VAR,d);
  MPR("But I found: '%s'=%li.\n",OPT_DIMOFIND1VAR,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_DIMOFIND1VAR);
  MPR("Es muss gelten: 0<'%s'<=d="FMTS".\n",OPT_DIMOFIND1VAR,d);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_DIMOFIND1VAR,l1);
  msg="invalid dimension of the index 1 variables (ungültige Dimensionsangabe für die Variablen vom Index 1)";break;
case 506:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_DIMOFIND2VAR);
  MPR("Requirement: 0<='%s'.\n",OPT_DIMOFIND2VAR);
  MPR("But I found: '%s'=%li.\n",OPT_DIMOFIND2VAR,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_DIMOFIND2VAR);
  MPR("Es muss gelten: 0<='%s'.\n",OPT_DIMOFIND2VAR);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_DIMOFIND2VAR,l1);
  msg="invalid dimension of the index 2 variables (ungültige Dimensionsangabe für die Variablen vom Index 2)";break;
case 507:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_DIMOFIND3VAR);
  MPR("Requirement: 0<='%s'.\n",OPT_DIMOFIND3VAR);
  MPR("But I found: '%s'=%li.\n",OPT_DIMOFIND3VAR,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_DIMOFIND3VAR);
  MPR("Es muss gelten: 0<='%s'.\n",OPT_DIMOFIND3VAR);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_DIMOFIND3VAR,l1);
  msg="invalid dimension of the index 3 variables (ungültige Dimensionsangabe für die Variablen vom Index 3)";break;
case 508:
  MPR("English: \n");
  MPR("Concerning Option '%s':\n",OPT_STEPSIZESTRATEGY);
  MPR("Requirement: '%s'=1 or '%s'=2.\n",OPT_STEPSIZESTRATEGY,OPT_STEPSIZESTRATEGY);
  MPR("But I found: '%s'=%li.\n",OPT_STEPSIZESTRATEGY,l1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_STEPSIZESTRATEGY);
  MPR("Gültige Werte für '%s' sind 1 oder 2.\n",OPT_STEPSIZESTRATEGY);
  MPR("Gefunden wurde aber '%s'=%li.\n",OPT_STEPSIZESTRATEGY,l1);
  msg="invalid step size strategy (ungültige Wahl für die Schrittweitenstrategie)";break;
case 509: 
  MPR("English: \n");
  MPR("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  MPR("Requirement: 0<='%s','%s'.\n",OPT_M1,OPT_M2);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  MPR("Es muss natürlich gelten: 0<='%s','%s'\n",OPT_M1,OPT_M2);
  msg="m1 and/or m2 negative (m1 und/oder m2 negativ)";break;
case 510:
  MPR("English: \n");
  MPR("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  MPR("Requirement: '%s'+'%s'<=d.\n",OPT_M1,OPT_M2);
  MPR("But I found: %li='%s'+'%s'>d="FMTS".\n",l1+l2,OPT_M1,OPT_M2,d);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  MPR("Es muss natürlich gelten: '%s'+'%s'<=d.\n",OPT_M1,OPT_M2);
  MPR("Gefunden wurde aber %li='%s'+'%s'>d="FMTS".\n",l1+l2,OPT_M1,OPT_M2,d);
  msg="m1+m2>d";break;
  msg="m1+m2>d";break;
case 511:
  MPR("English: \n");
  MPR("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  MPR("Either '%s' and '%s' are both zero or they are both greater than zero.\n",OPT_M1,OPT_M2);
  MPR("But I found: '%s'=%li, '%s'=%li.\n",OPT_M1,l1,OPT_M2,l2);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  MPR("Entweder sind beide 0 oder beide verschieden von 0\n");
  MPR("Gefunden wurde '%s'=%li und '%s'=%li.\n",OPT_M1,l1,OPT_M2,l2);
  msg="either m1,m2 both zero or both are not (entweder m1,m2 beide 0 oder beide nicht)";break;
case 512:
  MPR("English: \n");
  MPR("Concerning Options '%s' and '%s':\n",OPT_M1,OPT_M2);
  MPR("Requirement: There has to exist an mm with\n");
  MPR("%s=mm*%s.\n",OPT_M1,OPT_M2);
  MPR("But I found '%s'=%li and '%s'=%li.\n",OPT_M1,l1,OPT_M2,l2);
  MPR("German: \n");
  MPR("Zu den Optionen '%s' und '%s':\n",OPT_M1,OPT_M2);
  MPR("'%S' muss ein Vielfaches von '%s' sein. Es muss ein\n",OPT_M1,OPT_M2);
  MPR("mm geben, so dass '%s'=mm*'%s' gilt.\n",OPT_M1,OPT_M2);
  MPR("Gefunden wurde '%s'=%li und '%s'=%li.\n",OPT_M1,l1,OPT_M2,l2);
  msg="m1 must be a multiple of m2 (m1 muss ein Vielfaches von m2 sein)";break;
case 513:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_EPS);
  MPR("Requirement: 0<'%s'<1.\n",OPT_EPS);
  MPR("But I found: '%s'=%e.\n",OPT_EPS,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_EPS);
  MPR("Es muss gelten: 0<'%s'<1.\n",OPT_EPS);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_EPS,d1);
  msg="invalid rounding unit (ungültige Maschinengenauigkeit)";break;
case 514:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_RHO);
  MPR("Requirement: '%s'>0.\n",OPT_RHO);
  MPR("But I found: '%s'=%e.\n",OPT_RHO,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_RHO);
  MPR("Es muss gelten: '%s'>0.\n",OPT_RHO);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_RHO,d1);
  msg="invalid safety factor for step size control (ungültiger Schrittweitensteuerungsparameter)";break;
case 516:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_NEWTONSTOPCRIT);
  MPR("Requirement: '%s'>'%s'/'%s'.\n",OPT_NEWTONSTOPCRIT,OPT_EPS,OPT_RTOL);
  MPR("If '%s' is a vector, then the first component\n",OPT_RTOL);
  MPR("will be used in the above inequality in the requirement.\n");
  MPR("But I found '%s'=%e.\n",OPT_NEWTONSTOPCRIT,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_NEWTONSTOPCRIT);
  MPR("Es muss gelten: '%s'>'%s'/'%s'.\n",OPT_NEWTONSTOPCRIT,OPT_EPS,OPT_RTOL);
  MPR("Falls in '%s' ein Vektor übergeben wurde, so wird dessen\n",OPT_RTOL);
  MPR("erste Komponente in obiger Abschätzung verwendet.\n");
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_NEWTONSTOPCRIT,d1);
  msg="invalid stopping creterion for Newton (ungültiges Abbruchkriterium für die Newton-Iteration)";break;
case 517:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_FREEZESSLEFT);
  MPR("Requirement: 0<='%s'<=1.\n",OPT_FREEZESSLEFT);
  MPR("But I found '%s'=%e.\n",OPT_FREEZESSLEFT,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FREEZESSLEFT);
  MPR("Es muss gelten: 0<='%s'<=1.\n",OPT_FREEZESSLEFT);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_FREEZESSLEFT,d1);
  msg="invalid range value where step size isn't changed (ungültige Bereichsangabe für Bereich, in dem Schrittweite nicht geändert wird)";break;
case 518:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_FREEZESSRIGHT);
  MPR("Requirement: '%s'>=1.\n",OPT_FREEZESSRIGHT);
  MPR("But I found: '%s'=%e.\n",OPT_FREEZESSRIGHT,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_FREEZESSRIGHT);
  MPR("Es muss gelten: '%s'>=1.\n",OPT_FREEZESSRIGHT);
  MPR("Gefunden wurde aber '%s'=%e\n",OPT_FREEZESSRIGHT,d1);
  msg="invalid range value where step size isn't changed (ungültige Bereichsangabe für Bereich, in dem Schrittweite nicht geändert wird)";break;
case 519:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_MAXSS);
  MPR("Requirement: '%s'!=0.\n",OPT_MAXSS);
  MPR("But I found: '%s'=%e.\n",OPT_MAXSS,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_MAXSS);
  MPR("Es muss gelten: '%s'!=0.\n",OPT_MAXSS);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_MAXSS,d1);
  msg="invalid maximal stp size (ungültige maximale Schrittweite)";break;
case 520:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_SSMINSEL);
  MPR("Requirement: 0<'%s'<=1.\n",OPT_SSMINSEL);
  MPR("But I found '%s'=%e.\n",OPT_SSMINSEL,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSMINSEL);
  MPR("Es muss gelten: 0<'%s'<=1.\n",OPT_SSMINSEL);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSMINSEL,d1);
  msg="invalid parameter for step size selection (ungültige untere Grenze für die Schrittweitensteuerung)";break;
case 521:
  MPR("English: \n");
  MPR("Concerning option '%s':\n",OPT_SSMAXSEL);
  MPR("Requirement: '%s'>=1.\n",OPT_SSMAXSEL);
  MPR("But I found '%s'=%e.\n",OPT_SSMAXSEL,d1);
  MPR("German: \n");
  MPR("Zur Option '%s':\n",OPT_SSMAXSEL);
  MPR("Es muss gelten: '%s'>=1.\n",OPT_SSMAXSEL);
  MPR("Gefunden wurde aber '%s'=%e.\n",OPT_SSMAXSEL,d1);
  msg="invalid parameter for step size selection (ungültige obere Grenze für die Schrittweitensteuerung)";break;

/* Errors in inner Call during SolOut routine */
/* Fehler während des inner Calls zum Zeitpunkt der SolOut Routine */
case 601:
  MPR("English:\n");
  MPR("Only one input and output argument is allowed\n");
  MPR("in a call during the output function.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Bei Aufrufen innerhalb der Output Function wird nur\n");
  MPR("ein Eingabe- und ein Ausgabeargument unterstützt.\n");
  msg="wrong number of input and/or output parameters";break;
case 602:
  MPR("English:\n");
  MPR("1st input argument in the call during the ouput function is empty.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Das erste Eingabeargument während des Aufrufs aus der Output Function ist leer.\n");
  msg="1st arg was empty at call inside output function";break;
case 603:
  MPR("English:\n");
  MPR("1st input argument in the call during the ouput function\n");
  MPR("must be a scalar.\n");
  MPR("\n");
  MPR("German:\n");
  MPR("Das erste Eingabeargument während des Aufrufs aus der\n");
  MPR("Output Function muss ein Skalar sein.\n");
  msg="1st arg at call inside output function must be a scalar";break;


/* Fehler, die niemals auftreten sollten */
case 1001:
  msg="internal error: callOutputFcn: unknown reason";
  break;
case 1002:
  msg="internal error: unknown funcCallMethod";
  break;
