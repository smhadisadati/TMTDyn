function [ z , par_mex ] = int_mid_step( t , z , par_mex )
% to be completed by the user...



