/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * massF10_types.h
 *
 * Code generation for function 'massF10'
 *
 */

#ifndef MASSF10_TYPES_H
#define MASSF10_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (massF10_types.h) */
