/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * rtwtypes.h
 *
 * Code generation for function 'massF2'
 *
 */

#ifndef RTWTYPES_H
#define RTWTYPES_H
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */
