/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * massF15_types.h
 *
 * Code generation for function 'massF15'
 *
 */

#ifndef MASSF15_TYPES_H
#define MASSF15_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (massF15_types.h) */
