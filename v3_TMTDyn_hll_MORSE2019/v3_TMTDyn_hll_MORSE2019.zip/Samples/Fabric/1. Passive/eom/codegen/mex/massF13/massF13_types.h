/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * massF13_types.h
 *
 * Code generation for function 'massF13'
 *
 */

#ifndef MASSF13_TYPES_H
#define MASSF13_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (massF13_types.h) */
